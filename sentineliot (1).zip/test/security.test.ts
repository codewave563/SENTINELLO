/**
 * SentinelIoT Automated Security & Cryptography Verification Suite
 * Tests OpenSSL primitives, nonce lifecycle, replay protection, Zero-Trust scoring,
 * and defensive attack simulation.
 */

import {
  generateKeyPair,
  generateSecureNonce,
  signData,
  verifySignature,
  runCryptographicBenchmark,
  calculateFingerprint,
} from '../server/crypto.ts';
import { store } from '../server/store.ts';
import { evaluateZeroTrust } from '../server/zero-trust.ts';
import { evaluateDeviceAnomaly } from '../server/ai-engine.ts';
import { executeAttackScenario } from '../server/attack-simulator.ts';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`[PASS] ${testName}`);
    passed++;
  } else {
    console.error(`[FAIL] ${testName}`);
    failed++;
  }
}

async function runTestSuite() {
  console.log('====================================================');
  console.log('SENTINELIoT SECURITY VERIFICATION TEST SUITE');
  console.log('====================================================\n');

  // Test 1: Key Generation for all 3 algorithms
  console.log('--- 1. Cryptographic Key Generation Primitives ---');
  const ecdsaKey = generateKeyPair('ECDSA_P256');
  assert(ecdsaKey.publicKeyPem.includes('BEGIN PUBLIC KEY'), 'ECDSA P-256 SPKI Public Key generation');
  assert(ecdsaKey.fingerprint.startsWith('SHA256:'), 'ECDSA P-256 SHA-256 Key fingerprint calculation');

  const ed25519Key = generateKeyPair('ED25519');
  assert(ed25519Key.publicKeyPem.includes('BEGIN PUBLIC KEY'), 'Ed25519 Public Key generation');
  assert(ed25519Key.fingerprint.startsWith('SHA256:'), 'Ed25519 SHA-256 Key fingerprint calculation');

  const rsaKey = generateKeyPair('RSA_2048');
  assert(rsaKey.publicKeyPem.includes('BEGIN PUBLIC KEY'), 'RSA-2048 Public Key generation');
  assert(rsaKey.fingerprint.startsWith('SHA256:'), 'RSA-2048 SHA-256 Key fingerprint calculation');

  // Test 2: Digital Signature & Verification
  console.log('\n--- 2. Digital Signature & Verification ---');
  const testPayload = 'TEST_TELEMETRY_PAYLOAD_NONCE_998124';

  // Ed25519
  const edSig = signData('ED25519', ed25519Key.privateKeyPem, testPayload);
  const edValid = verifySignature('ED25519', ed25519Key.publicKeyPem, testPayload, edSig);
  assert(edValid, 'Ed25519 valid signature verification');

  const edTampered = verifySignature('ED25519', ed25519Key.publicKeyPem, testPayload + '_TAMPERED', edSig);
  assert(!edTampered, 'Ed25519 tampered payload rejection');

  // ECDSA P-256
  const ecSig = signData('ECDSA_P256', ecdsaKey.privateKeyPem, testPayload);
  const ecValid = verifySignature('ECDSA_P256', ecdsaKey.publicKeyPem, testPayload, ecSig);
  assert(ecValid, 'ECDSA P-256 valid signature verification');

  // RSA-2048
  const rsaSig = signData('RSA_2048', rsaKey.privateKeyPem, testPayload);
  const rsaValid = verifySignature('RSA_2048', rsaKey.publicKeyPem, testPayload, rsaSig);
  assert(rsaValid, 'RSA-2048 valid signature verification');

  // Test 3: Mutual Challenge-Response & Nonce Freshness
  console.log('\n--- 3. Challenge-Response Nonce Lifecycle & Replay Protection ---');
  store.seedInitialData();
  const testDeviceId = 'IOT-ESP32-07';

  // Issue challenge
  const challenge = store.issueChallenge(testDeviceId);
  assert(challenge.nonce.length === 64, '32-byte hexadecimal CSPRNG nonce generated');
  assert(challenge.expiresAt > Date.now(), 'Nonce expiration window initialized');

  // Sign challenge
  const validSignature = store.signChallengeLocally(testDeviceId, challenge.nonce, challenge.timestamp);

  // First verification (Nominal path)
  const firstVerify = store.verifyChallenge(
    testDeviceId,
    challenge.nonce,
    validSignature,
    challenge.timestamp
  );
  assert(firstVerify.success, 'Challenge verification succeeds on first valid submission');
  assert(firstVerify.nonceValid, 'Single-use nonce marked valid on first use');

  // Second verification with identical nonce (Replay Attack)
  const replayVerify = store.verifyChallenge(
    testDeviceId,
    challenge.nonce,
    validSignature,
    challenge.timestamp
  );
  assert(!replayVerify.success, 'Replay Attack blocked on second submission of same nonce');
  assert(!replayVerify.nonceValid, 'Nonce marked invalid / already consumed');
  assert(Boolean(replayVerify.failureReason?.includes('Replay') || replayVerify.failureReason?.includes('reuse')), 'Audit logs reason as Replay Attack');

  // Timestamp Skew Attack
  const staleChallenge = store.issueChallenge(testDeviceId);
  const staleSig = store.signChallengeLocally(testDeviceId, staleChallenge.nonce, Date.now() - 360000);
  const skewVerify = store.verifyChallenge(
    testDeviceId,
    staleChallenge.nonce,
    staleSig,
    Date.now() - 360000,
    { skewTimestamp: true }
  );
  assert(!skewVerify.success, 'Timestamp skew attack blocked (outside 60s tolerance window)');

  // Test 4: Zero-Trust Evaluation & Policy Decision
  console.log('\n--- 4. Zero-Trust Dynamic Evaluation & Risk Scoring ---');
  const device = store.getDevice(testDeviceId)!;
  const nominalZT = evaluateZeroTrust(device, 0);
  assert(nominalZT.overallTrustScore >= 75, 'Nominal device evaluates with high trust score');
  assert(nominalZT.policyDecision === 'ALLOW', 'Nominal device granted ALLOW policy');

  // Elevated risk simulation
  store.updateDeviceTelemetry(testDeviceId, {
    failedAuthCount: 4,
    authFailureRate: 0.5,
    bytesSent: 45000,
    uniqueDestinations: 6,
  });
  const elevatedDev = store.getDevice(testDeviceId)!;
  const elevatedZT = evaluateZeroTrust(elevatedDev, 1);
  assert(elevatedZT.riskScore > 50, 'Risk score elevated above 50 on abnormal telemetry');
  assert(elevatedZT.policyDecision !== 'ALLOW', 'Zero-Trust policy restricts or quarantines elevated risk node');

  // Test 5: Defensive Attack Simulation Engine
  console.log('\n--- 5. Defensive Attack Simulation Scenarios ---');
  const simRun = executeAttackScenario('SCENARIO-1', testDeviceId);
  assert(simRun.phases.length === 6, '6-stage defensive pipeline executed (Ingest to Respond)');
  assert(simRun.phases[1].status === 'DETECTED', 'Attack successfully detected at Phase 2');
  assert(simRun.finalDecision === 'QUARANTINE', 'Zero-Trust decision matrix enforces QUARANTINE');

  // Test 6: High-Precision Cryptographic Benchmark
  console.log('\n--- 6. Cryptographic Benchmark Engine ---');
  const benchmarks = runCryptographicBenchmark();
  assert(benchmarks.length === 3, 'Benchmark completed for ECDSA, Ed25519, and RSA-2048');
  assert(benchmarks[0].signMs > 0, 'Measured real sign execution time in ms');
  assert(benchmarks[1].signatureSizeBytes === 64, 'Ed25519 signature is exactly 64 bytes');
  assert(benchmarks[2].signatureSizeBytes === 256, 'RSA-2048 signature is exactly 256 bytes');

  console.log('\n====================================================');
  console.log(`TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  if (failed > 0) {
    process.exit(1);
  }
}

runTestSuite().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
