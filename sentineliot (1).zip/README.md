# SentinelIoT — Zero-Trust Cryptographic Security & AI Threat Detection Platform for IoT

SentinelIoT is an enterprise-grade IoT Security Operations Center (SOC) combining **asymmetric cryptographic device identity**, **mutual challenge-response authentication**, **continuous Zero-Trust policy evaluation**, and **AI-powered behavioral anomaly detection** (Isolation Forest) with automated incident containment.

---

## 1. System Architecture

```
[ IoT Edge Node / Sensor ]
          │
          │ 1. Mutual Challenge Request
          ▼
┌─────────────────────────────────────────────────────────────┐
│                 SENTINELIOT ZERO-TRUST GATEWAY              │
├─────────────────────────────────────────────────────────────┤
│  [2. Nonce CSPRNG Engine]  ──> 32-Byte Nonce + Expiration    │
│  [3. Cryptographic Engine] ──> OpenSSL (ECDSA / Ed25519/RSA)│
│  [4. Replay Protection]    ──> Single-Use Invalidation Gate  │
│  [5. AI Anomaly Engine]    ──> Isolation Forest Hypersphere │
│  [6. Zero-Trust Policy]    ──> 6-Factor Dynamic Risk Matrix │
│  [7. Containment Engine]   ──> Automated VLAN Isolation     │
│  [8. Audit Trail Ledger]   ──> Immutable Cryptographic Logs │
└─────────────────────────────────────────────────────────────┘
          │
          │ Evaluated Access (ALLOW / RESTRICT / QUARANTINE / BLOCK)
          ▼
[ Operational Industrial SCADA & Cloud Services ]
```

---

## 2. Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Recharts
- **Backend**: Node.js & Express, TypeScript (`tsx`)
- **Security & Cryptography**: Native OpenSSL / Node.js `crypto` primitives:
  - **Ed25519** (Edwards-curve Digital Signature Algorithm, Curve25519)
  - **ECDSA P-256** (NIST FIPS 186-4 with SHA-256)
  - **RSA-2048** (PKCS#1 v1.5 with SHA-256)
- **AI / Anomaly Detection**: Unsupervised Isolation Forest & multivariate dispersion algorithm modeling 10 distinct telemetry feature vectors with Shapley-style feature explainability attribution.
- **Data Layer**: In-memory encrypted catalog with single-use nonce storage and append-only audit trail with CSV/JSON forensic export.

---

## 3. Visual Design System

Implemented to enterprise SOC standards matching the specified color palette:

| Color Token | Hex Code | Purpose |
|---|---|---|
| **Deep Navy** | `#0B1F3A` | Structural cards, header, sidebar surfaces |
| **Dark Navy** | `#08182D` | Neutral canvas background, code blocks |
| **Warm Beige** | `#E8DCC8` | Verified states, primary action CTA buttons |
| **Burnt Copper** | `#C47A5A` | Threat highlights, quarantine markers, active flags |
| **Warm White** | `#FAF7F0` | High-contrast readable typography |
| **Steel Blue** | `#2B5D87` | Accent icons, navigation active states |
| **Muted Beige** | `#C8BDAA` | Secondary labels, descriptions, units |
| **Border** | `#294563` | 1px hairline dividers, single-elevation depth |

**Anti-Slop Discipline**:
- Unboxed typography for metadata (`·` and `/` separators)
- Tabular numerals (`font-mono tabular-nums`) on all timing, counters, and metrics
- No mechanical `//` comment prefixes, no fake version tags, no neon glow

---

## 4. Key Security Modules

### 4.1. Cryptographic Identity & Benchmarking
- **Key Generation**: Real SPKI PEM public key issuance and SHA-256 fingerprinting. Private keys are securely encapsulated server-side and never exposed.
- **Empirical Benchmark Suite**: True execution time measurement (`process.hrtime.bigint()`) across key generation, signing, and verification latency, alongside signature payload size comparison.

### 4.2. Mutual Challenge-Response Authentication
```
Device Request ──> Server Generates 32B Nonce (60s Expiry)
       ▲                        │
       │                        ▼
Server Verifies <── Device Signs Nonce with Private Key
```
- **Replay Defense**: Nonce is invalidated immediately upon first presentation. Re-submitting a previously consumed nonce triggers automated `REPLAY_ATTACK_DETECTED` alarms.
- **Timestamp Freshness**: Submissions outside the 60-second delta tolerance window are rejected.

### 4.3. Continuous Zero-Trust Risk Engine
Evaluates 6 dynamic pillars:
1. **Identity Trust (20%)**: Key curve strength and hardware binding.
2. **Authentication Trust (25%)**: Challenge freshness and session validity.
3. **Device Health (15%)**: CVE patch age and hardware uptime.
4. **Behavioural Trust (25%)**: Inverse of AI anomaly isolation score.
5. **Network Context (15%)**: IP white-listing and destination domain containment.
6. **Threat Penalty**: Direct deduction for uncontained security incidents.

**Dynamic Outcomes**:
- `ALLOW` (Risk < 30)
- `STEP_UP_AUTH` (Risk 30–54)
- `RESTRICT` (Risk 55–74: read-only telemetry mode)
- `QUARANTINE` (Risk ≥ 75: isolated to VLAN 99)
- `BLOCK` (Explicit key revocation)

### 4.4. AI Behavioral Anomaly Detection & Explainability
- Evaluates 10 features: `request_frequency`, `packet_frequency`, `failed_auth_count`, `session_duration`, `command_frequency`, `bytes_sent`, `bytes_received`, `unique_destinations`, `time_since_last_seen`, `auth_failure_rate`.
- **Explainability Panel**: Transparent breakdown showing exact percentage attribution for each flagged deviation (e.g., *Behavioural deviation 42%, Unusual traffic 24%*).

### 4.5. Defensive Cyber Attack Simulator (11 Scenarios)
1. **Replay Attack** (stale nonce resubmission)
2. **Forged Digital Signature** (signature corruption / invalid key)
3. **Expired Timestamp** (time-skew attack >300s)
4. **Concurrent Nonce Reuse** (twin hardware clone collision)
5. **Rogue / Unregistered Device** (unregistered hardware assertion)
6. **Brute-Force Auth Burst** (rapid high-frequency signature guessing)
7. **AI Behavioural Anomaly** (actuator command frequency surge)
8. **Data Exfiltration** (unusual outbound byte volume to external IPs)
9. **Unauthorized Command Injection** (sensor attempting firmware flash)
10. **Device Identity / Key Mismatch** (public key / UUID mismatch)
11. **Quarantine Policy Evasion** (blocked node attempting raw SCADA access)

Every scenario executes an animated 6-stage defensive pipeline:
**INGEST ──> DETECT ──> ANALYZE ──> SCORE ──> DECIDE ──> RESPOND**

---

## 5. API Reference

| Endpoint | Method | Description |
|---|---|---|
| `/api/devices` | GET, POST | List enrolled devices / enroll new hardware node |
| `/api/devices/:id/status` | PATCH | Update device state (`ONLINE`, `QUARANTINED`, `BLOCKED`) |
| `/api/crypto/generate-key` | POST | Generate real OpenSSL keypair for ECDSA/Ed25519/RSA |
| `/api/crypto/benchmark` | GET | Measure empirical cryptographic execution latency |
| `/api/auth/challenge` | POST | Issue 32-byte single-use challenge nonce |
| `/api/auth/verify` | POST | Cryptographically verify signed challenge with replay checks |
| `/api/auth/simulate-flow` | POST | Step-by-step pipeline simulator with tamper injection |
| `/api/zero-trust/evaluate/:id` | GET | Real-time 6-factor Zero-Trust evaluation & policy decision |
| `/api/ai/telemetry/:id` | GET | 10-feature telemetry vector & anomaly score |
| `/api/threats` | GET | Active security incident queue |
| `/api/threats/:id/contain` | PATCH | Mark threat as contained with forensic notes |
| `/api/attacks/scenarios` | GET | List 11 defensive simulation scenarios |
| `/api/attacks/run` | POST | Execute single defensive scenario |
| `/api/attacks/run-all` | POST | Batch execute all 11 scenarios |
| `/api/audit` | GET | Query tamper-evident security audit trail |
| `/api/audit/export` | GET | Export audit records in CSV or JSON format |
| `/api/system/health` | GET | SOC component health and memory telemetry |
| `/api/demo/run-e2e` | POST | Execute 14-step automated Zero-Trust lifecycle demo |
| `/api/search` | GET | Global search across devices, threats, and audit logs |
| `/api/reset` | POST | Reset fleet database to initial state |

---

## 6. How to Run

### Installation & Development
```bash
# 1. Install dependencies
npm install

# 2. Run backend and frontend together
npm run dev

# 3. Access SOC dashboard
# http://localhost:3000
```

### Run Automated Security Test Suite
```bash
npx tsx test/security.test.ts
```

### Production Build
```bash
npm run build
npm start
```
