import React, { useState, useEffect } from 'react';
import {
  BrainCircuit,
  AlertTriangle,
  Activity,
  Zap,
  TrendingUp,
  Cpu,
  RotateCcw,
  BarChart2,
  Info,
  ShieldCheck,
  ShieldAlert,
  Layers,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
} from 'recharts';
import type { AIDetectionResult, Device } from '../../types/index.ts';
import { fetchDeviceTelemetry, simulateTelemetrySpike } from '../../services/api.ts';

interface AiSecurityViewProps {
  devices: Device[];
  onRefresh: () => void;
}

export const AiSecurityView: React.FC<AiSecurityViewProps> = ({ devices, onRefresh }) => {
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>(
    devices.find((d) => d.status === 'SUSPICIOUS')?.id || devices[0]?.id || 'IOT-PLC-ACT-12'
  );
  const [loading, setLoading] = useState(false);
  const [detectionData, setDetectionData] = useState<{
    telemetry: Device['telemetry'];
    detection: AIDetectionResult;
  } | null>(null);
  const [spikeLoading, setSpikeLoading] = useState(false);

  const selectedDevice = devices.find((d) => d.id === selectedDeviceId) || devices[0];

  const loadTelemetry = async (devId: string) => {
    setLoading(true);
    try {
      const data = await fetchDeviceTelemetry(devId);
      setDetectionData(data);
    } catch (err) {
      console.error('AI telemetry error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedDeviceId) {
      loadTelemetry(selectedDeviceId);
    }
  }, [selectedDeviceId]);

  const handleInjectSpike = async (spikeType: 'TRAFFIC' | 'COMMAND_SURGE' | 'AUTH_BURST') => {
    setSpikeLoading(true);
    try {
      await simulateTelemetrySpike({
        deviceId: selectedDeviceId,
        spikeType,
      });
      await loadTelemetry(selectedDeviceId);
      onRefresh();
    } catch (err) {
      console.error('Spike simulation error:', err);
    } finally {
      setSpikeLoading(false);
    }
  };

  // Fleet anomaly scatter/bar comparison for all devices
  const fleetAnomalyChartData = devices.map((d) => {
    let score = d.riskScore;
    let zone = 'Normal';
    if (score >= 65) zone = 'Anomalous';
    else if (score >= 35) zone = 'Suspicious';

    return {
      name: d.name.slice(0, 14),
      fullId: d.id,
      score,
      zone,
      fill: score >= 65 ? '#C47A5A' : score >= 35 ? '#E8DCC8' : '#2B5D87',
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Cybersecurity Analytics</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#E8DCC8] font-mono bg-[#E8DCC8]/15 border border-[#E8DCC8]/30 px-2 py-0.5 rounded">
              DEMO / SYNTHETIC TELEMETRY
            </span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            AI SECURITY POSTURE — Behavioral Anomaly & Explainability Center
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Unsupervised Isolation Forest algorithm models 10-dimensional metric vectors against a synthetic nominal distribution. Identifies out-of-distribution compromised edge devices with transparent attribution.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDeviceId}
            onChange={(e) => setSelectedDeviceId(e.target.value)}
            className="bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.id}) - {d.status}
              </option>
            ))}
          </select>

          <button
            onClick={() => loadTelemetry(selectedDeviceId)}
            disabled={loading}
            className="p-2 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0] cursor-pointer"
            title="Refresh telemetry"
          >
            <RotateCcw size={15} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 1. AI SECURITY POSTURE & MODEL STATUS GAUGE                    */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase">Inference Engine</div>
          <div className="text-base font-bold text-[#FAF7F0] mt-1">Isolation Forest</div>
          <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5">Multivariate Ensembles</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase">Detector Status</div>
          <div className="text-base font-bold text-[#E8DCC8] flex items-center gap-1.5 mt-1 font-mono">
            <span className="w-2 h-2 rounded-full bg-[#E8DCC8] animate-pulse" />
            ACTIVE
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Continuous Ingestion</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase">Synthetic Baseline</div>
          <div className="text-base font-bold text-[#FAF7F0] mt-1 font-mono">10,000 Cycles</div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Hardware-calibrated</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase">Flagged Anomaly Cutoff</div>
          <div className="text-base font-bold text-[#C47A5A] mt-1 font-mono">&gt; 60 / 100 Index</div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Automated policy trigger</div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. ANOMALY CLASSIFICATION CHART (NORMAL, SUSPICIOUS, ANOMALOUS)*/}
      {/* ============================================================== */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-xs font-semibold text-[#FAF7F0]">Fleet Behavioral Anomaly Spectrum</h3>
            <p className="text-xs text-[#C8BDAA] mt-0.5">
              Normal (&lt;35), Suspicious (35–64), and Anomalous (&ge;65) classification zones.
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-[#2B5D87]" /> Normal (&lt;35)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-[#E8DCC8]" /> Suspicious (35-64)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-[#C47A5A]" /> Anomalous (&ge;65)
            </span>
          </div>
        </div>

        <div className="h-56 pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={fleetAnomalyChartData} margin={{ top: 15, right: 10, left: -20, bottom: 20 }}>
              <XAxis dataKey="name" stroke="#C8BDAA" fontSize={10} tickLine={false} interval={0} angle={-15} textAnchor="end" />
              <YAxis stroke="#C8BDAA" fontSize={10} tickLine={false} domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#08182D',
                  borderColor: '#294563',
                  fontSize: '11px',
                  color: '#FAF7F0',
                }}
              />
              <ReferenceLine y={65} stroke="#C47A5A" strokeDasharray="3 3" label={{ value: 'Anomalous Cutoff (65)', fill: '#C47A5A', fontSize: 10 }} />
              <ReferenceLine y={35} stroke="#E8DCC8" strokeDasharray="3 3" label={{ value: 'Suspicious (35)', fill: '#E8DCC8', fontSize: 10 }} />
              <Bar dataKey="score" radius={[4, 4, 0, 0]} name="Anomaly Score">
                {fleetAnomalyChartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 3. "WHY WAS THIS DEVICE FLAGGED?" EXPLAINABILITY PANEL        */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Anomaly Score Card */}
        <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-[#FAF7F0]">Selected Node Anomaly</span>
              <span className="text-[11px] font-mono text-[#C8BDAA]">{selectedDevice?.name}</span>
            </div>

            <div className="mt-4 flex items-baseline gap-3">
              <span className="text-4xl font-bold font-mono tabular-nums text-[#FAF7F0]">
                {detectionData ? detectionData.detection.anomalyScore : '—'}
              </span>
              <span className="text-xs text-[#C8BDAA] font-mono">/ 100</span>
              {detectionData && (
                <span
                  className={`text-xs font-semibold font-mono uppercase ml-auto ${
                    detectionData.detection.isAnomaly ? 'text-[#C47A5A]' : 'text-[#E8DCC8]'
                  }`}
                >
                  {detectionData.detection.isAnomaly ? 'ANOMALOUS (FLAGGED)' : 'NOMINAL (TRUSTED)'}
                </span>
              )}
            </div>

            <p className="text-xs text-[#C8BDAA] mt-2 leading-relaxed">
              Anomaly score is derived from tree-path isolation depth in 10-dimensional metric hyperspace. Scores &gt; 60 trigger automated Zero-Trust policy review.
            </p>
          </div>

          <div className="pt-3 border-t border-[#294563]/60 space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-[#C8BDAA]">Statistical Confidence:</span>
              <span className="text-[#E8DCC8] font-bold tabular-nums">
                {detectionData ? `${detectionData.detection.confidence}%` : '—'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#C8BDAA]">Sampling Interval:</span>
              <span className="text-[#FAF7F0]">10s Rolling Frame</span>
            </div>
          </div>
        </div>

        {/* Explainability Breakdown Card */}
        <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BrainCircuit size={16} className="text-[#2B5D87]" />
              <h3 className="text-xs font-semibold text-[#FAF7F0]">
                WHY WAS THIS DEVICE FLAGGED?
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#E8DCC8]">Shapley Feature Contributions</span>
          </div>

          <p className="text-xs text-[#C8BDAA]">
            Transparent explanation showing which metric deviations contributed most heavily to the anomaly score.
          </p>

          <div className="space-y-3">
            {detectionData ? (
              detectionData.detection.explainability.map((exp, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium text-[#FAF7F0]">{exp.factor}</span>
                    <span className="font-mono tabular-nums text-[#FAF7F0] font-semibold">
                      {exp.percentage}%
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#08182D] rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        exp.impact === 'CRITICAL'
                          ? 'bg-[#C47A5A]'
                          : exp.impact === 'HIGH'
                          ? 'bg-[#C47A5A]/85'
                          : exp.impact === 'MEDIUM'
                          ? 'bg-[#2B5D87]'
                          : 'bg-[#E8DCC8]'
                      }`}
                      style={{ width: `${exp.percentage}%` }}
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-[#C8BDAA]">Loading feature weights...</div>
            )}
          </div>

          {/* Anomaly Injection Simulator */}
          <div className="pt-3 border-t border-[#294563]/60 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-semibold text-[#FAF7F0]">Inject Simulated Telemetry Spike:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleInjectSpike('COMMAND_SURGE')}
                disabled={spikeLoading}
                className="px-2.5 py-1 text-xs rounded bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#C47A5A] transition-colors cursor-pointer"
              >
                Command Surge (18/min)
              </button>
              <button
                onClick={() => handleInjectSpike('TRAFFIC')}
                disabled={spikeLoading}
                className="px-2.5 py-1 text-xs rounded bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#C47A5A] transition-colors cursor-pointer"
              >
                Exfiltration (38KB)
              </button>
              <button
                onClick={() => handleInjectSpike('AUTH_BURST')}
                disabled={spikeLoading}
                className="px-2.5 py-1 text-xs rounded bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#C47A5A] transition-colors cursor-pointer"
              >
                Auth Burst (4x)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
