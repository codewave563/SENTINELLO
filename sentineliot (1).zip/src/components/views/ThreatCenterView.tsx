import React, { useState } from 'react';
import {
  AlertTriangle,
  ShieldAlert,
  Search,
  CheckCircle2,
  Filter,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Clock,
  Radio,
  FileText,
  Activity,
  UserCheck,
} from 'lucide-react';
import type { ThreatEvent, ThreatSeverity, ThreatStatus, AuditLog } from '../../types/index.ts';
import { RiskBadge } from '../ui/RiskBadge.tsx';
import { Drawer } from '../ui/Drawer.tsx';
import { containThreat } from '../../services/api.ts';

interface ThreatCenterViewProps {
  threats: ThreatEvent[];
  auditLogs?: AuditLog[];
  onRefresh: () => void;
}

export const ThreatCenterView: React.FC<ThreatCenterViewProps> = ({
  threats,
  auditLogs = [],
  onRefresh,
}) => {
  const [selectedThreat, setSelectedThreat] = useState<ThreatEvent | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');
  const [containLoading, setContainLoading] = useState(false);
  const [analystNotes, setAnalystNotes] = useState('');

  // Counts by severity
  const criticalCount = threats.filter((t) => t.severity === 'CRITICAL').length;
  const highCount = threats.filter((t) => t.severity === 'HIGH').length;
  const mediumCount = threats.filter((t) => t.severity === 'MEDIUM').length;
  const lowCount = threats.filter((t) => t.severity === 'LOW').length;

  const filteredThreats = threats.filter((t) => {
    const matchesSearch =
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.deviceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSeverity =
      severityFilter === 'ALL' || t.severity === severityFilter;

    return matchesSearch && matchesSeverity;
  });

  const handleContain = async (threatId: string) => {
    setContainLoading(true);
    try {
      const updated = await containThreat(threatId, analystNotes || undefined);
      setSelectedThreat(updated);
      setAnalystNotes('');
      onRefresh();
    } catch (err) {
      console.error('Contain threat error:', err);
    } finally {
      setContainLoading(false);
    }
  };

  // Related audit events for selected threat
  const relatedAuditLogs = selectedThreat
    ? auditLogs.filter(
        (l) =>
          l.deviceId === selectedThreat.deviceId ||
          l.details.includes(selectedThreat.id) ||
          l.event.includes(selectedThreat.category)
      )
    : [];

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Incident Center</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">SOC Threat Investigation</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            ACTIVE THREATS & SECURITY INCIDENT QUEUE
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Real-time correlated security detections flagged by cryptographic gates, replay protection monitors, and AI behavioral anomaly algorithms.
          </p>
        </div>

        <button
          onClick={onRefresh}
          className="p-2 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0] cursor-pointer"
          title="Refresh threats"
        >
          <RotateCcw size={15} />
        </button>
      </div>

      {/* ============================================================== */}
      {/* 1. ACTIVE THREATS SUMMARY (CRITICAL, HIGH, MEDIUM, LOW)        */}
      {/* ============================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div
          onClick={() => setSeverityFilter(severityFilter === 'CRITICAL' ? 'ALL' : 'CRITICAL')}
          className={`p-4 rounded-xl border border-t-4 border-t-[#C47A5A] transition-all cursor-pointer shadow-md ${
            severityFilter === 'CRITICAL'
              ? 'bg-[#102A4D] border-[#C47A5A] ring-1 ring-[#C47A5A]'
              : 'bg-[#0B1F3A] border-[#294563] hover:border-[#C47A5A]'
          }`}
        >
          <div className="text-[11px] font-mono text-[#C47A5A] font-bold uppercase flex items-center justify-between">
            <span>Critical Severity</span>
            <Radio size={12} className="text-[#C47A5A] animate-pulse" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#C47A5A] tabular-nums mt-1">
            {criticalCount}
          </div>
          <div className="text-[10px] text-[#C47A5A] font-mono mt-0.5 font-medium">Immediate containment</div>
        </div>

        <div
          onClick={() => setSeverityFilter(severityFilter === 'HIGH' ? 'ALL' : 'HIGH')}
          className={`p-4 rounded-xl border border-t-4 border-t-[#C47A5A] transition-all cursor-pointer shadow-md ${
            severityFilter === 'HIGH'
              ? 'bg-[#102A4D] border-[#C47A5A] ring-1 ring-[#C47A5A]'
              : 'bg-[#0B1F3A] border-[#294563] hover:border-[#C47A5A]'
          }`}
        >
          <div className="text-[11px] font-mono text-[#C47A5A] uppercase font-semibold flex items-center justify-between">
            <span>High Severity</span>
            <AlertTriangle size={12} className="text-[#C47A5A]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#FAF7F0] tabular-nums mt-1">
            {highCount}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Restricted policy</div>
        </div>

        <div
          onClick={() => setSeverityFilter(severityFilter === 'MEDIUM' ? 'ALL' : 'MEDIUM')}
          className={`p-4 rounded-xl border border-t-4 border-t-[#E8DCC8] transition-all cursor-pointer shadow-md ${
            severityFilter === 'MEDIUM'
              ? 'bg-[#102A4D] border-[#E8DCC8] ring-1 ring-[#E8DCC8]'
              : 'bg-[#0B1F3A] border-[#294563] hover:border-[#E8DCC8]'
          }`}
        >
          <div className="text-[11px] font-mono text-[#E8DCC8] uppercase font-semibold flex items-center justify-between">
            <span>Medium Severity</span>
            <ShieldAlert size={12} className="text-[#E8DCC8]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#E8DCC8] tabular-nums mt-1">
            {mediumCount}
          </div>
          <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5">Step-up auth</div>
        </div>

        <div
          onClick={() => setSeverityFilter(severityFilter === 'LOW' ? 'ALL' : 'LOW')}
          className={`p-4 rounded-xl border border-t-4 border-t-[#2B5D87] transition-all cursor-pointer shadow-md ${
            severityFilter === 'LOW'
              ? 'bg-[#102A4D] border-[#2B5D87] ring-1 ring-[#2B5D87]'
              : 'bg-[#0B1F3A] border-[#294563] hover:border-[#2B5D87]'
          }`}
        >
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase font-semibold flex items-center justify-between">
            <span>Low Severity</span>
            <CheckCircle2 size={12} className="text-[#2B5D87]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#FAF7F0] tabular-nums mt-1">
            {lowCount}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Informational telemetry</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0B1F3A] border border-[#294563] p-4 rounded-lg">
        <div className="relative flex-1 max-w-md">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#2B5D87]" />
          <input
            type="text"
            placeholder="Search threats by ID, device, category, or mechanism..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-1.5 pl-8 text-xs text-[#FAF7F0] placeholder-[#C8BDAA]/50 focus:outline-hidden focus:border-[#2B5D87]"
          />
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((sev) => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                severityFilter === sev
                  ? 'bg-[#2B5D87] text-[#FAF7F0]'
                  : 'bg-[#08182D] text-[#C8BDAA] hover:text-[#FAF7F0]'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* Threat Table */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#294563] bg-[#08182D]/80 text-[#C8BDAA] font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">Threat ID</th>
                <th className="py-3 px-4">Device</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4 text-right">Risk Score</th>
                <th className="py-3 px-4">Detected</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Response</th>
                <th className="py-3 px-4 text-right">Investigate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#294563]/40">
              {filteredThreats.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-xs text-[#C8BDAA]">
                    No security threats match the specified filter criteria.
                  </td>
                </tr>
              ) : (
                filteredThreats.map((threat) => {
                  const isContained = threat.status === 'CONTAINED' || threat.status === 'RESOLVED';
                  return (
                    <tr
                      key={threat.id}
                      onClick={() => setSelectedThreat(threat)}
                      className="hover:bg-[#102A4D]/60 transition-colors cursor-pointer group"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-[#FAF7F0] whitespace-nowrap">
                        {threat.id}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#FAF7F0] group-hover:text-[#E8DCC8] transition-colors">
                          {threat.deviceName}
                        </div>
                        <div className="text-[10px] text-[#C8BDAA] font-mono">{threat.deviceId}</div>
                      </td>

                      <td className="py-3 px-4 font-mono font-medium text-[#FAF7F0]">
                        {threat.category}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <RiskBadge level={threat.severity} showScore={false} />
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums text-[#FAF7F0] font-bold">
                        <span className={threat.riskScore >= 75 ? 'text-[#C47A5A]' : 'text-[#FAF7F0]'}>
                          {threat.riskScore}
                        </span>
                        <span className="text-[10px] text-[#C8BDAA]">/100</span>
                      </td>

                      <td className="py-3 px-4 text-[11px] text-[#C8BDAA] font-mono whitespace-nowrap tabular-nums">
                        {new Date(threat.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`font-mono text-xs uppercase font-bold px-2 py-0.5 rounded border ${
                            isContained
                              ? 'bg-[#E8DCC8]/10 text-[#E8DCC8] border-[#E8DCC8]/30'
                              : 'bg-[#C47A5A]/15 text-[#C47A5A] border-[#C47A5A]/40'
                          }`}
                        >
                          {threat.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap font-mono text-[11px] text-[#E8DCC8]">
                        {threat.responseAction}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedThreat(threat);
                          }}
                          className="px-2.5 py-1 rounded bg-[#08182D] border border-[#294563] text-[11px] text-[#C8BDAA] hover:text-[#FAF7F0] hover:border-[#2B5D87] transition-colors cursor-pointer"
                        >
                          Investigate
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. THREAT INVESTIGATION DRAWER WITH 6-STAGE TIMELINE (SEC 12)  */}
      {/* ============================================================== */}
      <Drawer
        isOpen={!!selectedThreat}
        onClose={() => setSelectedThreat(null)}
        title={selectedThreat ? `Incident Investigation: ${selectedThreat.id}` : 'Threat Details'}
        subtitle={selectedThreat ? `${selectedThreat.category} on ${selectedThreat.deviceName}` : ''}
        width="max-w-2xl"
      >
        {selectedThreat && (
          <div className="space-y-6 text-xs">
            {/* Incident Header Stats */}
            <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase">Severity Tier</span>
                <div className="mt-1 font-bold text-[#C47A5A]">{selectedThreat.severity}</div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase">Risk Calculation</span>
                <div className="mt-1 font-bold text-[#FAF7F0]">{selectedThreat.riskScore} / 100</div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase">Lifecycle Status</span>
                <div className="mt-1 font-bold text-[#E8DCC8]">{selectedThreat.status}</div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase">Response Policy</span>
                <div className="mt-1 font-bold text-[#E8DCC8]">{selectedThreat.responseAction}</div>
              </div>
            </div>

            {/* Narrative Description & Root Cause */}
            <div className="space-y-2">
              <h4 className="font-semibold text-[#FAF7F0]">Incident Narrative & Telemetry Root Cause</h4>
              <div className="p-3.5 bg-[#08182D] border border-[#294563] rounded-lg text-[#FAF7F0] leading-relaxed">
                {selectedThreat.description}
              </div>
            </div>

            {/* Target Hardware Context */}
            <div className="space-y-2">
              <h4 className="font-semibold text-[#FAF7F0]">Affected IoT Device Profile</h4>
              <div className="p-3 bg-[#08182D] border border-[#294563] rounded-lg space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#C8BDAA]">Device Name:</span>
                  <span className="text-[#FAF7F0] font-bold">{selectedThreat.deviceName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#C8BDAA]">Device UUID / ID:</span>
                  <span className="text-[#FAF7F0]">{selectedThreat.deviceId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#C8BDAA]">First Ingested:</span>
                  <span className="text-[#E8DCC8]">{new Date(selectedThreat.timestamp).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* ========================================================== */}
            {/* 6-STAGE THREAT INVESTIGATION TIMELINE (SECTION 12)         */}
            {/* ========================================================== */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-[#FAF7F0]">Threat Investigation Progression Timeline</h4>
                <span className="text-[10px] font-mono text-[#E8DCC8]">Automated SOC Pipeline</span>
              </div>

              <div className="space-y-3 border-l-2 border-[#294563] ml-3 pl-4">
                {(selectedThreat.investigationTimeline || []).map((stage, idx) => (
                  <div key={stage.stage} className="relative space-y-1">
                    {/* Step marker dot */}
                    <div
                      className={`absolute -left-[23px] top-1 w-3.5 h-3.5 rounded-full border-2 ${
                        stage.status === 'COMPLETED'
                          ? 'bg-[#E8DCC8] border-[#08182D]'
                          : stage.status === 'IN_PROGRESS'
                          ? 'bg-[#C47A5A] border-[#08182D] animate-ping'
                          : 'bg-[#294563] border-[#08182D]'
                      }`}
                    />

                    <div className="flex items-center justify-between">
                      <span className="font-bold font-mono text-xs text-[#FAF7F0]">
                        0{idx + 1}. {stage.label}
                      </span>
                      <span className="text-[10px] font-mono text-[#C8BDAA] tabular-nums">
                        {new Date(stage.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#C8BDAA] leading-relaxed">
                      {stage.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Containment Resolution Notes */}
            <div className="space-y-2">
              <h4 className="font-semibold text-[#FAF7F0]">Forensic Containment Notes</h4>
              <div className="p-3 bg-[#08182D] border border-[#294563] rounded text-[#C8BDAA]">
                {selectedThreat.investigationNotes || 'No manual forensic notes entered yet.'}
              </div>
            </div>

            {/* Related Audit Events */}
            {relatedAuditLogs.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold text-[#FAF7F0]">Related Forensic Audit Events ({relatedAuditLogs.length})</h4>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {relatedAuditLogs.map((l) => (
                    <div key={l.id} className="p-2 bg-[#08182D] border border-[#294563]/60 rounded text-[11px] flex justify-between gap-2">
                      <span className="font-mono text-[#FAF7F0] font-semibold">{l.event}</span>
                      <span className="text-[#C8BDAA] truncate max-w-xs">{l.details}</span>
                      <span className="font-mono text-[#E8DCC8] text-[10px] shrink-0">{l.result}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Box: Mark Contained */}
            {selectedThreat.status !== 'CONTAINED' && selectedThreat.status !== 'RESOLVED' && (
              <div className="space-y-3 pt-3 border-t border-[#294563]">
                <h4 className="font-semibold text-[#FAF7F0]">Verify & Enforce Threat Containment</h4>
                <textarea
                  rows={2}
                  placeholder="Enter analyst resolution notes (e.g. VLAN 99 partition verified, keys rotated, rate-limit enforced)..."
                  value={analystNotes}
                  onChange={(e) => setAnalystNotes(e.target.value)}
                  className="w-full bg-[#08182D] border border-[#294563] rounded p-2 text-xs text-[#FAF7F0] placeholder-[#C8BDAA]/50 focus:outline-hidden focus:border-[#2B5D87]"
                />
                <button
                  onClick={() => handleContain(selectedThreat.id)}
                  disabled={containLoading}
                  className="w-full py-2.5 rounded-lg text-xs font-semibold bg-[#2B5D87] text-[#FAF7F0] hover:bg-[#2B5D87]/80 transition-colors cursor-pointer"
                >
                  {containLoading ? 'Updating Incident Record...' : 'Confirm Containment & Mark Contained'}
                </button>
              </div>
            )}
          </div>
        )}
      </Drawer>
    </div>
  );
};
