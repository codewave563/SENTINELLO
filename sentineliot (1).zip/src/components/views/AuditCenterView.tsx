import React, { useState } from 'react';
import {
  FileText,
  Download,
  Search,
  Filter,
  RotateCcw,
  CheckCircle2,
  ShieldAlert,
  AlertTriangle,
  Info,
} from 'lucide-react';
import type { AuditLog, Device } from '../../types/index.ts';

interface AuditCenterViewProps {
  auditLogs: AuditLog[];
  devices: Device[];
  onRefresh: () => void;
}

export const AuditCenterView: React.FC<AuditCenterViewProps> = ({
  auditLogs,
  devices,
  onRefresh,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [sourceFilter, setSourceFilter] = useState('ALL');

  const filteredLogs = auditLogs.filter((log) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      log.event.toLowerCase().includes(q) ||
      log.details.toLowerCase().includes(q) ||
      (log.deviceName && log.deviceName.toLowerCase().includes(q)) ||
      (log.deviceId && log.deviceId.toLowerCase().includes(q));

    const matchesSeverity =
      severityFilter === 'ALL' || log.severity === severityFilter;

    const matchesSource =
      sourceFilter === 'ALL' || log.source === sourceFilter;

    return matchesSearch && matchesSeverity && matchesSource;
  });

  const handleExport = (format: 'csv' | 'json') => {
    window.open(`/api/audit/export?format=${format}`, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Compliance & Forensics</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">Immutable Audit Trail</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            Cryptographic Security Event & Policy Audit Ledger
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Append-only verification records documenting cryptographic key creation, mutual authentication challenges, AI anomaly detections, and Zero-Trust quarantine events.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleExport('csv')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#2B5D87] transition-colors"
          >
            <Download size={13} />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => handleExport('json')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#2B5D87] transition-colors"
          >
            <Download size={13} />
            <span>Export JSON</span>
          </button>
          <button
            onClick={onRefresh}
            className="p-1.5 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0]"
            title="Refresh logs"
          >
            <RotateCcw size={15} />
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0B1F3A] border border-[#294563] p-4 rounded-lg text-xs">
        <div className="relative flex-1 max-w-md">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#2B5D87]" />
          <input
            type="text"
            placeholder="Search audit records by event, device, or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-1.5 pl-8 text-xs text-[#FAF7F0] placeholder-[#C8BDAA]/50 focus:outline-hidden focus:border-[#2B5D87]"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="bg-[#08182D] border border-[#294563] rounded px-2.5 py-1 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
          >
            <option value="ALL">Severity: All</option>
            <option value="CRITICAL">Critical</option>
            <option value="WARNING">Warning</option>
            <option value="INFO">Info</option>
          </select>

          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            className="bg-[#08182D] border border-[#294563] rounded px-2.5 py-1 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
          >
            <option value="ALL">Source: All</option>
            <option value="AUTH_SERVICE">Auth Service</option>
            <option value="CRYPTO_ENGINE">Crypto Engine</option>
            <option value="ZERO_TRUST">Zero Trust</option>
            <option value="AI_ENGINE">AI Engine</option>
            <option value="ATTACK_SIM">Attack Sim</option>
            <option value="SOC_ADMIN">SOC Admin</option>
          </select>
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#294563] bg-[#08182D]/60 text-[#C8BDAA] font-mono text-[11px] uppercase">
                <th className="py-3 px-4">Audit ID</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Event</th>
                <th className="py-3 px-4">Associated Node</th>
                <th className="py-3 px-4">Source Component</th>
                <th className="py-3 px-4">Outcome</th>
                <th className="py-3 px-4">Forensic Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#294563]/40">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-xs text-[#C8BDAA]">
                    No audit records match the selected filters.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((log) => {
                  return (
                    <tr key={log.id} className="hover:bg-[#102A4D]/50 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-[#FAF7F0] whitespace-nowrap">
                        {log.id}
                      </td>

                      <td className="py-3 px-4 font-mono text-[11px] text-[#C8BDAA] tabular-nums whitespace-nowrap">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>

                      <td className="py-3 px-4 font-mono font-semibold text-[#FAF7F0]">
                        {log.event}
                      </td>

                      <td className="py-3 px-4">
                        {log.deviceName ? (
                          <div>
                            <div className="text-[#FAF7F0] font-medium">{log.deviceName}</div>
                            <div className="text-[10px] text-[#C8BDAA] font-mono">{log.deviceId}</div>
                          </div>
                        ) : (
                          <span className="text-[#C8BDAA] italic">System Fleet</span>
                        )}
                      </td>

                      <td className="py-3 px-4 font-mono text-[11px] text-[#E8DCC8]">
                        {log.source}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`font-mono text-xs font-semibold ${
                            log.result === 'SUCCESS'
                              ? 'text-[#E8DCC8]'
                              : log.result === 'BLOCKED' || log.result === 'DENIED'
                              ? 'text-[#C47A5A]'
                              : 'text-[#2B5D87]'
                          }`}
                        >
                          {log.result}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-[#C8BDAA] max-w-md">
                        {log.details}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
