import React, { useState } from 'react';
import {
  Server,
  Plus,
  Search,
  Filter,
  ShieldAlert,
  ShieldCheck,
  Ban,
  RotateCcw,
  KeyRound,
  Activity,
  Cpu,
  ArrowRight,
  ExternalLink,
  Lock,
  Layers,
  FileText,
  AlertTriangle,
  History,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import type { CryptoAlgorithm, Device, DeviceStatus, RiskLevel, ThreatEvent, AuditLog } from '../../types/index.ts';
import { StatusBadge } from '../ui/StatusBadge.tsx';
import { RiskBadge } from '../ui/RiskBadge.tsx';
import { Drawer } from '../ui/Drawer.tsx';
import { Modal } from '../ui/Modal.tsx';
import { registerDevice, updateDeviceStatus } from '../../services/api.ts';

interface DevicesViewProps {
  devices: Device[];
  threats?: ThreatEvent[];
  auditLogs?: AuditLog[];
  onRefresh: () => void;
  onNavigateToAuth: (deviceId: string) => void;
  initialStatusFilter?: string;
}

export const DevicesView: React.FC<DevicesViewProps> = ({
  devices,
  threats = [],
  auditLogs = [],
  onRefresh,
  onNavigateToAuth,
  initialStatusFilter = 'ALL',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>(initialStatusFilter);
  const [riskFilter, setRiskFilter] = useState<string>('ALL');
  const [algoFilter, setAlgoFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'name' | 'trust' | 'risk' | 'lastSeen'>('trust');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [drawerTab, setDrawerTab] = useState<'identity' | 'crypto' | 'auth' | 'behaviour' | 'risk' | 'zero-trust' | 'threats-audit'>('identity');

  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [registerLoading, setRegisterLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // New device form state
  const [formData, setFormData] = useState<{
    name: string;
    type: Device['type'];
    ipAddress: string;
    manufacturer: string;
    firmwareVersion: string;
    cryptoAlgorithm: CryptoAlgorithm;
  }>({
    name: '',
    type: 'SENSOR',
    ipAddress: '192.168.10.',
    manufacturer: 'Nordic Semiconductor',
    firmwareVersion: 'v2.1.0',
    cryptoAlgorithm: 'ED25519',
  });

  // Filter devices
  const filteredDevices = devices
    .filter((d) => {
      const matchesSearch =
        d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.ipAddress.includes(searchQuery) ||
        d.manufacturer.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesStatus = statusFilter === 'ALL' || d.status === statusFilter;
      const matchesRisk = riskFilter === 'ALL' || d.riskLevel === riskFilter;
      const matchesAlgo = algoFilter === 'ALL' || d.cryptoAlgorithm === algoFilter;

      return matchesSearch && matchesStatus && matchesRisk && matchesAlgo;
    })
    .sort((a, b) => {
      let comp = 0;
      if (sortBy === 'name') comp = a.name.localeCompare(b.name);
      else if (sortBy === 'trust') comp = a.trustScore - b.trustScore;
      else if (sortBy === 'risk') comp = a.riskScore - b.riskScore;
      else if (sortBy === 'lastSeen') comp = new Date(a.lastSeen).getTime() - new Date(b.lastSeen).getTime();

      return sortOrder === 'desc' ? -comp : comp;
    });

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.ipAddress) return;
    setRegisterLoading(true);
    try {
      const created = await registerDevice(formData);
      setIsRegisterOpen(false);
      setFormData({
        name: '',
        type: 'SENSOR',
        ipAddress: '192.168.10.',
        manufacturer: 'Nordic Semiconductor',
        firmwareVersion: 'v2.1.0',
        cryptoAlgorithm: 'ED25519',
      });
      onRefresh();
      setSelectedDevice(created);
    } catch (err) {
      console.error('Registration failed:', err);
    } finally {
      setRegisterLoading(false);
    }
  };

  const handleStatusChange = async (deviceId: string, newStatus: DeviceStatus, reason?: string) => {
    setActionLoading(deviceId);
    try {
      const updated = await updateDeviceStatus(deviceId, newStatus, reason);
      onRefresh();
      if (selectedDevice?.id === deviceId) {
        setSelectedDevice(updated);
      }
    } catch (err) {
      console.error('Status transition failed:', err);
    } finally {
      setActionLoading(null);
    }
  };

  // Device-specific threats and audit records
  const deviceThreats = selectedDevice
    ? threats.filter((t) => t.deviceId === selectedDevice.id)
    : [];

  const deviceAuditLogs = selectedDevice
    ? auditLogs.filter((l) => l.deviceId === selectedDevice.id)
    : [];

  return (
    <div className="space-y-4">
      {/* Top Banner & Action Header */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Catalog Inventory</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">Hardware Identity Fleet</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            DEVICE FLEET — Cryptographic Asset & Policy Management
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Inventory of registered IoT nodes. Every asset is bound to a dedicated OpenSSL keypair (Ed25519, ECDSA, or RSA) with continuous trust & risk evaluation.
          </p>
        </div>

        <button
          onClick={() => setIsRegisterOpen(true)}
          className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-[#08182D] bg-[#E8DCC8] hover:bg-[#FAF7F0] transition-colors shrink-0 shadow-sm cursor-pointer"
        >
          <Plus size={14} />
          <span>Enroll New Node</span>
        </button>
      </div>

      {/* Advanced Filter and Search Bar */}
      <div className="bg-[#0B1F3A] border border-[#294563] p-4 rounded-lg space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#2B5D87]" />
            <input
              type="text"
              placeholder="Search by device ID, name, manufacturer, or IP..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#08182D] border border-[#294563] rounded-md px-3 py-1.5 pl-8 text-xs text-[#FAF7F0] placeholder-[#C8BDAA]/50 focus:outline-hidden focus:border-[#2B5D87]"
            />
          </div>

          {/* Quick Status Filter Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            {['ALL', 'TRUSTED', 'ONLINE', 'SUSPICIOUS', 'QUARANTINED', 'BLOCKED'].map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  statusFilter === status
                    ? 'bg-[#2B5D87] text-[#FAF7F0]'
                    : 'bg-[#08182D] text-[#C8BDAA] hover:text-[#FAF7F0]'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* Secondary Filters: Risk, Algorithm, Sort */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-[#294563]/60 text-xs text-[#C8BDAA]">
          <div className="flex items-center gap-1.5">
            <span>Risk Tier:</span>
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="bg-[#08182D] border border-[#294563] rounded px-2 py-0.5 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
            >
              <option value="ALL">All Risk Tiers</option>
              <option value="LOW">Low (0-25)</option>
              <option value="MEDIUM">Medium (26-55)</option>
              <option value="HIGH">High (56-79)</option>
              <option value="CRITICAL">Critical (80+)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Algorithm:</span>
            <select
              value={algoFilter}
              onChange={(e) => setAlgoFilter(e.target.value)}
              className="bg-[#08182D] border border-[#294563] rounded px-2 py-0.5 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
            >
              <option value="ALL">All Cryptos</option>
              <option value="ED25519">Ed25519</option>
              <option value="ECDSA_P256">ECDSA P-256</option>
              <option value="RSA_2048">RSA-2048</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 ml-auto">
            <span>Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#08182D] border border-[#294563] rounded px-2 py-0.5 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
            >
              <option value="trust">Trust Score</option>
              <option value="risk">Risk Score</option>
              <option value="name">Device Name</option>
              <option value="lastSeen">Last Active</option>
            </select>
            <button
              onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
              className="px-1.5 py-0.5 rounded bg-[#08182D] border border-[#294563] text-xs text-[#FAF7F0] font-mono hover:border-[#2B5D87]"
              title="Toggle sort direction"
            >
              {sortOrder.toUpperCase()}
            </button>
          </div>
        </div>
      </div>

      {/* High-Density Device Fleet Table */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#294563] bg-[#08182D]/80 text-[#C8BDAA] font-mono text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">Device</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Trust</th>
                <th className="py-3 px-4">Risk</th>
                <th className="py-3 px-4">Crypto Algorithm</th>
                <th className="py-3 px-4">Last Seen</th>
                <th className="py-3 px-4 text-center">Threats</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#294563]/40">
              {filteredDevices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-xs text-[#C8BDAA]">
                    No IoT nodes match the current filter and search settings.
                  </td>
                </tr>
              ) : (
                filteredDevices.map((device) => {
                  const isActionBusy = actionLoading === device.id;
                  const nodeThreatCount = threats.filter((t) => t.deviceId === device.id).length;

                  return (
                    <tr
                      key={device.id}
                      onClick={() => setSelectedDevice(device)}
                      className="hover:bg-[#102A4D]/60 transition-colors group cursor-pointer"
                    >
                      {/* Device ID & Name */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#FAF7F0] group-hover:text-[#E8DCC8] transition-colors">
                          {device.name}
                        </div>
                        <div className="text-[10px] text-[#C8BDAA] font-mono">
                          {device.id} · {device.ipAddress}
                        </div>
                      </td>

                      {/* Type */}
                      <td className="py-3 px-4 font-mono text-[#FAF7F0]">
                        <span className="text-[11px] text-[#FAF7F0] font-semibold">{device.type}</span>
                        <div className="text-[10px] text-[#C8BDAA] font-sans">{device.manufacturer}</div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <StatusBadge status={device.status} />
                      </td>

                      {/* Trust Score */}
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-[#FAF7F0]">
                        <span className={device.trustScore >= 80 ? 'text-[#E8DCC8]' : device.trustScore < 40 ? 'text-[#C47A5A]' : 'text-[#FAF7F0]'}>
                          {device.trustScore}
                        </span>
                        <span className="text-[10px] text-[#C8BDAA]">/100</span>
                      </td>

                      {/* Risk Level */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <RiskBadge level={device.riskLevel} score={device.riskScore} />
                      </td>

                      {/* Crypto Algorithm & Fingerprint */}
                      <td className="py-3 px-4">
                        <div className="font-mono text-[11px] font-semibold text-[#E8DCC8]">
                          {device.cryptoAlgorithm}
                        </div>
                        <div className="text-[10px] text-[#C8BDAA] font-mono truncate max-w-[130px]">
                          {device.keyFingerprint}
                        </div>
                      </td>

                      {/* Last Seen */}
                      <td className="py-3 px-4 font-mono text-[11px] text-[#C8BDAA] whitespace-nowrap tabular-nums">
                        {new Date(device.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>

                      {/* Threats Count */}
                      <td className="py-3 px-4 text-center">
                        {nodeThreatCount > 0 ? (
                          <span className="inline-flex items-center gap-1 font-mono font-bold text-xs text-[#C47A5A] px-2 py-0.5 rounded bg-[#C47A5A]/15 border border-[#C47A5A]/30">
                            {nodeThreatCount}
                          </span>
                        ) : (
                          <span className="font-mono text-xs text-[#C8BDAA]">0</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td
                        className="py-3 px-4 text-right whitespace-nowrap space-x-1.5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => setSelectedDevice(device)}
                          className="px-2.5 py-1 rounded bg-[#08182D] border border-[#294563] text-[11px] text-[#C8BDAA] hover:text-[#FAF7F0] hover:border-[#2B5D87] transition-colors cursor-pointer"
                        >
                          Inspect
                        </button>

                        <button
                          onClick={() => onNavigateToAuth(device.id)}
                          className="px-2.5 py-1 rounded bg-[#08182D] border border-[#294563] text-[11px] text-[#E8DCC8] hover:border-[#E8DCC8] transition-colors cursor-pointer"
                          title="Authenticate Node"
                        >
                          Auth
                        </button>

                        {device.status !== 'QUARANTINED' && device.status !== 'BLOCKED' ? (
                          <button
                            onClick={() => handleStatusChange(device.id, 'QUARANTINED', 'Manual SOC Analyst isolation')}
                            disabled={isActionBusy}
                            className="px-2.5 py-1 rounded bg-[#08182D] border border-[#294563] text-[11px] text-[#C47A5A] hover:border-[#C47A5A] transition-colors cursor-pointer"
                            title="Quarantine Device"
                          >
                            Quarantine
                          </button>
                        ) : (
                          <button
                            onClick={() => handleStatusChange(device.id, 'ONLINE', 'Manual SOC restoration')}
                            disabled={isActionBusy}
                            className="px-2.5 py-1 rounded bg-[#08182D] border border-[#294563] text-[11px] text-[#E8DCC8] hover:border-[#E8DCC8] transition-colors cursor-pointer"
                            title="Restore Device to Online"
                          >
                            Restore
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ============================================================== */}
      {/* PROFESSIONAL SIDE DRAWER WITH 7 COMPREHENSIVE SECTIONS         */}
      {/* ============================================================== */}
      <Drawer
        isOpen={!!selectedDevice}
        onClose={() => setSelectedDevice(null)}
        title={selectedDevice ? `${selectedDevice.name}` : 'Device Details'}
        subtitle={selectedDevice ? `Hardware Identifier: ${selectedDevice.id}` : ''}
        width="max-w-2xl"
      >
        {selectedDevice && (
          <div className="space-y-5 text-xs">
            {/* Top Quick Status Gauge Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3.5 bg-[#08182D] border border-[#294563] rounded-lg">
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase font-mono">Status</span>
                <div className="mt-1"><StatusBadge status={selectedDevice.status} /></div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase font-mono">Trust Score</span>
                <div className="text-sm font-bold font-mono text-[#E8DCC8] mt-1">{selectedDevice.trustScore} / 100</div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase font-mono">Risk Tier</span>
                <div className="mt-1"><RiskBadge level={selectedDevice.riskLevel} score={selectedDevice.riskScore} /></div>
              </div>
              <div>
                <span className="text-[10px] text-[#C8BDAA] uppercase font-mono">Firmware Age</span>
                <div className="text-xs font-mono text-[#FAF7F0] mt-1">{selectedDevice.firmwareAgeMonths} months</div>
              </div>
            </div>

            {/* Navigation Tabs for Drawer */}
            <div className="flex items-center gap-1 border-b border-[#294563] pb-2 overflow-x-auto text-[11px]">
              {[
                { id: 'identity', label: 'Identity' },
                { id: 'crypto', label: 'Cryptography' },
                { id: 'auth', label: 'Authentication' },
                { id: 'behaviour', label: 'Behaviour' },
                { id: 'risk', label: 'Risk' },
                { id: 'zero-trust', label: 'Zero Trust' },
                { id: 'threats-audit', label: `Threats & Audit (${deviceThreats.length})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setDrawerTab(tab.id as any)}
                  className={`px-2.5 py-1 rounded font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    drawerTab === tab.id
                      ? 'bg-[#2B5D87] text-[#FAF7F0]'
                      : 'text-[#C8BDAA] hover:text-[#FAF7F0] hover:bg-[#08182D]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* SECTION 1: IDENTITY */}
            {drawerTab === 'identity' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Device ID:</span>
                    <span className="text-[#FAF7F0] font-bold">{selectedDevice.id}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Device Classification:</span>
                    <span className="text-[#FAF7F0]">{selectedDevice.type}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Manufacturer:</span>
                    <span className="text-[#FAF7F0]">{selectedDevice.manufacturer}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Firmware Version:</span>
                    <span className="text-[#E8DCC8]">{selectedDevice.firmwareVersion}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">IP Address:</span>
                    <span className="text-[#FAF7F0]">{selectedDevice.ipAddress}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#C8BDAA]">Enrolled At:</span>
                    <span className="text-[#FAF7F0]">{new Date(selectedDevice.registeredAt).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 2: CRYPTOGRAPHIC IDENTITY */}
            {drawerTab === 'crypto' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Algorithm:</span>
                    <span className="text-[#E8DCC8] font-bold">{selectedDevice.cryptoAlgorithm}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Key Fingerprint:</span>
                    <span className="text-[#FAF7F0] text-[11px] truncate max-w-[280px]">
                      {selectedDevice.keyFingerprint}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Digest Standard:</span>
                    <span className="text-[#FAF7F0]">SHA-256 (FIPS 186-4)</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Signature Status:</span>
                    <span className="text-[#E8DCC8] font-semibold flex items-center gap-1">
                      <CheckCircle2 size={13} /> VERIFIED & BOUND
                    </span>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] block mb-1">Public Key (SPKI PEM):</span>
                    <pre className="p-2.5 bg-[#0B1F3A] border border-[#294563]/60 rounded text-[10px] text-[#C8BDAA] overflow-x-auto select-all max-h-32">
                      {selectedDevice.publicKeyPem}
                    </pre>
                    <p className="text-[10px] text-[#C8BDAA]/60 italic mt-1">
                      * Security Guarantee: Private keys are held in hardware keystore / secure enclave; never exposed to API or UI.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 3: AUTHENTICATION */}
            {drawerTab === 'auth' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Last Authentication:</span>
                    <span className="text-[#FAF7F0]">{new Date(selectedDevice.lastSeen).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Auth Success Rate:</span>
                    <span className="text-[#E8DCC8] font-bold">
                      {Math.round((1 - selectedDevice.telemetry.authFailureRate) * 100)}%
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Failed Challenges:</span>
                    <span className={selectedDevice.telemetry.failedAuthCount > 0 ? 'text-[#C47A5A] font-bold' : 'text-[#FAF7F0]'}>
                      {selectedDevice.telemetry.failedAuthCount} failures
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#C8BDAA]">Session Security:</span>
                    <span className="text-[#E8DCC8]">Single-Use 32B CSPRNG Nonce</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onNavigateToAuth(selectedDevice.id);
                    setSelectedDevice(null);
                  }}
                  className="w-full py-2.5 rounded bg-[#2B5D87] text-[#FAF7F0] font-semibold text-xs hover:bg-[#2B5D87]/80 transition-colors cursor-pointer text-center"
                >
                  Launch Mutual Challenge-Response Testbench
                </button>
              </div>
            )}

            {/* SECTION 4: BEHAVIOUR */}
            {drawerTab === 'behaviour' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="grid grid-cols-2 gap-2.5 p-4 bg-[#08182D] border border-[#294563] rounded-lg font-mono text-xs">
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Request Frequency:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.requestFrequency} req/min</div>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Packet Rate:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.packetFrequency} pkts/sec</div>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Outbound Bytes:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.bytesSent} bytes/min</div>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Unique IP Hosts:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.uniqueDestinations} destinations</div>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Command Rate:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.commandFrequency} cmd/min</div>
                  </div>
                  <div>
                    <span className="text-[#C8BDAA] text-[10px]">Session Duration:</span>
                    <div className="text-xs text-[#FAF7F0] mt-0.5">{selectedDevice.telemetry.sessionDuration} sec</div>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 5: RISK */}
            {drawerTab === 'risk' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#FAF7F0]">Calculated Risk Score</span>
                    <RiskBadge level={selectedDevice.riskLevel} score={selectedDevice.riskScore} />
                  </div>
                  <p className="text-[#C8BDAA] text-[11px] leading-relaxed">
                    Evaluated from AI telemetry deviation, failed authentication attempts, firmware vulnerability exposure, and active threat history.
                  </p>
                </div>
              </div>
            )}

            {/* SECTION 6: ZERO TRUST */}
            {drawerTab === 'zero-trust' && (
              <div className="space-y-3 animate-in fade-in duration-200">
                <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Governing Policy:</span>
                    <span className="text-[#E8DCC8] font-bold">Never Trust. Always Verify.</span>
                  </div>
                  <div className="flex justify-between border-b border-[#294563]/40 pb-1.5">
                    <span className="text-[#C8BDAA]">Enforced Decision:</span>
                    <StatusBadge status={selectedDevice.status} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#C8BDAA]">Overall Trust Index:</span>
                    <span className="text-sm font-bold text-[#FAF7F0]">{selectedDevice.trustScore} / 100</span>
                  </div>
                </div>
              </div>
            )}

            {/* SECTION 7: THREATS & AUDIT */}
            {drawerTab === 'threats-audit' && (
              <div className="space-y-4 animate-in fade-in duration-200">
                {/* Threats */}
                <div className="space-y-2">
                  <span className="font-semibold text-[#FAF7F0] block">Security Incidents ({deviceThreats.length})</span>
                  {deviceThreats.length === 0 ? (
                    <div className="p-3 bg-[#08182D] border border-[#294563] rounded text-[#C8BDAA] text-[11px]">
                      No active security threats logged against this node.
                    </div>
                  ) : (
                    deviceThreats.map((t) => (
                      <div key={t.id} className="p-3 bg-[#08182D] border border-[#294563] rounded space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-[#FAF7F0]">{t.category}</span>
                          <span className="text-[10px] text-[#C47A5A] font-bold uppercase">{t.status}</span>
                        </div>
                        <p className="text-[11px] text-[#C8BDAA]">{t.description}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Audit */}
                <div className="space-y-2">
                  <span className="font-semibold text-[#FAF7F0] block">Recent Audit Records ({deviceAuditLogs.length})</span>
                  {deviceAuditLogs.length === 0 ? (
                    <div className="p-3 bg-[#08182D] border border-[#294563] rounded text-[#C8BDAA] text-[11px]">
                      No audit records for this node.
                    </div>
                  ) : (
                    deviceAuditLogs.slice(0, 4).map((l) => (
                      <div key={l.id} className="p-2.5 bg-[#08182D] border border-[#294563]/60 rounded text-[11px] flex justify-between gap-2">
                        <div>
                          <div className="font-mono text-[#FAF7F0] font-semibold">{l.event}</div>
                          <div className="text-[#C8BDAA] text-[10px] truncate max-w-sm">{l.details}</div>
                        </div>
                        <span className="font-mono text-[#E8DCC8] text-[10px] shrink-0">{l.result}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Quick Isolation / Restoration Controls in Drawer Footer */}
            <div className="pt-3 border-t border-[#294563] flex items-center justify-between gap-3">
              {selectedDevice.status !== 'QUARANTINED' && selectedDevice.status !== 'BLOCKED' ? (
                <button
                  onClick={() => handleStatusChange(selectedDevice.id, 'QUARANTINED', 'Quarantined via Device Drawer')}
                  className="flex-1 py-2 rounded text-xs font-semibold bg-[#08182D] border border-[#C47A5A] text-[#C47A5A] hover:bg-[#C47A5A]/10 transition-colors cursor-pointer"
                >
                  Quarantine Node to VLAN 99
                </button>
              ) : (
                <button
                  onClick={() => handleStatusChange(selectedDevice.id, 'ONLINE', 'Restored via Device Drawer')}
                  className="flex-1 py-2 rounded text-xs font-semibold bg-[#08182D] border border-[#E8DCC8] text-[#E8DCC8] hover:bg-[#E8DCC8]/10 transition-colors cursor-pointer"
                >
                  Restore Access to Online
                </button>
              )}

              <button
                onClick={() => setSelectedDevice(null)}
                className="px-4 py-2 rounded bg-[#08182D] border border-[#294563] text-xs text-[#C8BDAA] hover:text-[#FAF7F0] cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Drawer>

      {/* Enroll Device Modal */}
      <Modal
        isOpen={isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        title="Enroll New IoT Node"
        subtitle="Automatic OpenSSL Key Generation & Zero-Trust Binding"
      >
        <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-[#C8BDAA] mb-1 font-medium">Device Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Boiler Pressure Valve 04"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] focus:border-[#2B5D87] focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[#C8BDAA] mb-1 font-medium">Device Type</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] focus:border-[#2B5D87] focus:outline-hidden font-mono"
              >
                <option value="SENSOR">Sensor</option>
                <option value="GATEWAY">Gateway</option>
                <option value="CONTROLLER">Controller</option>
                <option value="ACTUATOR">Actuator</option>
                <option value="CAMERA">Camera</option>
                <option value="METER">Meter</option>
              </select>
            </div>

            <div>
              <label className="block text-[#C8BDAA] mb-1 font-medium">IP Address</label>
              <input
                type="text"
                required
                value={formData.ipAddress}
                onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] font-mono focus:border-[#2B5D87] focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[#C8BDAA] mb-1 font-medium">Manufacturer</label>
              <input
                type="text"
                value={formData.manufacturer}
                onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
                className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] focus:border-[#2B5D87] focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-[#C8BDAA] mb-1 font-medium">Firmware Version</label>
              <input
                type="text"
                value={formData.firmwareVersion}
                onChange={(e) => setFormData({ ...formData, firmwareVersion: e.target.value })}
                className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] font-mono focus:border-[#2B5D87] focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#C8BDAA] mb-1 font-medium">Cryptographic Algorithm</label>
            <select
              value={formData.cryptoAlgorithm}
              onChange={(e) => setFormData({ ...formData, cryptoAlgorithm: e.target.value as any })}
              className="w-full bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-[#FAF7F0] focus:border-[#2B5D87] focus:outline-hidden font-mono"
            >
              <option value="ED25519">Ed25519 (Curve25519, Fastest, Recommended)</option>
              <option value="ECDSA_P256">ECDSA P-256 (NIST secp256r1, FIPS 186-4)</option>
              <option value="RSA_2048">RSA-2048 (PKCS#1 v1.5 with SHA-256)</option>
            </select>
          </div>

          <div className="pt-3 border-t border-[#294563] flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsRegisterOpen(false)}
              className="px-3 py-1.5 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={registerLoading}
              className="px-4 py-1.5 rounded bg-[#E8DCC8] text-[#08182D] font-semibold hover:bg-[#FAF7F0] transition-colors cursor-pointer"
            >
              {registerLoading ? 'Generating Keys...' : 'Enroll & Generate Identity'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
