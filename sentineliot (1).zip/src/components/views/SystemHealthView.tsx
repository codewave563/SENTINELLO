import React, { useState, useEffect } from 'react';
import {
  Activity,
  CheckCircle2,
  Clock,
  Cpu,
  Database,
  Lock,
  RotateCcw,
  Server,
  Zap,
} from 'lucide-react';
import type { SystemHealth } from '../../types/index.ts';
import { fetchSystemHealth } from '../../services/api.ts';

export const SystemHealthView: React.FC = () => {
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [loading, setLoading] = useState(false);

  const loadHealth = async () => {
    setLoading(true);
    try {
      const data = await fetchSystemHealth();
      setHealth(data);
    } catch (err) {
      console.error('System health error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadHealth();
    const interval = setInterval(loadHealth, 5000);
    return () => clearInterval(interval);
  }, []);

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours}h ${minutes}m ${secs}s`;
  };

  const components = [
    {
      name: 'Cryptographic Engine',
      description: 'OpenSSL Native EVP Primitives (ECDSA, Ed25519, RSA-2048)',
      status: health?.cryptoService || 'OPERATIONAL',
      icon: Lock,
    },
    {
      name: 'AI Anomaly Detector',
      description: 'Isolation Forest Unsupervised Metric Dispersion Model',
      status: health?.mlEngine || 'OPERATIONAL',
      icon: Cpu,
    },
    {
      name: 'Zero-Trust Policy Evaluator',
      description: 'Continuous 6-Factor Dynamic Policy Gatekeeper',
      status: health?.backend || 'OPERATIONAL',
      icon: Activity,
    },
    {
      name: 'Zero-Trust Device Catalog',
      description: 'In-Memory Encrypted State & Single-Use Nonce Store',
      status: health?.database || 'OPERATIONAL',
      icon: Database,
    },
    {
      name: 'REST API & Boundary Gateway',
      description: 'Express SOC Endpoint Dispatcher & Middleware',
      status: health?.apiGateway || 'OPERATIONAL',
      icon: Server,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Telemetry Diagnostics</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">SOC Node Vitality</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            SentinelIoT Infrastructure & Service Health Monitor
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Live telemetry reporting on cryptographic sub-processors, in-memory nonce cache performance, and AI inference latency.
          </p>
        </div>

        <button
          onClick={loadHealth}
          disabled={loading}
          className="p-2 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0]"
          title="Refresh health"
        >
          <RotateCcw size={15} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Vital Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg space-y-1">
          <div className="text-xs text-[#C8BDAA]">Service Uptime</div>
          <div className="text-xl font-bold font-mono text-[#FAF7F0] tabular-nums">
            {health ? formatUptime(health.uptimeSeconds) : '—'}
          </div>
          <div className="text-[11px] text-[#C8BDAA]">Daemon runtime without restart</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg space-y-1">
          <div className="text-xs text-[#C8BDAA]">Processed Security Events</div>
          <div className="text-xl font-bold font-mono text-[#E8DCC8] tabular-nums">
            {health ? health.totalEventsProcessed : '—'}
          </div>
          <div className="text-[11px] text-[#C8BDAA]">Auths, challenges & audit entries</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg space-y-1">
          <div className="text-xs text-[#C8BDAA]">Active Zero-Trust Sessions</div>
          <div className="text-xl font-bold font-mono text-[#FAF7F0] tabular-nums">
            {health ? health.activeSessions : '—'}
          </div>
          <div className="text-[11px] text-[#C8BDAA]">Enrolled hardware devices</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] rounded-lg space-y-1">
          <div className="text-xs text-[#C8BDAA]">Resident Heap Memory</div>
          <div className="text-xl font-bold font-mono text-[#FAF7F0] tabular-nums">
            {health ? `${health.memoryUsageMb} MB` : '—'}
          </div>
          <div className="text-[11px] text-[#C8BDAA]">V8 Node.js memory footprint</div>
        </div>
      </div>

      {/* Component Status Cards */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-[#FAF7F0]">Subsystem Operational Status</h3>
          <span className="text-[11px] font-mono text-[#E8DCC8]">All Engines Nominal</span>
        </div>

        <div className="divide-y divide-[#294563]/40">
          {components.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.name} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded bg-[#08182D] border border-[#294563] text-[#2B5D87]">
                    <Icon size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-[#FAF7F0]">{c.name}</div>
                    <div className="text-[11px] text-[#C8BDAA]">{c.description}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 font-mono text-xs">
                  <CheckCircle2 size={14} className="text-[#E8DCC8]" />
                  <span className="text-[#E8DCC8] font-semibold">{c.status}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
