import React, { useState } from 'react';
import {
  Server,
  ShieldCheck,
  AlertTriangle,
  ShieldAlert,
  Activity,
  CheckCircle2,
  Lock,
  Play,
  RotateCcw,
  Radio,
  FileText,
  TrendingUp,
  TrendingDown,
  Info,
  ArrowUpRight,
  Shield,
  Layers,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import type { AuditLog, AuthAttempt, Device, ThreatEvent } from '../../types/index.ts';
import { StatusBadge } from '../ui/StatusBadge.tsx';
import { RiskBadge } from '../ui/RiskBadge.tsx';

interface OverviewViewProps {
  devices: Device[];
  threats: ThreatEvent[];
  auditLogs: AuditLog[];
  authAttempts: AuthAttempt[];
  onOpenDemo: () => void;
  onNavigateTab: (tab: any, filter?: any) => void;
  onRefresh: () => void;
  isLoading: boolean;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  devices,
  threats,
  auditLogs,
  authAttempts,
  onOpenDemo,
  onNavigateTab,
  onRefresh,
  isLoading,
}) => {
  const [activeTooltip, setActiveTooltip] = useState<string | null>(null);

  // Compute real KPIs from database state
  const totalDevices = devices.length;
  const activeDevices = devices.filter((d) => d.status === 'ONLINE' || d.status === 'TRUSTED').length;
  const trustedDevices = devices.filter((d) => d.status === 'TRUSTED').length;
  const suspiciousDevices = devices.filter((d) => d.status === 'SUSPICIOUS').length;
  const quarantinedDevices = devices.filter((d) => d.status === 'QUARANTINED' || d.status === 'BLOCKED').length;
  const activeThreats = threats.filter((t) => t.status === 'DETECTED' || t.status === 'INVESTIGATING').length;

  const totalAuths = authAttempts.length;
  const successfulAuths = authAttempts.filter((a) => a.result === 'SUCCESS').length;
  const authSuccessRate = totalAuths > 0 ? Math.round((successfulAuths / totalAuths) * 100) : 100;

  const avgRiskScore = totalDevices > 0
    ? Math.round(devices.reduce((acc, d) => acc + d.riskScore, 0) / totalDevices)
    : 0;

  const avgTrustScore = totalDevices > 0
    ? Math.round(devices.reduce((acc, d) => acc + d.trustScore, 0) / totalDevices)
    : 0;

  // Calculate Real Overall Security Posture (0-100)
  // Derived from trust scores, active threats, quarantined nodes, and auth success
  let rawPosture = avgTrustScore;
  if (activeThreats > 0) rawPosture -= activeThreats * 12;
  if (quarantinedDevices > 0) rawPosture -= quarantinedDevices * 6;
  if (authSuccessRate < 100) rawPosture -= (100 - authSuccessRate) * 0.4;
  const securityPostureScore = Math.max(10, Math.min(99, Math.round(rawPosture)));

  let postureLabel = 'OPTIMAL POSTURE';
  let postureDesc = 'All cryptographic validation checks nominal. Zero-Trust constraints satisfied.';
  let postureColor = '#E8DCC8'; // Warm beige
  if (securityPostureScore < 60 || activeThreats >= 2) {
    postureLabel = 'CRITICAL ATTENTION REQUIRED';
    postureDesc = 'Active uncontained threat vectors detected. Strict Zero-Trust quarantine enforced.';
    postureColor = '#C47A5A'; // Burnt copper
  } else if (securityPostureScore < 80 || activeThreats > 0 || quarantinedDevices > 0) {
    postureLabel = 'SECURE WITH ATTENTION';
    postureDesc = `${quarantinedDevices} node isolated to VLAN 99. Continuous AI anomaly monitoring active.`;
    postureColor = '#C47A5A';
  }

  // Semi-circle gauge geometry
  const radius = 80;
  const circumference = Math.PI * radius;
  const strokeDashoffset = circumference - (securityPostureScore / 100) * circumference;

  // Contributing factors to security score
  const postureFactors = [
    {
      title: 'Mutual Cryptographic Authentication',
      value: `${authSuccessRate}% Success`,
      impact: authSuccessRate >= 90 ? 'POSITIVE' : 'NEGATIVE',
      delta: authSuccessRate >= 90 ? '+24 pts' : '-18 pts',
    },
    {
      title: 'Zero-Trust Fleet Compliance',
      value: `${trustedDevices} / ${totalDevices} Nodes Trusted`,
      impact: trustedDevices / (totalDevices || 1) >= 0.5 ? 'POSITIVE' : 'NEUTRAL',
      delta: '+30 pts',
    },
    {
      title: 'Active Security Incidents',
      value: `${activeThreats} Uncontained Threat${activeThreats !== 1 ? 's' : ''}`,
      impact: activeThreats === 0 ? 'POSITIVE' : 'CRITICAL',
      delta: activeThreats === 0 ? '+15 pts' : `-${activeThreats * 12} pts`,
    },
    {
      title: 'Quarantine & VLAN Isolation',
      value: `${quarantinedDevices} Node${quarantinedDevices !== 1 ? 's' : ''} Contained`,
      impact: quarantinedDevices === 0 ? 'POSITIVE' : 'WARNING',
      delta: quarantinedDevices === 0 ? '+10 pts' : `-${quarantinedDevices * 6} pts`,
    },
  ];

  // Chart data: Status distribution
  const statusData = [
    { name: 'Trusted', value: trustedDevices, color: '#E8DCC8' },
    { name: 'Online', value: devices.filter((d) => d.status === 'ONLINE').length, color: '#2B5D87' },
    { name: 'Suspicious', value: suspiciousDevices, color: '#C8BDAA' },
    { name: 'Quarantined', value: quarantinedDevices, color: '#C47A5A' },
  ].filter((item) => item.value > 0);

  // Risk distribution
  const riskGroups = [
    { name: 'Low (0-25)', count: devices.filter((d) => d.riskScore < 26).length },
    { name: 'Med (26-55)', count: devices.filter((d) => d.riskScore >= 26 && d.riskScore < 56).length },
    { name: 'High (56-79)', count: devices.filter((d) => d.riskScore >= 56 && d.riskScore < 80).length },
    { name: 'Crit (80+)', count: devices.filter((d) => d.riskScore >= 80).length },
  ];

  // Auth history timeline
  const authTrendData = [
    { time: '10:00', successful: 8, failed: 0, replayed: 0 },
    { time: '10:15', successful: 12, failed: 1, replayed: 0 },
    { time: '10:30', successful: 14, failed: 2, replayed: 1 },
    { time: '10:45', successful: 11, failed: 0, replayed: 0 },
    { time: '11:00', successful: 16, failed: 1, replayed: 0 },
    { time: 'Live', successful: successfulAuths, failed: totalAuths - successfulAuths, replayed: authAttempts.filter(a => a.result === 'REPLAY_BLOCKED').length },
  ];

  const nowTime = new Date().toISOString().slice(11, 19);

  return (
    <div className="space-y-6">
      {/* ============================================================== */}
      {/* 1. TOP SYSTEM SECURITY POSTURE (CIRCLE REMOVED — TELEMETRY MATRIX) */}
      {/* ============================================================== */}
      <div className="bg-[#EFE8DC] border-2 border-[#D2C3AF] rounded-2xl p-6 sm:p-7 shadow-sm relative overflow-hidden group">
        {/* 4-Color Vibrant Accent Conduit Line */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#0B1F3A] via-[#2B5D87] via-[#C47A5A] to-[#0B1F3A] animate-conduit" />

        {/* Ambient Warm Accents */}
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-[#2B5D87]/10 blur-3xl pointer-events-none" />
        <div className="absolute right-1/3 -bottom-20 w-60 h-60 rounded-full bg-[#C47A5A]/10 blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6 relative z-10">
          {/* Left: Score Readout + Segmented Cyber Telemetry Matrix (NO CIRCLE) */}
          <div className="flex-1 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#923818] font-bold bg-[#C47A5A]/15 border border-[#C47A5A]/40 px-2 py-0.5 rounded shadow-2xs">
                FIPS 186-4 & ZERO-TRUST
              </span>
              <span className="text-xs text-[#968672]">·</span>
              <div className="flex items-center gap-1.5 text-xs font-mono text-[#0B1F3A]">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2B5D87] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#2B5D87]" />
                </span>
                <span className="font-bold">SECURITY ENGINE: ACTIVE</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-baseline gap-4 sm:gap-6">
              {/* Massive Crisp Numeric Readout */}
              <div className="flex items-baseline gap-2 shrink-0">
                <span className="text-5xl sm:text-6xl font-black font-mono tabular-nums text-[#0B1F3A] tracking-tight">
                  {securityPostureScore}
                </span>
                <div className="flex flex-col">
                  <span className="text-xs font-mono font-bold text-[#2B5D87] tracking-wider uppercase">
                    / 100 POSTURE
                  </span>
                  <span className="text-[11px] font-mono font-bold text-[#923818] uppercase tracking-wider">
                    {postureLabel}
                  </span>
                </div>
              </div>

              {/* Status Header & Description */}
              <div className="space-y-1">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight text-[#0B1F3A] flex items-center gap-2">
                  {securityPostureScore >= 80 ? (
                    <ShieldCheck size={20} className="text-[#2B5D87] shrink-0" />
                  ) : (
                    <ShieldAlert size={20} className="text-[#C47A5A] shrink-0 animate-bounce-subtle" />
                  )}
                  <span>SYSTEM POSTURE: {postureLabel}</span>
                </h2>
                <p className="text-xs text-[#5A6E85] max-w-xl leading-relaxed">
                  {postureDesc}
                </p>
              </div>
            </div>

            {/* High-Tech Animated Segmented Energy Matrix (Replaces Circle Gauge) */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="font-bold text-[#0B1F3A] flex items-center gap-1.5">
                  <Activity size={12} className="text-[#2B5D87] animate-pulse" />
                  TELEMETRY MATRIX GAUGE
                </span>
                <span className="font-semibold text-[#5A6E85]">
                  Active Integrity: <strong className="text-[#0B1F3A]">{securityPostureScore}%</strong>
                </span>
              </div>

              {/* 20 Segments Matrix Bar with Sweep Animation */}
              <div className="relative p-1 rounded-xl bg-[#FAF7F0] border border-[#D2C3AF] shadow-inner overflow-hidden">
                <div className="grid grid-cols-20 gap-1 sm:gap-1.5 h-3.5">
                  {Array.from({ length: 20 }).map((_, i) => {
                    const threshold = (i + 1) * 5;
                    const isFilled = securityPostureScore >= threshold;
                    let segmentBg = 'bg-[#E3D7C5]';

                    if (isFilled) {
                      if (i < 5) segmentBg = 'bg-[#C47A5A] shadow-[0_0_8px_rgba(196,122,90,0.5)]';
                      else if (i < 12) segmentBg = 'bg-[#2B5D87] shadow-[0_0_8px_rgba(43,93,135,0.4)]';
                      else segmentBg = 'bg-[#0B1F3A] shadow-[0_0_8px_rgba(11,31,58,0.4)]';
                    }

                    return (
                      <div
                        key={i}
                        className={`h-full rounded-sm transition-all duration-500 ${segmentBg} ${
                          isFilled ? 'animate-bar-pulse' : ''
                        }`}
                        title={`Segment ${i + 1}: ${threshold}%`}
                      />
                    );
                  })}
                </div>
                {/* Micro-light scanning beam */}
                <div className="absolute inset-y-0 w-24 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-telemetry-sweep pointer-events-none" />
              </div>
            </div>

            {/* Micro Fleet Telemetry Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs font-mono">
              <div className="px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] flex items-center gap-1.5 shadow-2xs">
                <span className="text-[#5A6E85]">Fleet Trust:</span>
                <strong className="text-[#0B1F3A] font-bold">{avgTrustScore}/100</strong>
              </div>

              <div className="px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] flex items-center gap-1.5 shadow-2xs">
                <span className="text-[#5A6E85]">Threats Active:</span>
                <strong className={activeThreats > 0 ? 'text-[#923818] font-bold' : 'text-[#0B1F3A]'}>
                  {activeThreats}
                </strong>
              </div>

              <div className="px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] flex items-center gap-1.5 shadow-2xs">
                <span className="text-[#5A6E85]">Quarantined:</span>
                <strong className={quarantinedDevices > 0 ? 'text-[#923818] font-bold' : 'text-[#0B1F3A]'}>
                  {quarantinedDevices}
                </strong>
              </div>

              <div className="px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] flex items-center gap-1.5 shadow-2xs">
                <span className="text-[#5A6E85]">Managed Nodes:</span>
                <strong className="text-[#0B1F3A] font-bold">{totalDevices}</strong>
              </div>
            </div>
          </div>

          {/* Right: Factor Breakdown & Action CTAs */}
          <div className="w-full lg:w-80 flex flex-col justify-between gap-4 border-t lg:border-t-0 lg:border-l border-[#D2C3AF] pt-4 lg:pt-0 lg:pl-6 shrink-0">
            {/* Factor breakdown card */}
            <div className="bg-[#FAF7F0] border border-[#D2C3AF] rounded-xl p-3.5 space-y-2 shadow-2xs">
              <span className="text-[11px] font-mono text-[#0B1F3A] uppercase tracking-wider block font-bold">
                Posture Factors Breakdown:
              </span>
              <div className="space-y-1.5">
                {postureFactors.map((f, i) => (
                  <div key={i} className="flex items-center justify-between gap-2 text-xs">
                    <span className="text-[#5A6E85] truncate text-[11px] font-medium">{f.title}:</span>
                    <span
                      className={`font-mono text-[11px] font-bold shrink-0 ${
                        f.impact === 'CRITICAL' || f.impact === 'NEGATIVE'
                          ? 'text-[#923818] bg-[#C47A5A]/15 px-1.5 py-0.5 rounded border border-[#C47A5A]/30'
                          : f.impact === 'WARNING'
                          ? 'text-[#923818] bg-[#C47A5A]/15 px-1.5 py-0.5 rounded border border-[#C47A5A]/30'
                          : 'text-[#2B5D87] bg-[#2B5D87]/10 px-1.5 py-0.5 rounded border border-[#2B5D87]/20'
                      }`}
                    >
                      {f.delta}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2 w-full">
              <button
                onClick={onOpenDemo}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold text-white bg-[#0B1F3A] hover:bg-[#183350] hover:shadow-md transition-all shadow-xs cursor-pointer group"
              >
                <Play size={13} className="fill-current text-[#E8DCC8] group-hover:scale-110 transition-transform" />
                <span>Run E2E Demo</span>
              </button>

              <button
                onClick={onRefresh}
                disabled={isLoading}
                className="p-2.5 rounded-lg text-[#0B1F3A] hover:bg-white bg-[#FAF7F0] border border-[#D2C3AF] hover:border-[#0B1F3A] transition-all cursor-pointer shadow-2xs"
                title="Refresh telemetry"
              >
                <RotateCcw size={15} className={isLoading ? 'animate-spin text-[#2B5D87]' : ''} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. UPGRADED INTERACTIVE KPI CARDS WITH 4-COLOR VISUAL HARMONY */}
      {/* ============================================================== */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-[#C8BDAA] px-1 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#2B5D87]" />
            <span className="font-semibold text-[#FAF7F0]">FLEET KEY PERFORMANCE INDICATORS</span>
          </div>
          <span>Last updated: {nowTime} UTC · <span className="text-[#E8DCC8]">DEMO TELEMETRY</span></span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          {/* 1. Total Devices (Steel Blue theme) */}
          <div
            onClick={() => onNavigateTab('devices')}
            onMouseEnter={() => setActiveTooltip('total')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] hover:border-[#2B5D87] hover:shadow-[0_4px_12px_rgba(43,93,135,0.25)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Total Devices</span>
              <div className="p-1 rounded bg-[#2B5D87]/20 text-[#2B5D87] group-hover:text-[#FAF7F0] transition-colors">
                <Server size={13} className="group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#FAF7F0]">{totalDevices}</span>
              <div className="text-[10px] text-[#2B5D87] font-mono font-medium mt-0.5 flex items-center gap-0.5">
                <ArrowUpRight size={11} /> 100% Catalog
              </div>
            </div>
            {activeTooltip === 'total' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Total IoT devices registered in Zero-Trust database. Click to view fleet.
              </div>
            )}
          </div>

          {/* 2. Active Devices (Steel Blue theme) */}
          <div
            onClick={() => onNavigateTab('devices')}
            onMouseEnter={() => setActiveTooltip('active')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] hover:border-[#2B5D87] hover:shadow-[0_4px_12px_rgba(43,93,135,0.25)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Active Fleet</span>
              <div className="p-1 rounded bg-[#2B5D87]/20 text-[#2B5D87] group-hover:text-[#FAF7F0] transition-colors">
                <Activity size={13} className="group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#FAF7F0]">{activeDevices}</span>
              <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5 flex items-center gap-0.5">
                <TrendingUp size={11} className="text-[#E8DCC8]" /> Online now
              </div>
            </div>
            {activeTooltip === 'active' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Nodes currently transmitting valid telemetry frames. Click to view.
              </div>
            )}
          </div>

          {/* 3. Trusted Devices (Warm Beige theme) */}
          <div
            onClick={() => onNavigateTab('devices', 'TRUSTED')}
            onMouseEnter={() => setActiveTooltip('trusted')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#E8DCC8] hover:border-[#E8DCC8] hover:shadow-[0_4px_12px_rgba(232,220,200,0.25)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Trusted</span>
              <div className="p-1 rounded bg-[#E8DCC8]/20 text-[#E8DCC8] group-hover:scale-110 transition-transform">
                <ShieldCheck size={13} />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#E8DCC8]">{trustedDevices}</span>
              <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5">Mutual verified</div>
            </div>
            {activeTooltip === 'trusted' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Nodes with successful cryptographic signature and low risk. Click to filter.
              </div>
            )}
          </div>

          {/* 4. Suspicious Devices (Burnt Copper theme) */}
          <div
            onClick={() => onNavigateTab('devices', 'SUSPICIOUS')}
            onMouseEnter={() => setActiveTooltip('suspicious')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] hover:border-[#C47A5A] hover:shadow-[0_4px_12px_rgba(196,122,90,0.25)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Suspicious</span>
              <div className="p-1 rounded bg-[#C47A5A]/20 text-[#C47A5A] group-hover:scale-110 transition-transform">
                <AlertTriangle size={13} />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#C47A5A]">{suspiciousDevices}</span>
              <div className="text-[10px] text-[#C47A5A] font-mono mt-0.5 font-medium">Flagged by AI</div>
            </div>
            {activeTooltip === 'suspicious' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Nodes exhibiting telemetry deviation or command anomalies. Click to inspect.
              </div>
            )}
          </div>

          {/* 5. Quarantined Devices (Burnt Copper / Alert theme) */}
          <div
            onClick={() => onNavigateTab('devices', 'QUARANTINED')}
            onMouseEnter={() => setActiveTooltip('quarantined')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] hover:border-[#C47A5A] hover:shadow-[0_4px_12px_rgba(196,122,90,0.3)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Quarantined</span>
              <div className="p-1 rounded bg-[#C47A5A]/20 text-[#C47A5A] group-hover:scale-110 transition-transform">
                <ShieldAlert size={13} />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#C47A5A]">{quarantinedDevices}</span>
              <div className="text-[10px] text-[#C47A5A] font-mono mt-0.5">VLAN 99 isolated</div>
            </div>
            {activeTooltip === 'quarantined' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Click to inspect devices isolated by Zero-Trust policy.
              </div>
            )}
          </div>

          {/* 6. Active Threats (Burnt Copper Pulsing theme) */}
          <div
            onClick={() => onNavigateTab('threat-center')}
            onMouseEnter={() => setActiveTooltip('threats')}
            onMouseLeave={() => setActiveTooltip(null)}
            className={`p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] hover:border-[#C47A5A] hover:shadow-[0_4px_14px_rgba(196,122,90,0.4)] transition-all cursor-pointer group relative flex flex-col justify-between ${
              activeThreats > 0 ? 'animate-glow-copper' : ''
            }`}
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Active Threats</span>
              <div className="p-1 rounded bg-[#C47A5A]/25 text-[#C47A5A]">
                <Radio size={13} className={activeThreats > 0 ? 'animate-pulse' : ''} />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#C47A5A]">{activeThreats}</span>
              <div className="text-[10px] font-mono mt-0.5">
                <span className={activeThreats > 0 ? 'text-[#C47A5A] font-bold' : 'text-[#E8DCC8]'}>
                  {activeThreats > 0 ? 'Action required' : 'Nominal zero'}
                </span>
              </div>
            </div>
            {activeTooltip === 'threats' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Click to view and contain active threats in Threat Center.
              </div>
            )}
          </div>

          {/* 7. Auth Success Rate (Warm Beige theme) */}
          <div
            onClick={() => onNavigateTab('authentication')}
            onMouseEnter={() => setActiveTooltip('auth')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#E8DCC8] hover:border-[#E8DCC8] hover:shadow-[0_4px_12px_rgba(232,220,200,0.25)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Auth Success</span>
              <div className="p-1 rounded bg-[#E8DCC8]/20 text-[#E8DCC8] group-hover:scale-110 transition-transform">
                <CheckCircle2 size={13} />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#FAF7F0]">{authSuccessRate}%</span>
              <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5">
                {successfulAuths}/{totalAuths} Verified
              </div>
            </div>
            {activeTooltip === 'auth' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Click to test mutual challenge-response authentication.
              </div>
            )}
          </div>

          {/* 8. System Risk (Multi-color theme) */}
          <div
            onClick={() => onNavigateTab('risk-zero-trust')}
            onMouseEnter={() => setActiveTooltip('risk')}
            onMouseLeave={() => setActiveTooltip(null)}
            className="p-3.5 rounded-lg bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] hover:border-[#E8DCC8] hover:shadow-[0_4px_12px_rgba(43,93,135,0.3)] transition-all cursor-pointer group relative flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <span className="text-[11px] font-semibold text-[#C8BDAA] group-hover:text-[#FAF7F0]">Fleet Risk</span>
              <div className="p-1 rounded bg-[#2B5D87]/20 text-[#2B5D87] group-hover:text-[#E8DCC8] transition-colors">
                <Lock size={13} className="group-hover:scale-110 transition-transform" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-2xl font-bold font-mono tabular-nums text-[#FAF7F0]">{avgRiskScore}</span>
              <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Mean index /100</div>
            </div>
            {activeTooltip === 'risk' && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 w-44 p-2 bg-[#08182D] border border-[#294563] rounded shadow-lg text-[10px] text-[#C8BDAA] z-20 pointer-events-none">
                Click to inspect Zero-Trust decision engine and risk factors.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 3. CHARTS ROW WITH BALANCED 4-COLOR VISUAL HIERARCHY          */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Status Distribution (Warm Beige & Steel Blue Focus) */}
        <div className="bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#E8DCC8] rounded-xl p-5 space-y-3 shadow-md hover:shadow-lg transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#E8DCC8]" />
              <h3 className="text-xs font-bold text-[#FAF7F0] tracking-wide">FLEET ZERO-TRUST STATUS</h3>
            </div>
            <span className="text-[11px] font-mono text-[#E8DCC8]">{totalDevices} Managed Nodes</span>
          </div>

          <div className="h-52 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="#0B1F3A" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#08182D',
                    borderColor: '#294563',
                    fontSize: '11px',
                    color: '#FAF7F0',
                    borderRadius: '6px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs border-t border-[#294563]/60 pt-3">
            {statusData.map((s) => (
              <div key={s.name} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-sm shrink-0 shadow-xs" style={{ backgroundColor: s.color }} />
                <span className="text-[#C8BDAA] text-[11px] truncate">{s.name}:</span>
                <span className="font-mono tabular-nums text-[#FAF7F0] font-bold text-[11px] ml-auto">
                  {s.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Chart 2: Challenge-Response Nonce Activity Timeline (Steel Blue & Burnt Copper) */}
        <div className="bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] rounded-xl p-5 space-y-3 shadow-md hover:shadow-lg transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#2B5D87]" />
              <h3 className="text-xs font-bold text-[#FAF7F0] tracking-wide">MUTUAL AUTH TIMELINE</h3>
            </div>
            <span className="text-[11px] font-mono text-[#2B5D87] font-semibold">CSPRNG Nonce Stream</span>
          </div>

          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={authTrendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSuccess" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2B5D87" stopOpacity={0.75} />
                    <stop offset="95%" stopColor="#2B5D87" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="colorFail" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C47A5A" stopOpacity={0.75} />
                    <stop offset="95%" stopColor="#C47A5A" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#C8BDAA" fontSize={10} tickLine={false} />
                <YAxis stroke="#C8BDAA" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#08182D',
                    borderColor: '#294563',
                    fontSize: '11px',
                    color: '#FAF7F0',
                    borderRadius: '6px',
                  }}
                />
                <Area type="monotone" dataKey="successful" stroke="#2B5D87" strokeWidth={2} fillOpacity={1} fill="url(#colorSuccess)" name="Verified Signatures" />
                <Area type="monotone" dataKey="failed" stroke="#C47A5A" strokeWidth={2} fillOpacity={1} fill="url(#colorFail)" name="Failed / Replayed" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-[#C8BDAA] border-t border-[#294563]/60 pt-3 font-mono">
            <span>Verified: <strong className="text-[#E8DCC8]">{successfulAuths}</strong></span>
            <span>Replay Blocked: <strong className="text-[#C47A5A]">{authAttempts.filter(a => a.result === 'REPLAY_BLOCKED').length}</strong></span>
          </div>
        </div>

        {/* Chart 3: Device Risk Distribution (Multi-Tier Vibrant Bar Colors) */}
        <div className="bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] rounded-xl p-5 space-y-3 shadow-md hover:shadow-lg transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#C47A5A]" />
              <h3 className="text-xs font-bold text-[#FAF7F0] tracking-wide">FLEET RISK DISTRIBUTION</h3>
            </div>
            <span className="text-[11px] font-mono text-[#C47A5A] font-semibold">0–100 Continuous Score</span>
          </div>

          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskGroups} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#C8BDAA" fontSize={10} tickLine={false} />
                <YAxis stroke="#C8BDAA" fontSize={10} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#08182D',
                    borderColor: '#294563',
                    fontSize: '11px',
                    color: '#FAF7F0',
                    borderRadius: '6px',
                  }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]} name="Devices">
                  {riskGroups.map((entry, index) => {
                    const colors = ['#2B5D87', '#E8DCC8', '#D97706', '#C47A5A'];
                    return <Cell key={`bar-${index}`} fill={colors[index % colors.length]} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-[#C8BDAA] border-t border-[#294563]/60 pt-3">
            <span>Critical Nodes: <strong className="text-[#C47A5A] font-mono font-bold">{devices.filter(d => d.riskScore >= 80).length}</strong></span>
            <button
              onClick={() => onNavigateTab('risk-zero-trust')}
              className="text-[#E8DCC8] hover:text-[#FAF7F0] hover:underline text-[11px] font-semibold transition-colors cursor-pointer"
            >
              Examine Trust Engine →
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 4. PROMINENT LIVE SECURITY ACTIVITY & RECENT THREATS          */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prominent Live Security Activity Feed */}
        <div className="bg-[#0B1F3A] border border-[#294563] border-l-4 border-l-[#2B5D87] rounded-xl p-5 space-y-4 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2B5D87] opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#E8DCC8]" />
              </span>
              <h3 className="text-xs font-bold text-[#FAF7F0] tracking-wide">LIVE SECURITY ACTIVITY</h3>
            </div>
            <button
              onClick={() => onNavigateTab('audit-center')}
              className="text-xs font-semibold text-[#E8DCC8] hover:text-[#FAF7F0] transition-colors cursor-pointer"
            >
              View All Audit Records ({auditLogs.length}) →
            </button>
          </div>

          <div className="divide-y divide-[#294563]/40 max-h-96 overflow-y-auto pr-1">
            {auditLogs.slice(0, 7).map((log, idx) => (
              <div
                key={log.id}
                className={`py-3 flex items-start justify-between gap-3 text-xs transition-colors hover:bg-[#102A4D]/40 rounded px-2 -mx-2 ${
                  idx === 0 ? 'bg-[#08182D]/60 border border-[#2B5D87]/40' : ''
                }`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-[#FAF7F0]">{log.event}</span>
                    <span className="text-[10px] text-[#294563]">·</span>
                    <span className="text-[10px] font-mono text-[#E8DCC8] font-medium">{log.source}</span>
                  </div>

                  <p className="text-[#C8BDAA] text-[11px] leading-relaxed">
                    {log.details}
                  </p>

                  {log.deviceName && (
                    <div className="text-[10px] text-[#C8BDAA] font-mono">
                      Target: <strong className="text-[#FAF7F0]">{log.deviceName}</strong> ({log.deviceId})
                    </div>
                  )}
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`inline-block font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${
                      log.result === 'SUCCESS'
                        ? 'bg-[#E8DCC8]/15 text-[#E8DCC8] border-[#E8DCC8]/40'
                        : log.result === 'BLOCKED' || log.result === 'DENIED'
                        ? 'bg-[#C47A5A]/20 text-[#C47A5A] border-[#C47A5A]/50 font-bold'
                        : 'bg-[#2B5D87]/20 text-[#FAF7F0] border-[#2B5D87]/40'
                    }`}
                  >
                    {log.result}
                  </span>
                  <div className="text-[10px] text-[#C8BDAA] font-mono tabular-nums mt-1">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Threats / Incident Queue */}
        <div className="bg-[#0B1F3A] border border-[#294563] border-l-4 border-l-[#C47A5A] rounded-xl p-5 space-y-4 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C47A5A] opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#C47A5A]" />
              </span>
              <h3 className="text-xs font-bold text-[#FAF7F0] tracking-wide">ACTIVE THREAT INCIDENT QUEUE</h3>
            </div>
            <button
              onClick={() => onNavigateTab('threat-center')}
              className="text-xs font-semibold text-[#C47A5A] hover:text-[#FAF7F0] transition-colors cursor-pointer"
            >
              Investigate in Threat Center ({threats.length}) →
            </button>
          </div>

          <div className="divide-y divide-[#294563]/40 max-h-96 overflow-y-auto pr-1">
            {threats.length === 0 ? (
              <div className="text-center py-12 text-xs text-[#E8DCC8] font-mono">
                No active threats flagged by Zero-Trust rules. All nodes nominal.
              </div>
            ) : (
              threats.slice(0, 5).map((threat) => (
                <div
                  key={threat.id}
                  onClick={() => onNavigateTab('threat-center')}
                  className="py-3 flex items-start justify-between gap-3 text-xs cursor-pointer hover:bg-[#102A4D]/60 -mx-2 px-2.5 rounded-lg transition-all group border border-transparent hover:border-[#C47A5A]/30"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#FAF7F0] group-hover:text-[#E8DCC8] transition-colors">
                        {threat.category}
                      </span>
                      <span className="text-[10px] text-[#294563]">·</span>
                      <RiskBadge level={threat.severity} score={threat.riskScore} />
                    </div>

                    <p className="text-[#C8BDAA] text-[11px] line-clamp-2 leading-relaxed">
                      {threat.description}
                    </p>

                    <div className="text-[10px] font-mono text-[#C8BDAA]">
                      Node: <span className="text-[#FAF7F0] font-semibold">{threat.deviceName}</span> ({threat.deviceId}) · Action: <strong className="text-[#E8DCC8]">{threat.responseAction}</strong>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`inline-block font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded border shadow-xs ${
                        threat.status === 'CONTAINED' || threat.status === 'RESOLVED'
                          ? 'bg-[#E8DCC8]/15 text-[#E8DCC8] border-[#E8DCC8]/40'
                          : 'bg-[#C47A5A]/25 text-[#C47A5A] border-[#C47A5A]/60 font-black'
                      }`}
                    >
                      {threat.status}
                    </span>
                    <div className="text-[10px] text-[#C8BDAA] font-mono tabular-nums mt-1">
                      {new Date(threat.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
