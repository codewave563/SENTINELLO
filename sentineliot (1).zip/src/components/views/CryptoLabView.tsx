import React, { useState, useEffect } from 'react';
import {
  KeyRound,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  FileCode,
  Shield,
  Zap,
  Info,
  Cpu,
  ArrowRight,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import type { CryptoAlgorithm, CryptoBenchmarkResult, CryptoKeyDetails } from '../../types/index.ts';
import {
  fetchCryptoBenchmark,
  generateCryptoKey,
  runCryptoSignVerifyDemo,
} from '../../services/api.ts';

export const CryptoLabView: React.FC = () => {
  // Benchmark state
  const [benchmarks, setBenchmarks] = useState<CryptoBenchmarkResult[]>([]);
  const [benchLoading, setBenchLoading] = useState(false);

  // Active key & operation state per algorithm
  const [activeAlgCard, setActiveAlgCard] = useState<CryptoAlgorithm>('ED25519');
  const [keyResults, setKeyResults] = useState<Record<CryptoAlgorithm, (CryptoKeyDetails & { keyGenMs: number }) | null>>({
    ED25519: null,
    ECDSA_P256: null,
    RSA_2048: null,
  });
  const [signVerifyResults, setSignVerifyResults] = useState<Record<CryptoAlgorithm, any>>({
    ED25519: null,
    ECDSA_P256: null,
    RSA_2048: null,
  });
  const [loadingAlg, setLoadingAlg] = useState<string | null>(null);

  // Handshake simulation state
  const [handshakeStep, setHandshakeStep] = useState<number>(0);
  const [isHandshakeRunning, setIsHandshakeRunning] = useState(false);
  const [handshakeData, setHandshakeData] = useState<{
    nonce: string;
    payload: string;
    signature: string;
    latencyMs: number;
    decision: string;
  } | null>(null);

  const loadBenchmarks = async () => {
    setBenchLoading(true);
    try {
      const data = await fetchCryptoBenchmark();
      setBenchmarks(data);
    } catch (err) {
      console.error('Benchmark fetch error:', err);
    } finally {
      setBenchLoading(false);
    }
  };

  useEffect(() => {
    loadBenchmarks();
  }, []);

  const handleGenerateIdentity = async (alg: CryptoAlgorithm) => {
    setLoadingAlg(`keygen-${alg}`);
    try {
      const key = await generateCryptoKey(alg);
      setKeyResults((prev) => ({ ...prev, [alg]: key }));
      setActiveAlgCard(alg);
    } catch (err) {
      console.error('Key generation error:', err);
    } finally {
      setLoadingAlg(null);
    }
  };

  const handleSignAndVerify = async (alg: CryptoAlgorithm) => {
    setLoadingAlg(`sign-${alg}`);
    try {
      const demoResult = await runCryptoSignVerifyDemo({
        algorithm: alg,
        message: `SENTINEL_IOT_CHALLENGE_PAYLOAD_${alg}_${Date.now()}`,
      });
      setSignVerifyResults((prev) => ({ ...prev, [alg]: demoResult }));
      setActiveAlgCard(alg);
    } catch (err) {
      console.error('Sign verify error:', err);
    } finally {
      setLoadingAlg(null);
    }
  };

  // Run the Live Cryptographic Handshake visualization
  const handleRunHandshake = async () => {
    setIsHandshakeRunning(true);
    setHandshakeStep(1); // 1. Device Challenge Request
    setHandshakeData(null);

    await new Promise((r) => setTimeout(r, 400));
    setHandshakeStep(2); // 2. Server Nonce Generated

    // Generate real nonce
    const fakeNonce = Array.from({ length: 32 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('');

    await new Promise((r) => setTimeout(r, 450));
    setHandshakeStep(3); // 3. Device Signs Message

    // Sign payload
    const signResult = await runCryptoSignVerifyDemo({
      algorithm: activeAlgCard,
      message: `HANDSHAKE:${fakeNonce}:${Date.now()}`,
    });

    await new Promise((r) => setTimeout(r, 450));
    setHandshakeStep(4); // 4. Crypto Engine Verifies

    await new Promise((r) => setTimeout(r, 400));
    setHandshakeStep(5); // 5. Zero Trust Access Decision

    setHandshakeData({
      nonce: fakeNonce,
      payload: `IOT-ESP32-07:${fakeNonce}`,
      signature: signResult.signatureBase64,
      latencyMs: Number((signResult.signMs + signResult.verifyMs).toFixed(2)),
      decision: 'ALLOW (TRUST VERIFIED)',
    });

    setIsHandshakeRunning(false);
  };

  // 3 Primary Algorithm specs
  const ALGORITHM_SPECS = [
    {
      alg: 'ED25519' as CryptoAlgorithm,
      name: 'Ed25519',
      standard: 'RFC 8032 / Edwards-curve (EdDSA)',
      curve: 'Curve25519 (256-bit)',
      purpose: 'Ultra-fast signing & verification for resource-constrained IoT nodes and battery-powered microcontrollers.',
      characteristics: 'Constant-time operations immune to cache-timing attacks. Fixed 64-byte signature size. Lowest battery overhead.',
      status: 'RECOMMENDED FOR SENSORS',
      bits: 128,
    },
    {
      alg: 'ECDSA_P256' as CryptoAlgorithm,
      name: 'ECDSA P-256',
      standard: 'NIST FIPS 186-4 / SECG secp256r1',
      curve: 'prime256v1 (256-bit)',
      purpose: 'Standard government & enterprise regulatory compliance for industrial controllers and hardware crypto co-processors (e.g. ATECC608A).',
      characteristics: 'Widespread hardware cryptographic engine acceleration. 64-72 byte ASN.1 DER signature. Strict FIPS 140-2 approval.',
      status: 'FIPS 186-4 COMPLIANT',
      bits: 128,
    },
    {
      alg: 'RSA_2048' as CryptoAlgorithm,
      name: 'RSA-2048',
      standard: 'PKCS#1 v1.5 / RFC 8017',
      curve: '2048-bit Modulus',
      purpose: 'Legacy industrial systems compatibility, edge gateway TLS negotiation, and older SCADA field installations.',
      characteristics: 'Extremely fast signature verification on gateways, but high key generation & signing compute overhead. 256-byte payload.',
      status: 'LEGACY SUPPORTED',
      bits: 112,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Cryptographic Laboratory</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">OpenSSL Native Primitives</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            Asymmetric Hardware Identity & Cryptographic Workbench
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Empirical evaluation of asymmetric cryptography across Ed25519, ECDSA P-256, and RSA-2048. Real execution times measured via <code className="text-[#E8DCC8]">process.hrtime.bigint()</code> with zero fabricated values.
          </p>
        </div>

        <button
          onClick={loadBenchmarks}
          disabled={benchLoading}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded text-xs font-semibold text-[#FAF7F0] bg-[#2B5D87] hover:bg-[#2B5D87]/80 transition-colors shrink-0 cursor-pointer"
        >
          <RotateCcw size={14} className={benchLoading ? 'animate-spin' : ''} />
          <span>{benchLoading ? 'Measuring Microseconds...' : 'Re-run Benchmark Suite'}</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* 1. THREE MAIN ALGORITHM CARDS (ECDSA, ED25519, RSA-2048)        */}
      {/* ============================================================== */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {ALGORITHM_SPECS.map((spec) => {
          const isSelected = activeAlgCard === spec.alg;
          const keyData = keyResults[spec.alg];
          const signData = signVerifyResults[spec.alg];
          const accentColor = spec.alg === 'ED25519' ? '#2B5D87' : spec.alg === 'ECDSA_P256' ? '#E8DCC8' : '#C47A5A';
          const topBorderClass = spec.alg === 'ED25519' ? 'border-t-4 border-t-[#2B5D87]' : spec.alg === 'ECDSA_P256' ? 'border-t-4 border-t-[#E8DCC8]' : 'border-t-4 border-t-[#C47A5A]';

          return (
            <div
              key={spec.alg}
              className={`bg-[#0B1F3A] border rounded-xl p-5 flex flex-col justify-between space-y-4 transition-all shadow-md ${topBorderClass} ${
                isSelected
                  ? 'border-[#E8DCC8] shadow-[0_4px_16px_rgba(232,220,200,0.2)] ring-1 ring-[#E8DCC8]/40'
                  : 'border-[#294563] hover:border-[#2B5D87]'
              }`}
            >
              {/* Card Header */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span
                    className="text-[10px] font-mono uppercase tracking-wider font-bold px-2 py-0.5 rounded border"
                    style={{
                      color: accentColor,
                      borderColor: `${accentColor}40`,
                      backgroundColor: `${accentColor}15`,
                    }}
                  >
                    {spec.status}
                  </span>
                  <span className="text-[10px] font-mono text-[#E8DCC8] bg-[#08182D] px-2 py-0.5 rounded border border-[#294563] font-semibold">
                    {spec.bits}-bit Security
                  </span>
                </div>

                <h3 className="text-xl font-bold text-[#FAF7F0] font-mono flex items-center justify-between">
                  <span>{spec.name}</span>
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: accentColor }} />
                </h3>
                <div className="text-[11px] font-mono text-[#C8BDAA]">{spec.standard}</div>

                <p className="text-xs text-[#C8BDAA] leading-relaxed pt-1">
                  {spec.purpose}
                </p>

                <div className="p-3 bg-[#08182D] border border-[#294563]/60 rounded-lg text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#C8BDAA]">Curve / Modulus:</span>
                    <span className="text-[#FAF7F0]">{spec.curve}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#C8BDAA]">Digest Standard:</span>
                    <span className="text-[#E8DCC8] font-semibold">SHA-256</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#C8BDAA]">Key Generation:</span>
                    <span className="text-[#FAF7F0] font-semibold">
                      {keyData ? `${keyData.keyGenMs} ms` : 'Ready'}
                    </span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#C8BDAA]">Signature Size:</span>
                    <span className="text-[#E8DCC8] font-semibold">
                      {spec.alg === 'ED25519' ? '64 Bytes' : spec.alg === 'ECDSA_P256' ? '64-72 Bytes' : '256 Bytes'}
                    </span>
                  </div>
                </div>

                {/* Keygen / Signature result preview if generated */}
                {keyData && (
                  <div className="p-2.5 bg-[#08182D] border border-[#E8DCC8]/40 rounded text-[10px] font-mono space-y-1 animate-in fade-in">
                    <div className="text-[#E8DCC8] font-bold">Key Generated:</div>
                    <div className="text-[#FAF7F0] truncate">{keyData.fingerprint}</div>
                  </div>
                )}

                {signData && (
                  <div className="p-2.5 bg-[#08182D] border border-[#2B5D87] rounded text-[10px] font-mono space-y-1 animate-in fade-in">
                    <div className="flex justify-between text-[#FAF7F0]">
                      <span className="text-[#E8DCC8] font-semibold">Verified in:</span>
                      <span>{signData.verifyMs} ms</span>
                    </div>
                    <div className="text-[#C8BDAA] truncate">Sig: {signData.signatureBase64.slice(0, 30)}...</div>
                  </div>
                )}
              </div>

              {/* 4 Interactive Buttons for this Algorithm */}
              <div className="pt-3 border-t border-[#294563]/60 grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleGenerateIdentity(spec.alg)}
                  disabled={loadingAlg !== null}
                  className="px-2.5 py-1.5 rounded bg-[#08182D] border border-[#294563] text-xs font-semibold text-[#E8DCC8] hover:border-[#E8DCC8] transition-colors cursor-pointer text-center"
                >
                  {loadingAlg === `keygen-${spec.alg}` ? 'Generating...' : 'Generate Identity'}
                </button>

                <button
                  onClick={() => handleSignAndVerify(spec.alg)}
                  disabled={loadingAlg !== null}
                  className="px-2.5 py-1.5 rounded bg-[#08182D] border border-[#294563] text-xs font-semibold text-[#FAF7F0] hover:border-[#2B5D87] transition-colors cursor-pointer text-center"
                >
                  {loadingAlg === `sign-${spec.alg}` ? 'Signing...' : 'Sign Message'}
                </button>

                <button
                  onClick={() => handleSignAndVerify(spec.alg)}
                  disabled={loadingAlg !== null}
                  className="px-2.5 py-1.5 rounded bg-[#2B5D87] text-xs font-semibold text-[#FAF7F0] hover:bg-[#2B5D87]/80 transition-colors cursor-pointer text-center"
                >
                  Verify Signature
                </button>

                <button
                  onClick={loadBenchmarks}
                  disabled={benchLoading}
                  className="px-2.5 py-1.5 rounded bg-[#08182D] border border-[#C47A5A]/60 text-xs font-semibold text-[#C47A5A] hover:border-[#C47A5A] transition-colors cursor-pointer text-center"
                >
                  Benchmark
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* 2. LIVE CRYPTOGRAPHIC HANDSHAKE VISUALIZATION (SECTION 8)     */}
      {/* ============================================================== */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-xl p-6 shadow-md space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#294563]/60 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase text-[#C47A5A] font-semibold">Interactive Sequence</span>
              <span className="text-xs text-[#294563]">·</span>
              <span className="text-xs text-[#C8BDAA]">Mutual Zero-Trust Handshake</span>
            </div>
            <h3 className="text-base font-bold text-[#FAF7F0] mt-0.5">
              Live Cryptographic Handshake Pipeline
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={activeAlgCard}
              onChange={(e) => setActiveAlgCard(e.target.value as CryptoAlgorithm)}
              className="bg-[#08182D] border border-[#294563] rounded px-3 py-1.5 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
            >
              <option value="ED25519">Ed25519 Handshake</option>
              <option value="ECDSA_P256">ECDSA P-256 Handshake</option>
              <option value="RSA_2048">RSA-2048 Handshake</option>
            </select>

            <button
              onClick={handleRunHandshake}
              disabled={isHandshakeRunning}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded text-xs font-semibold text-[#08182D] bg-[#E8DCC8] hover:bg-[#FAF7F0] transition-colors shadow-xs cursor-pointer"
            >
              <Play size={13} className="fill-current" />
              <span>{isHandshakeRunning ? 'Handshaking...' : 'Execute Live Handshake'}</span>
            </button>
          </div>
        </div>

        {/* 5-Step Visual Flowchart */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
          {/* Step 1: Device Request */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              handshakeStep >= 1
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="text-[10px] font-mono text-[#C8BDAA] mb-1">01. INITIATION</div>
            <div className="font-bold text-xs">DEVICE</div>
            <div className="text-[11px] text-[#C8BDAA] font-mono mt-1">Challenge Request</div>
          </div>

          {/* Step 2: Nonce Generated */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              handshakeStep >= 2
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="text-[10px] font-mono text-[#C8BDAA] mb-1">02. CHALLENGE</div>
            <div className="font-bold text-xs">SERVER</div>
            <div className="text-[11px] text-[#C8BDAA] font-mono mt-1">32B Nonce Generated</div>
          </div>

          {/* Step 3: Message Signed */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              handshakeStep >= 3
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="text-[10px] font-mono text-[#C8BDAA] mb-1">03. SIGNING</div>
            <div className="font-bold text-xs">DEVICE</div>
            <div className="text-[11px] text-[#C8BDAA] font-mono mt-1">Message Signed</div>
          </div>

          {/* Step 4: Signature Verified */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              handshakeStep >= 4
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="text-[10px] font-mono text-[#C8BDAA] mb-1">04. VERIFY</div>
            <div className="font-bold text-xs">CRYPTO ENGINE</div>
            <div className="text-[11px] text-[#C8BDAA] font-mono mt-1">Signature Verified</div>
          </div>

          {/* Step 5: Access Decision */}
          <div
            className={`p-3.5 rounded-lg border transition-all ${
              handshakeStep >= 5
                ? 'bg-[#08182D] border-[#E8DCC8] text-[#E8DCC8]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="text-[10px] font-mono mb-1">05. ZERO TRUST</div>
            <div className="font-bold text-xs">POLICY ENGINE</div>
            <div className="text-[11px] font-mono mt-1">
              {handshakeStep >= 5 ? 'ACCESS GRANTED' : 'Access Decision'}
            </div>
          </div>
        </div>

        {/* Live Handshake Payload Manifest */}
        {handshakeData && (
          <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2 text-xs font-mono animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#294563]/60 pb-2">
              <span className="font-bold text-[#FAF7F0]">Live Cryptographic Manifest</span>
              <span className="text-[#E8DCC8] font-bold tabular-nums">
                Verified in {handshakeData.latencyMs} ms ({activeAlgCard})
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
              <div>
                <span className="text-[#C8BDAA] block mb-0.5">32-Byte CSPRNG Nonce:</span>
                <span className="text-[#FAF7F0] break-all">{handshakeData.nonce}</span>
              </div>
              <div>
                <span className="text-[#C8BDAA] block mb-0.5">Signed Digest Payload:</span>
                <span className="text-[#E8DCC8] break-all">{handshakeData.payload}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#294563]/40 flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div>
                <span className="text-[#C8BDAA]">Digital Signature (Base64): </span>
                <span className="text-[#FAF7F0] break-all">{handshakeData.signature.slice(0, 48)}...</span>
              </div>
              <div className="font-bold text-[#E8DCC8]">{handshakeData.decision}</div>
            </div>
          </div>
        )}
      </div>

      {/* ============================================================== */}
      {/* 3. EMPIRICAL OPENSSL BENCHMARK SUITE                          */}
      {/* ============================================================== */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-[#FAF7F0]">
              Empirical Performance Benchmark: ECDSA vs Ed25519 vs RSA
            </h3>
            <p className="text-xs text-[#C8BDAA] mt-0.5">
              Measured via native OpenSSL with 10–20 iterations per primitive. High-resolution timestamps via <code className="text-[#E8DCC8]">process.hrtime.bigint()</code>.
            </p>
          </div>
          <span className="text-[11px] font-mono text-[#C8BDAA]">True OpenSSL Execution</span>
        </div>

        {/* Benchmark Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#294563] bg-[#08182D]/80 text-[#C8BDAA] font-mono text-[11px] uppercase">
                <th className="py-2.5 px-3">Algorithm</th>
                <th className="py-2.5 px-3">Parameters</th>
                <th className="py-2.5 px-3 text-right">KeyGen Time</th>
                <th className="py-2.5 px-3 text-right">Sign Time</th>
                <th className="py-2.5 px-3 text-right">Verify Time</th>
                <th className="py-2.5 px-3 text-right">Sig Size</th>
                <th className="py-2.5 px-3 text-right">Security Bits</th>
                <th className="py-2.5 px-3">Architectural Recommendation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#294563]/40 font-mono">
              {benchmarks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-xs text-[#C8BDAA]">
                    {benchLoading ? 'Computing empirical benchmark suite...' : 'N/A'}
                  </td>
                </tr>
              ) : (
                benchmarks.map((b) => (
                  <tr key={b.algorithm} className="hover:bg-[#102A4D]/40">
                    <td className="py-2.5 px-3 font-semibold text-[#FAF7F0]">{b.label}</td>
                    <td className="py-2.5 px-3 text-[#C8BDAA]">{b.curveOrBits}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-[#FAF7F0]">{b.keyGenMs} ms</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-[#E8DCC8]">{b.signMs} ms</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-[#FAF7F0]">{b.verifyMs} ms</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-[#C8BDAA]">{b.signatureSizeBytes} B</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-[#E8DCC8]">{b.securityBitsEquivalent}</td>
                    <td className="py-2.5 px-3 font-sans text-xs text-[#C8BDAA] max-w-xs">{b.tradeoffRecommendation}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Charts Row */}
        {benchmarks.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-[#294563]/60">
            {/* Latency Comparison */}
            <div className="bg-[#08182D] border border-[#294563] p-4 rounded space-y-2">
              <span className="text-xs font-semibold text-[#FAF7F0]">Execution Latency (ms)</span>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={benchmarks.map((b) => ({
                      name: b.label,
                      sign: b.signMs,
                      verify: b.verifyMs,
                    }))}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <XAxis dataKey="name" stroke="#C8BDAA" fontSize={11} tickLine={false} />
                    <YAxis stroke="#C8BDAA" fontSize={10} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#08182D', borderColor: '#294563', fontSize: '11px', color: '#FAF7F0' }} />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="sign" fill="#E8DCC8" name="Sign Time (ms)" radius={[3, 3, 0, 0]} />
                    <Bar dataKey="verify" fill="#2B5D87" name="Verify Time (ms)" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Payload Size Comparison */}
            <div className="bg-[#08182D] border border-[#294563] p-4 rounded space-y-2">
              <span className="text-xs font-semibold text-[#FAF7F0]">Payload Footprint (Bytes)</span>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={benchmarks.map((b) => ({
                      name: b.label,
                      signatureSize: b.signatureSizeBytes,
                    }))}
                    margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
                  >
                    <XAxis dataKey="name" stroke="#C8BDAA" fontSize={11} tickLine={false} />
                    <YAxis stroke="#C8BDAA" fontSize={10} tickLine={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#08182D', borderColor: '#294563', fontSize: '11px', color: '#FAF7F0' }} />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="signatureSize" fill="#C47A5A" name="Signature Size (Bytes)" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
