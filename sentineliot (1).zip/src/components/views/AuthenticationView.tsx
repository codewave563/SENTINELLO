import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Play,
  ArrowRight,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  KeyRound,
  AlertTriangle,
  History,
  Lock,
  Layers,
  Radio,
  FileCheck,
} from 'lucide-react';
import type { AuthAttempt, Device, PolicyDecision } from '../../types/index.ts';
import { simulateAuthFlow } from '../../services/api.ts';
import { StatusBadge } from '../ui/StatusBadge.tsx';

interface AuthenticationViewProps {
  devices: Device[];
  authAttempts: AuthAttempt[];
  onRefresh: () => void;
  initialDeviceId?: string;
}

type PipelineState =
  | 'WAITING'
  | 'CHALLENGE_ISSUED'
  | 'SIGNING'
  | 'VERIFYING'
  | 'VERIFIED'
  | 'FAILED'
  | 'EXPIRED'
  | 'REPLAY_DETECTED';

export const AuthenticationView: React.FC<AuthenticationViewProps> = ({
  devices,
  authAttempts,
  onRefresh,
  initialDeviceId,
}) => {
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>(
    initialDeviceId || devices[0]?.id || 'IOT-ESP32-07'
  );
  const [pipelineState, setPipelineState] = useState<PipelineState>('WAITING');
  const [isExecuting, setIsExecuting] = useState(false);
  const [simDetails, setSimDetails] = useState<any>(null);

  // Simulation mode toggles
  const [tamperSig, setTamperSig] = useState(false);
  const [triggerReplay, setTriggerReplay] = useState(false);
  const [triggerSkew, setTriggerSkew] = useState(false);

  // Calculated overview stats
  const totalAttempts = authAttempts.length;
  const successfulCount = authAttempts.filter((a) => a.result === 'SUCCESS').length;
  const failedCount = authAttempts.filter((a) => a.result === 'FAILED').length;
  const replayCount = authAttempts.filter((a) => a.result === 'REPLAY_BLOCKED').length;
  const expiredCount = authAttempts.filter((a) => a.result === 'EXPIRED').length;

  const handleRunAuth = async () => {
    setIsExecuting(true);
    setSimDetails(null);
    setPipelineState('WAITING');

    try {
      // Step 1: Request
      await new Promise((r) => setTimeout(r, 200));
      setPipelineState('CHALLENGE_ISSUED');

      // Step 2: Signing
      await new Promise((r) => setTimeout(r, 350));
      setPipelineState('SIGNING');

      // Step 3: Server verification call
      await new Promise((r) => setTimeout(r, 350));
      setPipelineState('VERIFYING');

      const response = await simulateAuthFlow({
        deviceId: selectedDeviceId,
        tamperWithSignature: tamperSig,
        triggerReplay,
        triggerSkew,
      });

      await new Promise((r) => setTimeout(r, 350));
      setSimDetails(response.data);

      const verification = response.data.step4_verification;
      if (verification.success) {
        setPipelineState('VERIFIED');
      } else if (verification.failureReason?.includes('Replay')) {
        setPipelineState('REPLAY_DETECTED');
      } else if (verification.failureReason?.includes('timestamp') || verification.failureReason?.includes('skew')) {
        setPipelineState('EXPIRED');
      } else {
        setPipelineState('FAILED');
      }

      onRefresh();
    } catch (err) {
      console.error('Auth run error:', err);
      setPipelineState('FAILED');
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Authentication Center</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">Mutual Zero-Trust Challenge-Response</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            AUTHENTICATION OVERVIEW — Nonce Freshness & Cryptographic Verification
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            IoT nodes prove private key possession via signed 32-byte nonces. Single-use enforcement guarantees immunity against eavesdropping and packet replay attacks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDeviceId}
            onChange={(e) => {
              setSelectedDeviceId(e.target.value);
              setPipelineState('WAITING');
              setSimDetails(null);
            }}
            className="bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.id}) - {d.cryptoAlgorithm}
              </option>
            ))}
          </select>

          <button
            onClick={handleRunAuth}
            disabled={isExecuting}
            className="inline-flex items-center gap-2 px-4 py-2 rounded text-xs font-semibold text-[#08182D] bg-[#E8DCC8] hover:bg-[#FAF7F0] transition-colors shrink-0 shadow-xs cursor-pointer"
          >
            <Play size={13} className="fill-current" />
            <span>{isExecuting ? 'Authenticating...' : 'Execute Challenge'}</span>
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 1. AUTHENTICATION OVERVIEW CARDS (5 KPI CARDS)                 */}
      {/* ============================================================== */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div className="p-4 bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] rounded-xl shadow-md hover:border-[#2B5D87] transition-all">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase font-semibold flex items-center justify-between">
            <span>Total Attempts</span>
            <History size={13} className="text-[#2B5D87]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#FAF7F0] tabular-nums mt-1">
            {totalAttempts}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">All sessions</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#E8DCC8] rounded-xl shadow-md hover:border-[#E8DCC8] transition-all">
          <div className="text-[11px] font-mono text-[#E8DCC8] uppercase font-semibold flex items-center justify-between">
            <span>Successful</span>
            <CheckCircle2 size={13} className="text-[#E8DCC8]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#E8DCC8] tabular-nums mt-1">
            {successfulCount}
          </div>
          <div className="text-[10px] text-[#E8DCC8] font-mono mt-0.5">Signature verified</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] rounded-xl shadow-md hover:border-[#C47A5A] transition-all">
          <div className="text-[11px] font-mono text-[#C47A5A] uppercase font-semibold flex items-center justify-between">
            <span>Failed Signatures</span>
            <XCircle size={13} className="text-[#C47A5A]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#C47A5A] tabular-nums mt-1">
            {failedCount}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Key/digest mismatch</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#C47A5A] rounded-xl shadow-md hover:border-[#C47A5A] transition-all">
          <div className="text-[11px] font-mono text-[#C47A5A] uppercase font-semibold flex items-center justify-between">
            <span>Replay Attempts</span>
            <ShieldAlert size={13} className="text-[#C47A5A]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#C47A5A] tabular-nums mt-1">
            {replayCount}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">Reused nonce blocked</div>
        </div>

        <div className="p-4 bg-[#0B1F3A] border border-[#294563] border-t-2 border-t-[#2B5D87] rounded-xl col-span-2 sm:col-span-1 shadow-md hover:border-[#2B5D87] transition-all">
          <div className="text-[11px] font-mono text-[#C8BDAA] uppercase font-semibold flex items-center justify-between">
            <span>Expired Challenges</span>
            <Clock size={13} className="text-[#2B5D87]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#FAF7F0] tabular-nums mt-1">
            {expiredCount}
          </div>
          <div className="text-[10px] text-[#C8BDAA] font-mono mt-0.5">&gt;60s time skew</div>
        </div>
      </div>

      {/* Simulation Condition Modifiers */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-3.5 px-4 flex flex-wrap items-center justify-between gap-3 text-xs">
        <span className="font-semibold text-[#FAF7F0]">Testbench Tamper Injection:</span>
        <div className="flex flex-wrap items-center gap-5">
          <label className="flex items-center gap-2 cursor-pointer text-[#C8BDAA] hover:text-[#FAF7F0]">
            <input
              type="checkbox"
              checked={triggerReplay}
              onChange={(e) => setTriggerReplay(e.target.checked)}
              className="accent-[#C47A5A] rounded"
            />
            <span>Inject Replay Attack (Resubmit stale nonce)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-[#C8BDAA] hover:text-[#FAF7F0]">
            <input
              type="checkbox"
              checked={tamperSig}
              onChange={(e) => setTamperSig(e.target.checked)}
              className="accent-[#C47A5A] rounded"
            />
            <span>Corrupt Digital Signature (Simulate forgery)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-[#C8BDAA] hover:text-[#FAF7F0]">
            <input
              type="checkbox"
              checked={triggerSkew}
              onChange={(e) => setTriggerSkew(e.target.checked)}
              className="accent-[#C47A5A] rounded"
            />
            <span>Skew Timestamp (&gt;300s window violation)</span>
          </label>
        </div>
      </div>

      {/* Visual Animated Security Pipeline */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound size={16} className="text-[#2B5D87]" />
            <h3 className="text-xs font-semibold text-[#FAF7F0]">Challenge-Response Pipeline State</h3>
          </div>
          <span className="font-mono text-xs text-[#E8DCC8] uppercase font-bold">{pipelineState.replace('_', ' ')}</span>
        </div>

        {/* 6 Stages Graphic */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2.5 text-center text-xs">
          <div
            className={`p-3 rounded-lg border transition-all ${
              pipelineState !== 'WAITING'
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] text-[#C8BDAA] mb-1">01. INITIATE</div>
            <div className="font-semibold text-xs truncate">Device Request</div>
            <div className="text-[10px] text-[#C8BDAA] font-mono mt-1">Bound to MAC/IP</div>
          </div>

          <div
            className={`p-3 rounded-lg border transition-all ${
              ['CHALLENGE_ISSUED', 'SIGNING', 'VERIFYING', 'VERIFIED', 'FAILED', 'EXPIRED', 'REPLAY_DETECTED'].includes(pipelineState)
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] text-[#C8BDAA] mb-1">02. CHALLENGE</div>
            <div className="font-semibold text-xs truncate">Nonce Generation</div>
            <div className="text-[10px] text-[#C8BDAA] font-mono mt-1">32B CSPRNG</div>
          </div>

          <div
            className={`p-3 rounded-lg border transition-all ${
              ['SIGNING', 'VERIFYING', 'VERIFIED', 'FAILED', 'EXPIRED', 'REPLAY_DETECTED'].includes(pipelineState)
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] text-[#C8BDAA] mb-1">03. SIGN</div>
            <div className="font-semibold text-xs truncate">Hardware Signing</div>
            <div className="text-[10px] text-[#C8BDAA] font-mono mt-1">Private Key</div>
          </div>

          <div
            className={`p-3 rounded-lg border transition-all ${
              ['VERIFYING', 'VERIFIED', 'FAILED', 'EXPIRED', 'REPLAY_DETECTED'].includes(pipelineState)
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] text-[#C8BDAA] mb-1">04. CRYPTO VERIFY</div>
            <div className="font-semibold text-xs truncate">Public Key Match</div>
            <div className="text-[10px] text-[#C8BDAA] font-mono mt-1">OpenSSL EVP</div>
          </div>

          <div
            className={`p-3 rounded-lg border transition-all ${
              ['VERIFIED', 'FAILED', 'EXPIRED', 'REPLAY_DETECTED'].includes(pipelineState)
                ? 'bg-[#102A4D] border-[#2B5D87] text-[#FAF7F0]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] text-[#C8BDAA] mb-1">05. REPLAY CHECK</div>
            <div className="font-semibold text-xs truncate">Single-Use Nonce</div>
            <div className="text-[10px] text-[#C8BDAA] font-mono mt-1">Freshness &lt;60s</div>
          </div>

          <div
            className={`p-3 rounded-lg border transition-all ${
              pipelineState === 'VERIFIED'
                ? 'bg-[#08182D] border-[#E8DCC8] text-[#E8DCC8]'
                : pipelineState === 'REPLAY_DETECTED' || pipelineState === 'FAILED' || pipelineState === 'EXPIRED'
                ? 'bg-[#08182D] border-[#C47A5A] text-[#C47A5A]'
                : 'bg-[#08182D] border-[#294563] text-[#C8BDAA]'
            }`}
          >
            <div className="font-mono text-[10px] mb-1">06. DECISION</div>
            <div className="font-bold text-xs truncate">
              {pipelineState === 'VERIFIED'
                ? 'AUTHENTICATED'
                : pipelineState === 'REPLAY_DETECTED'
                ? 'REPLAY BLOCKED'
                : pipelineState === 'EXPIRED'
                ? 'EXPIRED'
                : pipelineState === 'FAILED'
                ? 'REJECTED'
                : 'Awaiting Run'}
            </div>
            <div className="text-[10px] font-mono mt-1">Zero-Trust Gate</div>
          </div>
        </div>

        {/* Detailed Session Telemetry if available */}
        {simDetails && (
          <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-3 font-mono text-xs animate-in fade-in">
            <div className="flex items-center justify-between border-b border-[#294563]/60 pb-2">
              <span className="font-bold text-[#FAF7F0]">Session Cryptographic Manifest</span>
              <span className="text-[#E8DCC8] font-bold tabular-nums">
                Verified in {simDetails.step4_verification.latencyMs} ms
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px]">
              <div>
                <span className="text-[#C8BDAA] block mb-0.5">32-Byte Nonce:</span>
                <span className="text-[#FAF7F0] break-all">{simDetails.step2_challenge.nonce}</span>
              </div>
              <div>
                <span className="text-[#C8BDAA] block mb-0.5">Signed Digest Payload:</span>
                <span className="text-[#E8DCC8] break-all">{simDetails.step3_device_signature.signedPayload}</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-[11px] pt-1 border-t border-[#294563]/40">
              <div className="flex items-center gap-1.5">
                <span className="text-[#C8BDAA]">Signature:</span>
                {simDetails.step4_verification.signatureValid ? (
                  <span className="text-[#E8DCC8] font-bold">VALID</span>
                ) : (
                  <span className="text-[#C47A5A] font-bold">INVALID</span>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[#C8BDAA]">Timestamp Freshness:</span>
                {simDetails.step4_verification.timestampValid ? (
                  <span className="text-[#E8DCC8] font-bold">VALID</span>
                ) : (
                  <span className="text-[#C47A5A] font-bold">EXPIRED / SKEWED</span>
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[#C8BDAA]">Nonce Single-Use:</span>
                {simDetails.step4_verification.nonceValid ? (
                  <span className="text-[#E8DCC8] font-bold">CONSUMED ONCE</span>
                ) : (
                  <span className="text-[#C47A5A] font-bold">REPLAY DETECTED</span>
                )}
              </div>
              <div className="flex items-center gap-1.5 ml-auto">
                <span className="text-[#C8BDAA]">Policy Decision:</span>
                <StatusBadge status={simDetails.step4_verification.policyDecision} size="sm" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ============================================================== */}
      {/* 2. AUTHENTICATION TIMELINE & ATTEMPTS LEDGER                   */}
      {/* ============================================================== */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History size={16} className="text-[#2B5D87]" />
            <h3 className="text-xs font-semibold text-[#FAF7F0]">Authentication Attempts & Outcomes Ledger</h3>
          </div>
          <span className="text-[11px] font-mono text-[#C8BDAA]">{authAttempts.length} Records</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#294563] bg-[#08182D]/80 text-[#C8BDAA] font-mono text-[11px] uppercase tracking-wider">
                <th className="py-2.5 px-3">Device</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Nonce Status</th>
                <th className="py-2.5 px-3">Signature Status</th>
                <th className="py-2.5 px-3">Timestamp Status</th>
                <th className="py-2.5 px-3">Identity Status</th>
                <th className="py-2.5 px-3">Final Decision</th>
                <th className="py-2.5 px-3 text-right">Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#294563]/40 font-mono">
              {authAttempts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-xs text-[#C8BDAA]">
                    No authentication events recorded yet.
                  </td>
                </tr>
              ) : (
                authAttempts.map((attempt) => {
                  let outcomeLabel = 'AUTHENTICATED';
                  let outcomeColor = 'text-[#E8DCC8]';

                  if (attempt.result === 'REPLAY_BLOCKED') {
                    outcomeLabel = 'REPLAY BLOCKED';
                    outcomeColor = 'text-[#C47A5A] font-bold';
                  } else if (attempt.result === 'EXPIRED') {
                    outcomeLabel = 'EXPIRED';
                    outcomeColor = 'text-[#C47A5A]';
                  } else if (attempt.result === 'FAILED') {
                    outcomeLabel = 'REJECTED';
                    outcomeColor = 'text-[#C47A5A]';
                  }

                  return (
                    <tr key={attempt.id} className="hover:bg-[#102A4D]/40">
                      <td className="py-2.5 px-3 font-sans font-medium text-[#FAF7F0]">
                        <div>{attempt.deviceName}</div>
                        <div className="text-[10px] text-[#C8BDAA] font-mono">{attempt.deviceId} · {attempt.algorithm}</div>
                      </td>

                      <td className="py-2.5 px-3 text-[11px] text-[#C8BDAA] tabular-nums whitespace-nowrap">
                        {new Date(attempt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>

                      <td className="py-2.5 px-3">
                        {attempt.nonceValid ? (
                          <span className="text-[#E8DCC8]">VALID (SINGLE-USE)</span>
                        ) : (
                          <span className="text-[#C47A5A] font-bold">REUSED NONCE</span>
                        )}
                      </td>

                      <td className="py-2.5 px-3">
                        {attempt.signatureValid ? (
                          <span className="text-[#E8DCC8]">VERIFIED</span>
                        ) : (
                          <span className="text-[#C47A5A] font-bold">REJECTED</span>
                        )}
                      </td>

                      <td className="py-2.5 px-3">
                        {attempt.timestampValid ? (
                          <span className="text-[#E8DCC8]">FRESH (&lt;60s)</span>
                        ) : (
                          <span className="text-[#C47A5A]">SKEWED</span>
                        )}
                      </td>

                      <td className="py-2.5 px-3">
                        <span className="text-[#E8DCC8]">ENROLLED SPKI</span>
                      </td>

                      <td className="py-2.5 px-3">
                        <span className={`font-semibold ${outcomeColor}`}>
                          {outcomeLabel}
                        </span>
                      </td>

                      <td className="py-2.5 px-3 text-right tabular-nums text-[#C8BDAA]">
                        {attempt.latencyMs} ms
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
