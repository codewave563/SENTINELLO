import React, { useState, useEffect } from 'react';
import {
  Crosshair,
  Play,
  RotateCcw,
  CheckCircle2,
  ShieldAlert,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  FastForward,
  Info,
} from 'lucide-react';
import type { AttackScenario, AttackSimulationRun, Device } from '../../types/index.ts';
import {
  fetchAttackScenarios,
  runAllAttackScenarios,
  runAttackScenario,
} from '../../services/api.ts';
import { RiskBadge } from '../ui/RiskBadge.tsx';

interface AttackSimulatorViewProps {
  devices: Device[];
  onRefresh: () => void;
}

export const AttackSimulatorView: React.FC<AttackSimulatorViewProps> = ({ devices, onRefresh }) => {
  const [scenarios, setScenarios] = useState<AttackScenario[]>([]);
  const [selectedTargetDeviceId, setSelectedTargetDeviceId] = useState<string>(
    devices.find((d) => d.status !== 'BLOCKED')?.id || devices[0]?.id || 'IOT-ESP32-07'
  );
  const [loading, setLoading] = useState(false);
  const [activeRun, setActiveRun] = useState<AttackSimulationRun | null>(null);
  const [runningScenarioId, setRunningScenarioId] = useState<string | null>(null);
  const [batchRunning, setBatchRunning] = useState(false);
  const [batchResults, setBatchResults] = useState<AttackSimulationRun[]>([]);

  useEffect(() => {
    fetchAttackScenarios()
      .then(setScenarios)
      .catch((err) => console.error('Fetch scenarios error:', err));
  }, []);

  const handleRunSingleScenario = async (scenarioId: string) => {
    setRunningScenarioId(scenarioId);
    setActiveRun(null);
    try {
      const run = await runAttackScenario(scenarioId, selectedTargetDeviceId);
      setActiveRun(run);
      onRefresh();
    } catch (err) {
      console.error('Run scenario error:', err);
    } finally {
      setRunningScenarioId(null);
    }
  };

  const handleRunAll = async () => {
    setBatchRunning(true);
    setBatchResults([]);
    try {
      const results = await runAllAttackScenarios();
      setBatchResults(results);
      onRefresh();
    } catch (err) {
      console.error('Run all error:', err);
    } finally {
      setBatchRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Defensive Cyber Range</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">11 Controlled Defensive Scenarios</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            Defensive Attack Simulation & Automated Response Suite
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Controlled simulation of IoT threat vectors to validate real-time boundary detection, cryptographic replay rejection, and Zero-Trust policy enforcement.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#C8BDAA]">Target Node:</span>
            <select
              value={selectedTargetDeviceId}
              onChange={(e) => setSelectedTargetDeviceId(e.target.value)}
              className="bg-[#08182D] border border-[#294563] rounded px-3 py-1.5 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
            >
              {devices.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.id})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleRunAll}
            disabled={batchRunning || runningScenarioId !== null}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded text-xs font-semibold text-[#08182D] bg-[#E8DCC8] hover:bg-[#FAF7F0] transition-colors shrink-0 shadow-xs"
          >
            <FastForward size={13} className="fill-current" />
            <span>{batchRunning ? 'Simulating All 11...' : 'Run All 11 Scenarios'}</span>
          </button>
        </div>
      </div>

      {/* Active Pipeline Animation Frame (if a scenario just ran) */}
      {activeRun && (
        <div className="bg-[#0B1F3A] border border-[#C47A5A]/50 rounded-lg p-5 space-y-4 animate-in fade-in duration-300">
          <div className="flex items-center justify-between border-b border-[#294563]/60 pb-3">
            <div>
              <div className="text-xs font-mono uppercase text-[#C47A5A]">Scenario Execution Result</div>
              <h3 className="text-sm font-bold text-[#FAF7F0] mt-0.5">
                {activeRun.scenarioName}
              </h3>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono text-[#C8BDAA]">Target Device:</span>
              <div className="font-mono text-xs font-semibold text-[#FAF7F0]">
                {activeRun.targetDeviceName} ({activeRun.targetDeviceId})
              </div>
            </div>
          </div>

          {/* 6-Phase Pipeline */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-[#FAF7F0]">Defensive Mitigation Pipeline:</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2">
              {activeRun.phases.map((phase) => (
                <div
                  key={phase.phase}
                  className="p-3 bg-[#08182D] border border-[#294563] rounded space-y-1 text-xs"
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#C8BDAA]">
                    <span>PHASE {phase.phase}</span>
                    <span
                      className={`font-bold ${
                        phase.status === 'DETECTED' || phase.status === 'MITIGATED'
                          ? 'text-[#C47A5A]'
                          : 'text-[#E8DCC8]'
                      }`}
                    >
                      {phase.status}
                    </span>
                  </div>
                  <div className="font-semibold text-[#FAF7F0] truncate">{phase.name}</div>
                  <p className="text-[10px] text-[#C8BDAA] line-clamp-3 leading-relaxed mt-1">
                    {phase.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Response summary banner */}
          <div className="p-3 bg-[#08182D] border border-[#294563] rounded flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <ShieldAlert size={16} className="text-[#C47A5A]" />
              <span className="text-[#FAF7F0]">{activeRun.summary}</span>
            </div>
            <div className="flex items-center gap-2 font-mono shrink-0">
              <span className="text-[#C8BDAA]">Policy Enforced:</span>
              <span className="px-2 py-0.5 rounded bg-[#102A4D] border border-[#C47A5A] text-[#C47A5A] font-bold">
                {activeRun.finalDecision}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Scenarios Grid (All 11 scenarios) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {scenarios.map((scenario) => {
          const isCurrentRunning = runningScenarioId === scenario.id;
          return (
            <div
              key={scenario.id}
              className="bg-[#0B1F3A] border border-[#294563] hover:border-[#2B5D87] rounded-lg p-4 flex flex-col justify-between space-y-3 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] text-[#C8BDAA]">{scenario.id}</span>
                  <RiskBadge level={scenario.severity} showScore={false} />
                </div>

                <h4 className="text-xs font-bold text-[#FAF7F0] leading-snug">{scenario.name}</h4>
                <p className="text-xs text-[#C8BDAA] line-clamp-2 leading-relaxed">
                  {scenario.description}
                </p>

                <div className="p-2 bg-[#08182D] border border-[#294563]/60 rounded text-[11px] font-mono text-[#C8BDAA]">
                  <span className="text-[#E8DCC8]">Mechanism: </span>
                  {scenario.technicalMechanism}
                </div>
              </div>

              <div className="pt-2 border-t border-[#294563]/60 flex items-center justify-between">
                <span className="text-[11px] text-[#C8BDAA] font-mono">
                  Response: <strong className="text-[#FAF7F0]">{scenario.expectedDefensiveResponse}</strong>
                </span>

                <button
                  onClick={() => handleRunSingleScenario(scenario.id)}
                  disabled={isCurrentRunning || batchRunning}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold text-[#FAF7F0] bg-[#2B5D87] hover:bg-[#2B5D87]/80 transition-colors"
                >
                  <Play size={12} className="fill-current" />
                  <span>{isCurrentRunning ? 'Executing...' : 'Run Scenario'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
