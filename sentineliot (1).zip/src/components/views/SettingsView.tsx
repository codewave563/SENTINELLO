import React, { useState } from 'react';
import {
  Settings,
  ShieldCheck,
  RotateCcw,
  Sliders,
  Bell,
  Sun,
  Moon,
  Database,
  CheckCircle2,
} from 'lucide-react';
import { resetDatabase } from '../../services/api.ts';

interface SettingsViewProps {
  onReset: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onReset }) => {
  const [resetLoading, setResetLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  // Policy configuration state
  const [challengeWindowSec, setChallengeWindowSec] = useState(60);
  const [quarantineThreshold, setQuarantineThreshold] = useState(75);
  const [restrictThreshold, setRestrictThreshold] = useState(55);
  const [enforceSha256, setEnforceSha256] = useState(true);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [audioAlerts, setAudioAlerts] = useState(false);

  const handleResetFleet = async () => {
    if (!confirm('Reset all devices, active threats, and audit logs to the initial nominal demo state?')) return;
    setResetLoading(true);
    setResetSuccess(false);
    try {
      await resetDatabase();
      setResetSuccess(true);
      onReset();
      setTimeout(() => setResetSuccess(false), 3000);
    } catch (err) {
      console.error('Reset error:', err);
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Administration</span>
          <span className="text-xs text-[#294563]">·</span>
          <span className="text-xs text-[#C8BDAA]">Zero-Trust Enforcement Policies</span>
        </div>
        <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
          SentinelIoT SOC Platform Configuration
        </h2>
        <p className="text-xs text-[#C8BDAA] mt-1">
          Configure cryptographic thresholds, challenge expiry windows, automated quarantine rules, and reset the synthetic demonstration fleet.
        </p>
      </div>

      {/* Section 1: Zero-Trust Security Policies */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
        <div className="flex items-center gap-2 border-b border-[#294563]/60 pb-3">
          <ShieldCheck size={16} className="text-[#2B5D87]" />
          <h3 className="text-xs font-semibold text-[#FAF7F0]">Zero-Trust Governance & Thresholds</h3>
        </div>

        <div className="space-y-4 text-xs">
          <div className="space-y-1">
            <div className="flex justify-between">
              <label className="text-[#FAF7F0] font-medium">Automated Quarantine Threshold (Risk Score)</label>
              <span className="font-mono text-[#C47A5A] font-bold">{quarantineThreshold} / 100</span>
            </div>
            <input
              type="range"
              min="50"
              max="95"
              value={quarantineThreshold}
              onChange={(e) => setQuarantineThreshold(Number(e.target.value))}
              className="w-full accent-[#C47A5A]"
            />
            <p className="text-[11px] text-[#C8BDAA]">
              Devices with risk scores exceeding this value are automatically partitioned into an isolated VLAN.
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between">
              <label className="text-[#FAF7F0] font-medium">Restriction Threshold (Read-Only Mode)</label>
              <span className="font-mono text-[#E8DCC8] font-bold">{restrictThreshold} / 100</span>
            </div>
            <input
              type="range"
              min="30"
              max="70"
              value={restrictThreshold}
              onChange={(e) => setRestrictThreshold(Number(e.target.value))}
              className="w-full accent-[#2B5D87]"
            />
            <p className="text-[11px] text-[#C8BDAA]">
              Actuator command privileges are revoked; telemetry rate-limited.
            </p>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between">
              <label className="text-[#FAF7F0] font-medium">Cryptographic Nonce Freshness Window (Seconds)</label>
              <span className="font-mono text-[#FAF7F0] font-bold">{challengeWindowSec}s</span>
            </div>
            <input
              type="range"
              min="15"
              max="300"
              value={challengeWindowSec}
              onChange={(e) => setChallengeWindowSec(Number(e.target.value))}
              className="w-full accent-[#2B5D87]"
            />
            <p className="text-[11px] text-[#C8BDAA]">
              Maximum timestamp skew tolerance for signed challenges before triggering a time-skew replay block.
            </p>
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={enforceSha256}
                onChange={(e) => setEnforceSha256(e.target.checked)}
                className="accent-[#2B5D87] rounded"
              />
              <span className="text-[#FAF7F0] font-medium">Enforce FIPS 186-4 SHA-256 Digest Minimum</span>
            </label>
            <p className="text-[11px] text-[#C8BDAA] ml-6">
              Rejects any legacy MD5 / SHA-1 signature submissions at API gateway.
            </p>
          </div>
        </div>
      </div>

      {/* Section 2: Alert Notifications */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
        <div className="flex items-center gap-2 border-b border-[#294563]/60 pb-3">
          <Bell size={16} className="text-[#2B5D87]" />
          <h3 className="text-xs font-semibold text-[#FAF7F0]">Incident Notification Dispatch</h3>
        </div>

        <div className="space-y-3 text-xs">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="accent-[#2B5D87] rounded"
            />
            <span className="text-[#FAF7F0] font-medium">SOC Critical Threat Email Paging</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={audioAlerts}
              onChange={(e) => setAudioAlerts(e.target.checked)}
              className="accent-[#2B5D87] rounded"
            />
            <span className="text-[#FAF7F0] font-medium">Browser Auditory Alarm on Quarantine Event</span>
          </label>
        </div>
      </div>

      {/* Section 3: Reset Demonstration Data */}
      <div className="bg-[#0B1F3A] border border-[#C47A5A]/50 rounded-lg p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Database size={16} className="text-[#C47A5A]" />
          <h3 className="text-xs font-semibold text-[#FAF7F0]">Demonstration Fleet Reset</h3>
        </div>

        <p className="text-xs text-[#C8BDAA]">
          Reset all in-memory database records to the initial synthetic fleet state. Clears all active threat alerts, nonces, and attack simulation runs, restoring clean nominal baselines.
        </p>

        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={handleResetFleet}
            disabled={resetLoading}
            className="px-4 py-2 rounded text-xs font-semibold bg-[#08182D] border border-[#C47A5A] text-[#C47A5A] hover:bg-[#C47A5A]/10 transition-colors"
          >
            {resetLoading ? 'Resetting Fleet Database...' : 'Reset Fleet to Nominal State'}
          </button>

          {resetSuccess && (
            <span className="flex items-center gap-1 text-xs text-[#E8DCC8] font-mono">
              <CheckCircle2 size={14} />
              Fleet state reset successfully!
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
