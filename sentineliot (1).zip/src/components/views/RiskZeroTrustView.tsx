import React, { useState, useEffect } from 'react';
import {
  Scale,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Lock,
  ArrowRight,
  TrendingDown,
  Cpu,
  Layers,
  Activity,
  Server,
  Zap,
} from 'lucide-react';
import type { Device, ZeroTrustEvaluation } from '../../types/index.ts';
import { evaluateDeviceZeroTrust } from '../../services/api.ts';
import { StatusBadge } from '../ui/StatusBadge.tsx';
import { RiskBadge } from '../ui/RiskBadge.tsx';

interface RiskZeroTrustViewProps {
  devices: Device[];
  onRefresh: () => void;
}

export const RiskZeroTrustView: React.FC<RiskZeroTrustViewProps> = ({ devices, onRefresh }) => {
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>(
    devices.find((d) => d.status === 'SUSPICIOUS')?.id || devices[0]?.id || 'IOT-ESP32-07'
  );
  const [evaluation, setEvaluation] = useState<ZeroTrustEvaluation | null>(null);
  const [loading, setLoading] = useState(false);

  const selectedDevice = devices.find((d) => d.id === selectedDeviceId) || devices[0];

  const loadEvaluation = async (devId: string) => {
    setLoading(true);
    try {
      const data = await evaluateDeviceZeroTrust(devId);
      setEvaluation(data);
    } catch (err) {
      console.error('Zero-Trust eval error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedDeviceId) {
      loadEvaluation(selectedDeviceId);
    }
  }, [selectedDeviceId]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#C47A5A]">Policy Engine</span>
            <span className="text-xs text-[#294563]">·</span>
            <span className="text-xs text-[#C8BDAA]">Dynamic Risk-Based Access Control</span>
          </div>
          <h2 className="text-base font-bold text-[#FAF7F0] mt-0.5">
            ZERO TRUST DECISION ENGINE — "Never Trust. Always Verify."
          </h2>
          <p className="text-xs text-[#C8BDAA] mt-1 max-w-2xl">
            Continuous automated gatekeeper computing dynamic risk from hardware identity, challenge verification, AI anomaly scores, and threat exposure to enforce least-privilege containment.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedDeviceId}
            onChange={(e) => setSelectedDeviceId(e.target.value)}
            className="bg-[#08182D] border border-[#294563] rounded px-3 py-2 text-xs text-[#FAF7F0] font-mono focus:outline-hidden"
          >
            {devices.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.id}) - {d.status}
              </option>
            ))}
          </select>

          <button
            onClick={() => loadEvaluation(selectedDeviceId)}
            disabled={loading}
            className="p-2 rounded bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0] cursor-pointer"
            title="Re-evaluate device"
          >
            <RotateCcw size={15} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* ============================================================== */}
      {/* 1. ADVANCED ZERO TRUST DECISION ENGINE PIPELINE (SEC 13)       */}
      {/* ============================================================== */}
      {evaluation && (
        <div className="bg-[#0B1F3A] border border-[#294563] rounded-xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-[#294563]/60 pb-3">
            <div className="flex items-center gap-2">
              <Scale size={18} className="text-[#2B5D87]" />
              <h3 className="text-sm font-bold text-[#FAF7F0]">
                ZERO TRUST MULTI-TIER DECISION ENGINE
              </h3>
            </div>
            <span className="text-xs font-mono text-[#E8DCC8] uppercase font-bold">
              Target: {selectedDevice.name} ({selectedDevice.id})
            </span>
          </div>

          {/* 4-Stage Architectural Pipeline Display */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            {/* STAGE 1: 6 INPUT TELEMETRY PILLARS */}
            <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5">
              <div className="text-[10px] font-mono text-[#C8BDAA] uppercase tracking-wider font-semibold border-b border-[#294563]/40 pb-1">
                STAGE 1 · INPUT SIGNALS
              </div>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">IDENTITY:</span>
                  <span className="text-[#E8DCC8] font-bold flex items-center gap-1">
                    <CheckCircle2 size={11} /> VERIFIED ({selectedDevice.cryptoAlgorithm})
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">AUTH SESSION:</span>
                  <span className={selectedDevice.telemetry.failedAuthCount === 0 ? 'text-[#E8DCC8] font-bold' : 'text-[#C47A5A] font-bold'}>
                    {selectedDevice.telemetry.failedAuthCount === 0 ? '✓ VALID' : `⚠ ${selectedDevice.telemetry.failedAuthCount} FAILS`}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">DEVICE HEALTH:</span>
                  <span className={selectedDevice.firmwareAgeMonths > 18 ? 'text-[#C47A5A]' : 'text-[#FAF7F0]'}>
                    {selectedDevice.firmwareAgeMonths} mos firmware
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">AI BEHAVIOUR:</span>
                  <span className={evaluation.behaviouralTrust < 50 ? 'text-[#C47A5A] font-bold' : 'text-[#E8DCC8]'}>
                    {evaluation.behaviouralTrust < 50 ? '⚠ ANOMALOUS' : '✓ NOMINAL'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">NETWORK IP:</span>
                  <span className="text-[#FAF7F0]">{selectedDevice.ipAddress}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#C8BDAA]">THREAT HISTORY:</span>
                  <span className={evaluation.threatPenalty > 0 ? 'text-[#C47A5A] font-bold' : 'text-[#E8DCC8]'}>
                    {evaluation.threatPenalty > 0 ? `⚠ -${evaluation.threatPenalty} PTS` : '✓ CLEAN'}
                  </span>
                </div>
              </div>
            </div>

            {/* STAGE 2: RISK ENGINE */}
            <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5">
              <div className="text-[10px] font-mono text-[#C8BDAA] uppercase tracking-wider font-semibold border-b border-[#294563]/40 pb-1">
                STAGE 2 · RISK ENGINE
              </div>
              <div className="space-y-2">
                <div>
                  <span className="text-[#C8BDAA] text-[11px] block">Computed Fleet Risk:</span>
                  <div className="text-2xl font-bold font-mono text-[#FAF7F0] mt-0.5 tabular-nums">
                    {evaluation.riskScore} <span className="text-xs text-[#C8BDAA]">/ 100</span>
                  </div>
                </div>
                <div>
                  <span className="text-[#C8BDAA] text-[11px] block">Risk Classification Tier:</span>
                  <div className="mt-1"><RiskBadge level={evaluation.riskLevel} score={evaluation.riskScore} /></div>
                </div>
                <p className="text-[11px] text-[#C8BDAA] leading-relaxed pt-1">
                  Inverse of 6-factor trust weighting minus active security penalty deductions.
                </p>
              </div>
            </div>

            {/* STAGE 3: POLICY ARBITRATION */}
            <div className="p-4 bg-[#08182D] border border-[#294563] rounded-lg space-y-2.5">
              <div className="text-[10px] font-mono text-[#C8BDAA] uppercase tracking-wider font-semibold border-b border-[#294563]/40 pb-1">
                STAGE 3 · POLICY ENGINE
              </div>
              <div className="space-y-1.5 font-mono text-[11px]">
                <div className="text-[#C8BDAA]">Governing Principle:</div>
                <div className="text-[#FAF7F0] font-bold">Least Privilege Required</div>
                <div className="pt-2 text-[#C8BDAA]">Rule Evaluated:</div>
                <div className="text-[#E8DCC8] font-bold">
                  {evaluation.riskScore >= 75
                    ? 'Risk &ge; 75 → Auto Quarantine'
                    : evaluation.riskScore >= 55
                    ? 'Risk &ge; 55 → Command Restriction'
                    : evaluation.riskScore >= 30
                    ? 'Risk &ge; 30 → Step-Up Auth'
                    : 'Risk &lt; 30 → Full Access'}
                </div>
              </div>
            </div>

            {/* STAGE 4: FINAL DECISION */}
            <div className={`p-4 rounded-lg border space-y-2.5 ${
              evaluation.policyDecision === 'ALLOW'
                ? 'bg-[#08182D] border-[#E8DCC8]'
                : evaluation.policyDecision === 'QUARANTINE' || evaluation.policyDecision === 'BLOCK'
                ? 'bg-[#08182D] border-[#C47A5A] ring-1 ring-[#C47A5A]'
                : 'bg-[#08182D] border-[#2B5D87]'
            }`}>
              <div className="text-[10px] font-mono uppercase tracking-wider text-[#C8BDAA] font-semibold border-b border-[#294563]/40 pb-1">
                STAGE 4 · FINAL DECISION
              </div>
              <div>
                <span className="text-[11px] text-[#C8BDAA] font-mono block">Enforced Access Gate:</span>
                <div className="text-xl font-bold font-mono text-[#FAF7F0] uppercase mt-1">
                  {evaluation.policyDecision}
                </div>
              </div>
              <div className="text-[11px] text-[#E8DCC8] font-mono pt-1">
                {evaluation.policyDecision === 'ALLOW'
                  ? '✓ ACCESS PERMITTED'
                  : evaluation.policyDecision === 'QUARANTINE'
                  ? '⚠ ISOLATED TO VLAN 99'
                  : evaluation.policyDecision === 'RESTRICT'
                  ? '⚠ READ-ONLY TELEMETRY'
                  : '⚠ STEP-UP AUTH REQUIRED'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. TRUST FACTOR RADAR & EXPLAINABLE REASONING DECOMPOSITION    */}
      {/* ============================================================== */}
      {evaluation && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 6 Trust Factor Pillars */}
          <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-[#FAF7F0]">Continuous Trust Factor Pillars</h3>
              <span className="text-[11px] font-mono text-[#E8DCC8]">
                Overall Trust: <strong className="tabular-nums font-bold">{evaluation.overallTrustScore} / 100</strong>
              </span>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#FAF7F0] font-medium">1. Cryptographic Identity Trust (Weight: 20%)</span>
                  <span className="font-mono text-[#FAF7F0]">{evaluation.identityTrust} / 100</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#2B5D87]" style={{ width: `${evaluation.identityTrust}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#FAF7F0] font-medium">2. Authentication Session Trust (Weight: 25%)</span>
                  <span className="font-mono text-[#FAF7F0]">{evaluation.authTrust} / 100</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#2B5D87]" style={{ width: `${evaluation.authTrust}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#FAF7F0] font-medium">3. Hardware & Firmware Health (Weight: 15%)</span>
                  <span className="font-mono text-[#FAF7F0]">{evaluation.deviceHealth} / 100</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#2B5D87]" style={{ width: `${evaluation.deviceHealth}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#FAF7F0] font-medium">4. AI Behavioural Anomaly Inversion (Weight: 25%)</span>
                  <span className="font-mono text-[#FAF7F0]">{evaluation.behaviouralTrust} / 100</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#2B5D87]" style={{ width: `${evaluation.behaviouralTrust}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#FAF7F0] font-medium">5. Network Context & Destination Confinement (Weight: 15%)</span>
                  <span className="font-mono text-[#FAF7F0]">{evaluation.networkContext} / 100</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#2B5D87]" style={{ width: `${evaluation.networkContext}%` }} />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-[#C47A5A] font-medium">6. Threat History Deduction Penalty</span>
                  <span className="font-mono text-[#C47A5A]">-{evaluation.threatPenalty} pts</span>
                </div>
                <div className="w-full h-1.5 bg-[#08182D] rounded-full overflow-hidden">
                  <div className="h-full bg-[#C47A5A]" style={{ width: `${evaluation.threatPenalty}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Explainable Risk Decomposition */}
          <div className="bg-[#0B1F3A] border border-[#294563] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-[#FAF7F0]">
                Explainable Risk Engine Reasoning
              </h3>
              <RiskBadge level={evaluation.riskLevel} score={evaluation.riskScore} />
            </div>

            <p className="text-xs text-[#C8BDAA]">
              Transparent forensic breakdown of every penalty delta contributing to elevated risk.
            </p>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {evaluation.explainableFactors.map((factor, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded bg-[#08182D] border border-[#294563]/60 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] text-[#C8BDAA] uppercase">
                      [{factor.category}]
                    </span>
                    <span className="text-[#FAF7F0]">{factor.factor}</span>
                  </div>
                  <span className="font-mono tabular-nums text-[#C47A5A] font-semibold">
                    {factor.impact > 0 ? `+${factor.impact}` : '0'}
                  </span>
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#08182D] border border-[#294563] rounded flex items-center justify-between text-xs font-mono">
              <span className="text-[#C8BDAA]">Total Calculated Risk Score:</span>
              <span className="text-sm font-bold text-[#FAF7F0]">
                {evaluation.riskScore} — <span className="text-[#C47A5A]">{evaluation.riskLevel}</span>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
