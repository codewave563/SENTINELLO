import React from 'react';
import { CheckCircle2, AlertTriangle, ShieldAlert, Ban, Wifi, WifiOff } from 'lucide-react';
import type { DeviceStatus, PolicyDecision } from '../../types/index.ts';

interface StatusBadgeProps {
  status: DeviceStatus | PolicyDecision;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'md' }) => {
  const isSm = size === 'sm';
  const iconSize = isSm ? 11 : 13;
  const paddingClass = isSm ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  switch (status) {
    case 'TRUSTED':
    case 'ALLOW':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-semibold rounded-md transition-all shadow-xs bg-[#2B5D87]/15 text-[#2B5D87] border border-[#2B5D87]/40 ${paddingClass}`}
        >
          <CheckCircle2 size={iconSize} className="text-[#2B5D87] shrink-0" />
          <span>{status === 'ALLOW' ? 'Allowed' : 'Trusted'}</span>
        </span>
      );

    case 'ONLINE':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-semibold rounded-md transition-all shadow-xs bg-[#0B1F3A]/10 text-[#0B1F3A] border border-[#0B1F3A]/25 ${paddingClass}`}
        >
          <span className="relative flex h-2 w-2 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2B5D87] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#2B5D87]"></span>
          </span>
          <Wifi size={iconSize} className="text-[#2B5D87] shrink-0" />
          <span>Online</span>
        </span>
      );

    case 'OFFLINE':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium rounded-md transition-all bg-[#C8BDAA]/20 text-[#5A6578] border border-[#C8BDAA]/40 ${paddingClass}`}
        >
          <WifiOff size={iconSize} className="text-[#788599] shrink-0" />
          <span>Offline</span>
        </span>
      );

    case 'SUSPICIOUS':
    case 'STEP_UP_AUTH':
    case 'RESTRICT':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-semibold rounded-md transition-all shadow-xs bg-[#C47A5A]/15 text-[#A64F2D] border border-[#C47A5A]/40 ${paddingClass}`}
        >
          <AlertTriangle size={iconSize} className="text-[#C47A5A] shrink-0 animate-pulse-subtle" />
          <span>{status === 'STEP_UP_AUTH' ? 'Step-Up Auth' : status === 'RESTRICT' ? 'Restricted' : 'Suspicious'}</span>
        </span>
      );

    case 'QUARANTINED':
    case 'QUARANTINE':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-bold rounded-md transition-all shadow-xs bg-[#C47A5A]/25 text-[#923818] border border-[#C47A5A]/60 ${paddingClass}`}
        >
          <ShieldAlert size={iconSize} className="text-[#C47A5A] shrink-0 animate-bounce-subtle" />
          <span>Quarantined</span>
        </span>
      );

    case 'BLOCKED':
    case 'BLOCK':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-bold rounded-md transition-all shadow-xs bg-[#0B1F3A]/20 text-[#08182D] border border-[#0B1F3A]/40 ${paddingClass}`}
        >
          <Ban size={iconSize} className="text-[#C47A5A] shrink-0" />
          <span>Blocked</span>
        </span>
      );

    default:
      return (
        <span className={`inline-flex items-center gap-1 font-mono rounded bg-slate-100 text-slate-700 border border-slate-300 ${paddingClass}`}>
          {status}
        </span>
      );
  }
};

