import React from 'react';
import { ShieldCheck, ShieldAlert, AlertOctagon, AlertTriangle } from 'lucide-react';
import type { RiskLevel } from '../../types/index.ts';

interface RiskBadgeProps {
  level: RiskLevel;
  score?: number;
  showScore?: boolean;
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, score, showScore = true }) => {
  let icon = <ShieldCheck size={12} className="text-[#2B5D87] shrink-0" />;
  let badgeClasses = 'bg-[#2B5D87]/15 text-[#2B5D87] border-[#2B5D87]/30';

  if (level === 'MEDIUM') {
    icon = <AlertTriangle size={12} className="text-[#966E3A] shrink-0" />;
    badgeClasses = 'bg-[#E8DCC8]/50 text-[#855D2B] border-[#C8BDAA]';
  } else if (level === 'HIGH') {
    icon = <ShieldAlert size={12} className="text-[#C47A5A] shrink-0" />;
    badgeClasses = 'bg-[#C47A5A]/15 text-[#A64F2D] border-[#C47A5A]/40 font-semibold';
  } else if (level === 'CRITICAL') {
    icon = <AlertOctagon size={12} className="text-[#C47A5A] shrink-0 animate-pulse-subtle" />;
    badgeClasses = 'bg-[#C47A5A]/25 text-[#923818] border-[#C47A5A]/60 font-bold';
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[11px] font-mono border transition-all shadow-2xs ${badgeClasses}`}
    >
      {icon}
      <span>{level}</span>
      {showScore && score !== undefined && (
        <span className="opacity-80 font-bold tabular-nums">({score})</span>
      )}
    </span>
  );
};

