import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  ShieldAlert,
  AlertTriangle,
  X,
  ShieldCheck,
  Activity,
  KeyRound,
  Lock,
} from 'lucide-react';
import { runEndToEndDemo } from '../../services/api.ts';
import type { Device } from '../../types/index.ts';

interface EndToEndDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCompleted?: () => void;
}

interface DemoStepItem {
  step: number;
  title: string;
  detail: string;
  status: 'SUCCESS' | 'MITIGATED' | 'IN_PROGRESS';
  category: string;
}

export const EndToEndDemoModal: React.FC<EndToEndDemoModalProps> = ({
  isOpen,
  onClose,
  onCompleted,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(-1);
  const [demoSteps, setDemoSteps] = useState<DemoStepItem[]>([]);
  const [finalDevice, setFinalDevice] = useState<Device | null>(null);

  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;

  const isCancelledRef = useRef(false);

  // 15 Standardized Stages for the End-to-End Demo
  const ALL_15_STAGES: Omit<DemoStepItem, 'status'>[] = [
    { step: 1, title: 'Device Registration', detail: 'Creating new IoT asset in Zero-Trust asset catalog with hardware MAC and IP binding.', category: 'ENROLLMENT' },
    { step: 2, title: 'Cryptographic Key Generation', detail: 'OpenSSL generating dedicated Ed25519 keypair. SHA-256 SPKI fingerprint bound.', category: 'CRYPTOGRAPHY' },
    { step: 3, title: 'Server Challenge Creation', detail: '32-byte cryptographic CSPRNG nonce generated with single-use 60s expiration constraint.', category: 'AUTHENTICATION' },
    { step: 4, title: 'Device Signature Generation', detail: 'IoT node signs nonce challenge using private key in secure hardware enclave.', category: 'AUTHENTICATION' },
    { step: 5, title: 'Digital Signature Verification', detail: 'Zero-Trust gateway validates digital signature against enrolled public key (latency: 1.2ms).', category: 'CRYPTOGRAPHY' },
    { step: 6, title: 'Mutual Authentication Success', detail: 'Single-use nonce consumed. Session established; device transitioned to TRUSTED state.', category: 'AUTHENTICATION' },
    { step: 7, title: 'Nominal Telemetry Ingestion', detail: 'Sensor transmitting within calibrated baseline bounds (12 req/min, 2.1 pkts/sec).', category: 'TELEMETRY' },
    { step: 8, title: 'Simulated Behavioral Anomaly', detail: 'Injecting telemetry deviation: request surge to 145 req/min and unfamiliar destination IPs.', category: 'ANOMALY' },
    { step: 9, title: 'AI Anomaly Model Detection', detail: 'Isolation Forest ensemble flags out-of-distribution node with 88/100 anomaly index.', category: 'AI_DETECTION' },
    { step: 10, title: 'Dynamic Risk Engine Recalculation', detail: 'Calculated risk score elevated to 82/100 (CRITICAL tier) due to behavioral deviation.', category: 'RISK_ENGINE' },
    { step: 11, title: 'Zero-Trust Policy Arbitration', detail: 'Rule evaluated: Risk &ge; 75 triggers mandatory Zero-Trust QUARANTINE policy.', category: 'ZERO_TRUST' },
    { step: 12, title: 'Security Threat Incident Generation', detail: 'Incident THR-8924 logged in SOC Threat Center with CRITICAL severity attribution.', category: 'INCIDENTS' },
    { step: 13, title: 'Automated Device Quarantine', detail: 'Node isolated to VLAN 99. Actuator command privileges revoked; outbound routes severed.', category: 'CONTAINMENT' },
    { step: 14, title: 'Tamper-Evident Audit Event Log', detail: 'Cryptographic forensic record committed to append-only tamper-evident audit ledger.', category: 'AUDIT' },
    { step: 15, title: 'Final System Posture Update', detail: 'SOC dashboard security posture recalculated: quarantined asset reflected in fleet telemetry.', category: 'POSTURE' },
  ];

  const handleStartOrRestartDemo = async () => {
    isCancelledRef.current = false;
    setIsRunning(true);
    setIsPaused(false);
    setCurrentStepIndex(0);
    setDemoSteps([]);
    setFinalDevice(null);

    try {
      // Execute backend E2E logic to create real records in store
      const backendResult = await runEndToEndDemo();
      setFinalDevice(backendResult.finalState);

      // Walk through all 15 stages visually
      for (let i = 0; i < ALL_15_STAGES.length; i++) {
        if (isCancelledRef.current) break;

        // Handle pause
        while (isPausedRef.current && !isCancelledRef.current) {
          await new Promise((r) => setTimeout(r, 200));
        }

        setCurrentStepIndex(i);
        const stage = ALL_15_STAGES[i];
        const isMitigated = ['ANOMALY', 'AI_DETECTION', 'RISK_ENGINE', 'ZERO_TRUST', 'INCIDENTS', 'CONTAINED', 'CONTAINMENT'].includes(stage.category);

        setDemoSteps((prev) => [
          ...prev,
          {
            ...stage,
            status: isMitigated ? 'MITIGATED' : 'SUCCESS',
          },
        ]);

        await new Promise((r) => setTimeout(r, 420));
      }

      setIsRunning(false);
      setIsPaused(false);
      if (onCompleted) onCompleted();
    } catch (err) {
      console.error('Demo run error:', err);
      setIsRunning(false);
    }
  };

  const handlePause = () => {
    setIsPaused(true);
  };

  const handleResume = () => {
    setIsPaused(false);
  };

  const handleClose = () => {
    isCancelledRef.current = true;
    setIsRunning(false);
    setIsPaused(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-[#08182D]/90 backdrop-blur-xs" onClick={!isRunning ? handleClose : undefined} />

      <div className="relative w-full max-w-4xl bg-[#0B1F3A] border border-[#294563] rounded-xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[92vh]">
        {/* Header with Controls */}
        <div className="px-6 py-4 border-b border-[#294563] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#08182D]/60">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#C47A5A] font-semibold bg-[#C47A5A]/15 border border-[#C47A5A]/30 px-2 py-0.5 rounded">
                Interactive E2E Simulation
              </span>
              <span className="text-xs text-[#294563]">·</span>
              <span className="text-xs text-[#C8BDAA] font-mono">15-Stage Zero-Trust Lifecycle</span>
            </div>
            <h3 className="text-base font-bold text-[#FAF7F0] mt-0.5">
              Automated Cryptographic Enrollment to AI Quarantine & Posture Recalculation
            </h3>
          </div>

          {/* Controls: PAUSE, RESUME, RESTART, CLOSE */}
          <div className="flex items-center gap-2 shrink-0">
            {isRunning && !isPaused && (
              <button
                onClick={handlePause}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-[#08182D] border border-[#294563] text-[#FAF7F0] hover:border-[#E8DCC8] transition-colors cursor-pointer"
              >
                <Pause size={12} />
                <span>Pause</span>
              </button>
            )}

            {isRunning && isPaused && (
              <button
                onClick={handleResume}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-[#E8DCC8] text-[#08182D] hover:bg-[#FAF7F0] transition-colors cursor-pointer"
              >
                <Play size={12} className="fill-current" />
                <span>Resume</span>
              </button>
            )}

            <button
              onClick={handleStartOrRestartDemo}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-[#08182D] border border-[#294563] text-[#C8BDAA] hover:text-[#FAF7F0] transition-colors cursor-pointer"
              title="Restart Sequence"
            >
              <RotateCcw size={12} />
              <span>Restart</span>
            </button>

            <button
              onClick={handleClose}
              className="p-1.5 text-[#C8BDAA] hover:text-[#FAF7F0] rounded-md hover:bg-[#102A4D] transition-colors cursor-pointer"
              title="Close Dialog"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {currentStepIndex === -1 ? (
            <div className="p-10 text-center border border-dashed border-[#294563] rounded-xl bg-[#08182D]/50 space-y-4">
              <div className="inline-flex p-3 rounded-full bg-[#102A4D] text-[#E8DCC8] border border-[#294563]">
                <ShieldCheck size={32} />
              </div>
              <div>
                <h4 className="text-base font-bold text-[#FAF7F0]">Ready to Initiate Complete 15-Stage Lifecycle</h4>
                <p className="text-xs text-[#C8BDAA] max-w-lg mx-auto mt-1 leading-relaxed">
                  Executing real server-side OpenSSL key generation, signed challenge mutual verification, simulated telemetry anomaly injection, and automated Zero-Trust quarantine containment.
                </p>
              </div>
              <button
                onClick={handleStartOrRestartDemo}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-lg text-xs font-bold text-[#08182D] bg-[#E8DCC8] hover:bg-[#FAF7F0] transition-colors cursor-pointer shadow-md"
              >
                <Play size={14} className="fill-current" />
                <span>START 15-STAGE DEMO SEQUENCE</span>
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Progress Bar & Status */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-[#C8BDAA] font-mono tabular-nums">
                  <span>
                    Lifecycle Status:{' '}
                    <strong className={isRunning ? (isPaused ? 'text-[#E8DCC8]' : 'text-[#2B5D87]') : 'text-[#E8DCC8]'}>
                      {isRunning ? (isPaused ? 'PAUSED' : 'EXECUTING LIVE...') : 'COMPLETED'}
                    </strong>
                  </span>
                  <span>{Math.min(15, demoSteps.length)} / 15 Stages</span>
                </div>
                <div className="w-full h-2 bg-[#08182D] rounded-full overflow-hidden border border-[#294563]/40">
                  <div
                    className="h-full bg-gradient-to-r from-[#2B5D87] via-[#E8DCC8] to-[#C47A5A] transition-all duration-300"
                    style={{ width: `${(Math.min(15, demoSteps.length) / 15) * 100}%` }}
                  />
                </div>
              </div>

              {/* 15 Steps Stream Container */}
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {demoSteps.map((step, idx) => (
                  <div
                    key={step.step}
                    className={`p-3.5 rounded-lg border text-xs flex items-start gap-3 transition-all ${
                      idx === demoSteps.length - 1 && isRunning
                        ? 'bg-[#102A4D] border-[#E8DCC8] shadow-md ring-1 ring-[#E8DCC8]/30'
                        : 'bg-[#08182D]/60 border-[#294563]/60'
                    }`}
                  >
                    <div className="shrink-0 mt-0.5">
                      {step.status === 'MITIGATED' ? (
                        <ShieldAlert size={16} className="text-[#C47A5A]" />
                      ) : (
                        <CheckCircle2 size={16} className="text-[#E8DCC8]" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-[#FAF7F0]">
                          <span className="font-mono text-[#C8BDAA] mr-1.5">{String(step.step).padStart(2, '0')}.</span>
                          {step.title}
                        </span>
                        <span
                          className={`text-[10px] font-mono uppercase font-bold px-1.5 py-0.5 rounded ${
                            step.status === 'MITIGATED'
                              ? 'bg-[#C47A5A]/15 text-[#C47A5A] border border-[#C47A5A]/30'
                              : 'bg-[#E8DCC8]/15 text-[#E8DCC8] border border-[#E8DCC8]/30'
                          }`}
                        >
                          {step.status === 'MITIGATED' ? 'Enforced' : 'Verified'}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#C8BDAA] mt-1 font-mono leading-relaxed">{step.detail}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Final Complete Summary Banner */}
              {!isRunning && finalDevice && (
                <div className="p-4 rounded-xl bg-[#08182D] border border-[#C47A5A]/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-in fade-in">
                  <div>
                    <div className="text-[10px] font-mono text-[#C47A5A] uppercase tracking-wider font-bold">
                      DEMO COMPLETED · FINAL NODE POSTURE
                    </div>
                    <div className="text-sm font-bold text-[#FAF7F0] mt-0.5">
                      {finalDevice.name} ({finalDevice.id})
                    </div>
                    <div className="text-xs text-[#C8BDAA] font-mono mt-1">
                      Status: <strong className="text-[#C47A5A]">{finalDevice.status}</strong> · Risk Score:{' '}
                      <strong className="text-[#C47A5A]">{finalDevice.riskScore}/100</strong> · Policy Enforced:{' '}
                      <strong className="text-[#E8DCC8]">QUARANTINE (VLAN 99)</strong>
                    </div>
                  </div>

                  <button
                    onClick={handleClose}
                    className="px-5 py-2.5 rounded-lg text-xs font-bold bg-[#E8DCC8] text-[#08182D] hover:bg-[#FAF7F0] transition-colors cursor-pointer shrink-0"
                  >
                    Close & Review SOC Dashboard
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
