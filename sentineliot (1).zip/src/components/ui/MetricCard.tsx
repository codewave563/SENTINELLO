import React from 'react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  trend?: {
    value: string;
    isPositive?: boolean;
  };
  highlight?: boolean;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  trend,
  highlight = false,
}) => {
  return (
    <div
      className={`p-4 rounded-lg border transition-colors ${
        highlight
          ? 'bg-[#0B1F3A] border-[#C47A5A]/50 shadow-sm'
          : 'bg-[#0B1F3A] border-[#294563] hover:border-[#2B5D87]'
      }`}
    >
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium text-[#C8BDAA]">{title}</span>
        {icon && <div className="text-[#2B5D87]">{icon}</div>}
      </div>

      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-2xl font-semibold tracking-tight text-[#FAF7F0] font-mono tabular-nums">
          {value}
        </span>
        {trend && (
          <span
            className={`text-xs font-mono tabular-nums ${
              trend.isPositive ? 'text-[#E8DCC8]' : 'text-[#C47A5A]'
            }`}
          >
            {trend.value}
          </span>
        )}
      </div>

      {subtitle && (
        <div className="mt-1 text-xs text-[#C8BDAA] line-clamp-1">{subtitle}</div>
      )}
    </div>
  );
};
