import React, { useState, useEffect } from 'react';
import { Search, Server, AlertTriangle, FileText, ChevronRight, X, ShieldCheck } from 'lucide-react';
import { searchGlobal } from '../../services/api.ts';
import type { Device, ThreatEvent, AuditLog } from '../../types/index.ts';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDevice: (device: Device) => void;
  onSelectThreat: (threat: ThreatEvent) => void;
  onSelectAudit?: (audit: AuditLog) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectDevice,
  onSelectThreat,
  onSelectAudit,
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [results, setResults] = useState<{
    devices: Device[];
    threats: ThreatEvent[];
    auditLogs: AuditLog[];
  }>({ devices: [], threats: [], auditLogs: [] });

  // Compute flattened list of items for keyboard navigation
  const allItems: { type: 'device' | 'threat' | 'audit'; data: any }[] = [
    ...results.devices.map((d) => ({ type: 'device' as const, data: d })),
    ...results.threats.map((t) => ({ type: 'threat' as const, data: t })),
    ...results.auditLogs.map((a) => ({ type: 'audit' as const, data: a })),
  ];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) onClose();

      if (isOpen && allItems.length > 0) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setSelectedIndex((prev) => (prev + 1) % allItems.length);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          setSelectedIndex((prev) => (prev - 1 + allItems.length) % allItems.length);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          const item = allItems[selectedIndex];
          if (item) {
            if (item.type === 'device') onSelectDevice(item.data);
            else if (item.type === 'threat') onSelectThreat(item.data);
            else if (item.type === 'audit' && onSelectAudit) onSelectAudit(item.data);
            onClose();
          }
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, allItems, selectedIndex, onSelectDevice, onSelectThreat, onSelectAudit]);

  useEffect(() => {
    if (!isOpen) return;
    const timer = setTimeout(async () => {
      if (!query.trim()) {
        setResults({ devices: [], threats: [], auditLogs: [] });
        setSelectedIndex(0);
        return;
      }
      setLoading(true);
      try {
        const data = await searchGlobal(query.trim());
        setResults(data);
        setSelectedIndex(0);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    }, 180);
    return () => clearTimeout(timer);
  }, [query, isOpen]);

  if (!isOpen) return null;

  const totalResults = allItems.length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-start justify-center pt-20 px-4">
      <div className="fixed inset-0 bg-[#08182D]/85 backdrop-blur-xs" onClick={onClose} />

      <div className="relative w-full max-w-2xl bg-[#0B1F3A] border border-[#294563] rounded-xl shadow-2xl overflow-hidden z-10">
        {/* Search Input Box */}
        <div className="flex items-center px-4 py-3.5 border-b border-[#294563] gap-3 bg-[#08182D]/50">
          <Search size={18} className="text-[#2B5D87] shrink-0" />
          <input
            type="text"
            placeholder="Search Device IDs, Names, Threat IDs, Auth challenges, or Audit logs..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent text-[#FAF7F0] placeholder-[#C8BDAA]/50 text-xs sm:text-sm focus:outline-hidden"
          />
          <div className="flex items-center gap-1.5 shrink-0">
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-[#C8BDAA] bg-[#08182D] border border-[#294563] rounded">
              ↑↓ Navigate
            </kbd>
            <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-[#C8BDAA] bg-[#08182D] border border-[#294563] rounded">
              ↵ Select
            </kbd>
            <button onClick={onClose} className="text-[#C8BDAA] hover:text-[#FAF7F0] p-1 cursor-pointer">
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Results Container */}
        <div className="max-h-96 overflow-y-auto p-4 space-y-4">
          {loading && (
            <div className="text-center py-6 text-xs text-[#C8BDAA]">
              Searching SentinelIoT Zero-Trust catalog...
            </div>
          )}

          {!loading && query && totalResults === 0 && (
            <div className="text-center py-8 text-xs text-[#C8BDAA]">
              No security entities matching "{query}".
            </div>
          )}

          {!loading && !query && (
            <div className="text-xs text-[#C8BDAA] py-4 text-center space-y-1">
              <p>Type to search across IoT hardware nodes, active threats, and audit records.</p>
              <p className="text-[11px] text-[#2B5D87] font-mono">Example: "ESP32", "Replay", "Quarantine", "192.168", "Ed25519"</p>
            </div>
          )}

          {results.devices.length > 0 && (
            <div>
              <div className="text-[11px] font-mono text-[#2B5D87] uppercase tracking-wider mb-2 font-semibold">
                IoT Devices ({results.devices.length})
              </div>
              <div className="space-y-1">
                {results.devices.map((device, i) => {
                  const globalIdx = i;
                  const isHighlighted = selectedIndex === globalIdx;
                  return (
                    <button
                      key={device.id}
                      onClick={() => {
                        onSelectDevice(device);
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-lg transition-colors text-left group cursor-pointer ${
                        isHighlighted ? 'bg-[#102A4D] border border-[#2B5D87]' : 'hover:bg-[#102A4D]/50 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Server size={14} className="text-[#2B5D87]" />
                        <div>
                          <div className="text-xs font-semibold text-[#FAF7F0]">{device.name}</div>
                          <div className="text-[11px] text-[#C8BDAA] font-mono">
                            {device.id} · {device.ipAddress} · {device.cryptoAlgorithm}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono text-[#E8DCC8] font-bold">
                          Trust: {device.trustScore}/100
                        </span>
                        <ChevronRight size={14} className="text-[#C8BDAA] group-hover:text-[#FAF7F0]" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {results.threats.length > 0 && (
            <div>
              <div className="text-[11px] font-mono text-[#C47A5A] uppercase tracking-wider mb-2 font-semibold">
                Security Threats ({results.threats.length})
              </div>
              <div className="space-y-1">
                {results.threats.map((threat, i) => {
                  const globalIdx = results.devices.length + i;
                  const isHighlighted = selectedIndex === globalIdx;
                  return (
                    <button
                      key={threat.id}
                      onClick={() => {
                        onSelectThreat(threat);
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-lg transition-colors text-left group cursor-pointer ${
                        isHighlighted ? 'bg-[#102A4D] border border-[#C47A5A]' : 'hover:bg-[#102A4D]/50 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <AlertTriangle size={14} className="text-[#C47A5A]" />
                        <div>
                          <div className="text-xs font-semibold text-[#FAF7F0]">{threat.category}</div>
                          <div className="text-[11px] text-[#C8BDAA] line-clamp-1">{threat.description}</div>
                        </div>
                      </div>
                      <ChevronRight size={14} className="text-[#C8BDAA] group-hover:text-[#FAF7F0]" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {results.auditLogs.length > 0 && (
            <div>
              <div className="text-[11px] font-mono text-[#E8DCC8] uppercase tracking-wider mb-2 font-semibold">
                Audit Trail ({results.auditLogs.length})
              </div>
              <div className="space-y-1">
                {results.auditLogs.map((log, i) => {
                  const globalIdx = results.devices.length + results.threats.length + i;
                  const isHighlighted = selectedIndex === globalIdx;
                  return (
                    <div
                      key={log.id}
                      onClick={() => {
                        if (onSelectAudit) onSelectAudit(log);
                        onClose();
                      }}
                      className={`p-2.5 rounded-lg bg-[#08182D]/40 border flex items-start gap-2.5 text-left transition-colors cursor-pointer ${
                        isHighlighted ? 'border-[#E8DCC8] bg-[#102A4D]' : 'border-[#294563]/50 hover:border-[#2B5D87]'
                      }`}
                    >
                      <FileText size={14} className="text-[#C8BDAA] shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-mono font-bold text-[#FAF7F0]">{log.event}</span>
                          <span className="text-[10px] font-mono text-[#E8DCC8]">{log.result}</span>
                        </div>
                        <div className="text-[11px] text-[#C8BDAA] mt-0.5">{log.details}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
