import React, { useRef, useEffect } from 'react';
import {
  Bell,
  Check,
  Trash2,
  ShieldAlert,
  AlertTriangle,
  Info,
  CheckCircle2,
  ExternalLink,
} from 'lucide-react';
import type { NotificationItem } from '../../types/index.ts';

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onClearAll: () => void;
  onOpenRelatedEvent: (item: NotificationItem) => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onClearAll,
  onOpenRelatedEvent,
}) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={ref}
      className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-[#0B1F3A] border border-[#294563] rounded-lg shadow-2xl z-50 overflow-hidden"
    >
      <div className="px-4 py-3 border-b border-[#294563] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={14} className="text-[#2B5D87]" />
          <span className="text-xs font-semibold text-[#FAF7F0]">Security Notifications</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onMarkAllRead}
            className="text-[11px] text-[#C8BDAA] hover:text-[#FAF7F0] flex items-center gap-1 transition-colors cursor-pointer"
            title="Mark all notifications as read"
          >
            <Check size={12} />
            <span>Mark read</span>
          </button>

          <button
            onClick={onClearAll}
            className="text-[11px] text-[#C47A5A] hover:text-[#FAF7F0] flex items-center gap-1 transition-colors cursor-pointer"
            title="Clear all notifications"
          >
            <Trash2 size={12} />
            <span>Clear</span>
          </button>
        </div>
      </div>

      <div className="max-h-80 overflow-y-auto divide-y divide-[#294563]/40">
        {notifications.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#C8BDAA]">
            No unread security alerts
          </div>
        ) : (
          notifications.map((n) => {
            let icon = <Info size={14} className="text-[#2B5D87]" />;
            if (n.severity === 'CRITICAL') icon = <ShieldAlert size={14} className="text-[#C47A5A]" />;
            else if (n.severity === 'WARNING') icon = <AlertTriangle size={14} className="text-[#C47A5A]" />;
            else if (n.severity === 'SUCCESS') icon = <CheckCircle2 size={14} className="text-[#E8DCC8]" />;

            return (
              <div
                key={n.id}
                onClick={() => {
                  onOpenRelatedEvent(n);
                  onClose();
                }}
                className={`p-3 text-left transition-colors cursor-pointer hover:bg-[#102A4D]/60 group ${
                  !n.read ? 'bg-[#08182D]/40' : 'opacity-70'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5 shrink-0">{icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-semibold text-[#FAF7F0] truncate group-hover:text-[#E8DCC8] transition-colors">
                        {n.title}
                      </span>
                      <span className="text-[10px] text-[#C8BDAA] font-mono tabular-nums shrink-0">
                        {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs text-[#C8BDAA] mt-0.5 line-clamp-2 leading-relaxed">{n.message}</p>
                    <div className="mt-1 flex items-center gap-1 text-[10px] text-[#2B5D87] font-mono group-hover:text-[#E8DCC8] transition-colors">
                      <span>Open related event</span>
                      <ExternalLink size={10} />
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
