import React, { useState, useEffect } from 'react';
import {
  Search,
  Bell,
  ShieldCheck,
  Menu,
  Clock,
  Radio,
} from 'lucide-react';
import type { NotificationItem } from '../../types/index.ts';
import { NotificationDropdown } from '../ui/NotificationDropdown.tsx';

interface HeaderProps {
  currentTabLabel: string;
  onOpenSearch: () => void;
  notifications: NotificationItem[];
  onMarkAllNotificationsRead: () => void;
  onClearAllNotifications: () => void;
  onOpenRelatedEvent: (item: NotificationItem) => void;
  onToggleMobileMenu: () => void;
  activeThreatCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTabLabel,
  onOpenSearch,
  notifications,
  onMarkAllNotificationsRead,
  onClearAllNotifications,
  onOpenRelatedEvent,
  onToggleMobileMenu,
  activeThreatCount,
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        `${now.toISOString().slice(11, 19)} UTC`
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="relative bg-[#E8DCC8] border-b border-[#D2C3AF] px-4 sm:px-6 flex items-center justify-between sticky top-0 z-20 h-14 shadow-xs">
      {/* 4-Color Vibrant SOC Conduit Rail */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#0B1F3A] via-[#2B5D87] via-[#C47A5A] to-[#0B1F3A] animate-conduit" />

      {/* Left zone: Mobile toggle + Breadcrumb / Current Tab */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleMobileMenu}
          className="lg:hidden p-1.5 text-[#0B1F3A] hover:bg-[#DBCBB5] rounded-md transition-colors cursor-pointer"
          aria-label="Toggle menu"
        >
          <Menu size={18} />
        </button>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#5A6E85] font-semibold">SentinelIoT SOC</span>
          <span className="text-[#968672]">/</span>
          <span className="font-bold text-[#0B1F3A] flex items-center gap-1.5 bg-[#FAF7F0] px-2 py-0.5 rounded border border-[#D2C3AF] shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#2B5D87] animate-pulse" />
            {currentTabLabel}
          </span>
        </div>
      </div>

      {/* Right zone: Global Search, Posture, Clock, Notifications, Technical Operator */}
      <div className="flex items-center gap-2 sm:gap-3.5">
        {/* Global Search Button */}
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] text-xs text-[#0B1F3A] hover:border-[#0B1F3A] hover:bg-white transition-all cursor-pointer shadow-2xs group"
          title="Search devices and logs (Ctrl + K)"
        >
          <Search size={14} className="text-[#2B5D87] group-hover:scale-110 transition-transform" />
          <span className="hidden md:inline font-medium">Search SOC...</span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-[#0B1F3A] bg-[#E8DCC8] border border-[#D2C3AF] rounded font-bold">
            ⌘K
          </kbd>
        </button>

        {/* Security Engine State Badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#2B5D87]/40 text-xs shadow-2xs">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2B5D87] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#2B5D87]" />
          </span>
          <span className="text-[#0B1F3A] font-mono text-[11px] font-bold tracking-wider">
            SECURITY ENGINE: ACTIVE
          </span>
        </div>

        {/* Active Threats Alert Badge */}
        {activeThreatCount > 0 ? (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#C47A5A]/20 border border-[#C47A5A] text-xs shadow-xs animate-glow-copper">
            <Radio size={12} className="text-[#923818] animate-pulse" />
            <span className="text-[#923818] font-mono font-bold text-[11px]">
              {activeThreatCount} THREAT{activeThreatCount > 1 ? 'S' : ''} ACTIVE
            </span>
          </div>
        ) : (
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#FAF7F0] border border-[#D2C3AF] text-xs">
            <ShieldCheck size={13} className="text-[#2B5D87]" />
            <span className="text-[#0B1F3A] font-mono text-[11px] font-semibold">ZERO-TRUST ENFORCED</span>
          </div>
        )}

        {/* Environment Tag */}
        <div className="hidden xl:flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#FAF7F0] border border-[#D2C3AF] text-[11px] font-mono">
          <span className="text-[#5A6E85]">FLEET:</span>
          <span className="text-[#0B1F3A] font-bold">DEMO / SYNTHETIC</span>
        </div>

        {/* System UTC Time */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#FAF7F0] border border-[#D2C3AF] text-xs font-mono tabular-nums text-[#0B1F3A] font-semibold shadow-2xs">
          <Clock size={13} className="text-[#2B5D87]" />
          <span>{currentTime || '00:00:00 UTC'}</span>
        </div>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications((prev) => !prev)}
            className="p-2 text-[#0B1F3A] hover:bg-[#FAF7F0] rounded-md border border-transparent hover:border-[#D2C3AF] transition-all relative cursor-pointer"
            aria-label="Security notifications"
          >
            <Bell size={16} />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C47A5A] opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#C47A5A]" />
              </span>
            )}
          </button>

          <NotificationDropdown
            isOpen={showNotifications}
            onClose={() => setShowNotifications(false)}
            notifications={notifications}
            onMarkAllRead={onMarkAllNotificationsRead}
            onClearAll={onClearAllNotifications}
            onOpenRelatedEvent={onOpenRelatedEvent}
          />
        </div>

        {/* Operator Badge (PERSON AVATAR REMOVED AS REQUESTED) */}
        <div className="flex items-center gap-2.5 pl-2.5 border-l border-[#D2C3AF]">
          <div className="w-8 h-8 rounded-lg bg-[#0B1F3A] border border-[#2B5D87] flex items-center justify-center text-[#E8DCC8] shadow-xs relative group cursor-pointer">
            <ShieldCheck size={16} className="text-[#E8DCC8] group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#C47A5A] animate-ping" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#C47A5A] border border-[#E8DCC8]" />
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-bold text-[#0B1F3A] tracking-wide leading-none">SECOPS COMMAND</div>
            <div className="text-[10px] font-mono text-[#2B5D87] font-semibold leading-none mt-1">Tier 3 Active</div>
          </div>
        </div>
      </div>
    </header>
  );
};
