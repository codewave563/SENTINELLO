import React from 'react';
import {
  LayoutDashboard,
  Server,
  KeyRound,
  ShieldCheck,
  BrainCircuit,
  AlertTriangle,
  Scale,
  Crosshair,
  FileText,
  Activity,
  Settings,
  ChevronLeft,
  ChevronRight,
  Play,
  ShieldAlert,
} from 'lucide-react';

export type NavigationTab =
  | 'overview'
  | 'devices'
  | 'crypto-lab'
  | 'authentication'
  | 'ai-security'
  | 'threat-center'
  | 'risk-zero-trust'
  | 'attack-simulator'
  | 'audit-center'
  | 'system-health'
  | 'settings';

interface SidebarProps {
  currentTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onOpenDemo: () => void;
}

const NAV_ITEMS: { id: NavigationTab; label: string; icon: React.FC<{ size?: number; className?: string }> }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'devices', label: 'Devices', icon: Server },
  { id: 'crypto-lab', label: 'Crypto Lab', icon: KeyRound },
  { id: 'authentication', label: 'Authentication', icon: ShieldCheck },
  { id: 'ai-security', label: 'AI Security', icon: BrainCircuit },
  { id: 'threat-center', label: 'Threat Center', icon: AlertTriangle },
  { id: 'risk-zero-trust', label: 'Risk & Zero Trust', icon: Scale },
  { id: 'attack-simulator', label: 'Attack Simulator', icon: Crosshair },
  { id: 'audit-center', label: 'Audit Center', icon: FileText },
  { id: 'system-health', label: 'System Health', icon: Activity },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  isCollapsed,
  onToggleCollapse,
  onOpenDemo,
}) => {
  return (
    <aside
      className={`fixed inset-y-0 left-0 z-30 flex flex-col bg-[#0B1F3A] border-r border-[#294563] transition-all duration-200 select-none ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="h-14 px-4 border-b border-[#294563] flex items-center justify-between">
        {!isCollapsed ? (
          <div className="flex items-center gap-2.5">
            <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-[#2B5D87] to-[#0B1F3A] border border-[#2B5D87] flex items-center justify-center text-[#FAF7F0] font-bold text-xs tracking-wider shadow-md">
              <ShieldAlert size={17} className="text-[#E8DCC8]" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#C47A5A] border-2 border-[#0B1F3A] animate-pulse" />
            </div>
            <div>
              <div className="text-sm font-black tracking-tight text-[#FAF7F0]">
                SENTINEL<span className="text-[#C47A5A]">IoT</span>
              </div>
              <div className="text-[10px] text-[#E8DCC8] tracking-wider uppercase font-mono font-medium flex items-center gap-1">
                <span>Zero-Trust SOC</span>
                <span className="w-1 h-1 rounded-full bg-[#2B5D87]" />
              </div>
            </div>
          </div>
        ) : (
          <div className="relative mx-auto w-8 h-8 rounded-lg bg-gradient-to-br from-[#2B5D87] to-[#0B1F3A] border border-[#2B5D87] flex items-center justify-center text-[#FAF7F0]">
            <ShieldAlert size={17} className="text-[#E8DCC8]" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#C47A5A] animate-pulse" />
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className={`p-1.5 rounded-md text-[#C8BDAA] hover:text-[#FAF7F0] hover:bg-[#102A4D] transition-colors cursor-pointer ${
            isCollapsed ? 'hidden' : 'block'
          }`}
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <ChevronLeft size={16} />
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto px-2.5 py-3 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              title={isCollapsed ? item.label : undefined}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-semibold transition-all duration-150 text-left cursor-pointer group ${
                isActive
                  ? 'bg-gradient-to-r from-[#102A4D] to-[#0B1F3A] text-[#FAF7F0] border-l-[3px] border-[#C47A5A] shadow-xs'
                  : 'text-[#C8BDAA] hover:text-[#FAF7F0] hover:bg-[#102A4D]/60 hover:border-l-2 hover:border-[#2B5D87]'
              }`}
            >
              <Icon
                size={16}
                className={`shrink-0 transition-transform group-hover:scale-110 ${
                  isActive ? 'text-[#E8DCC8]' : 'text-[#2B5D87]'
                }`}
              />
              {!isCollapsed && (
                <span className={`truncate ${isActive ? 'text-[#FAF7F0]' : 'text-[#C8BDAA] group-hover:text-[#FAF7F0]'}`}>
                  {item.label}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer Controls */}
      <div className="p-3 border-t border-[#294563] space-y-2">
        {!isCollapsed ? (
          <button
            onClick={onOpenDemo}
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-gradient-to-r from-[#08182D] via-[#102A4D] to-[#08182D] border border-[#C47A5A]/70 text-xs font-bold text-[#E8DCC8] hover:text-[#FAF7F0] hover:border-[#C47A5A] hover:shadow-[0_0_12px_rgba(196,122,90,0.35)] transition-all cursor-pointer group"
          >
            <Play size={13} className="fill-current text-[#C47A5A] group-hover:scale-110 transition-transform" />
            <span className="tracking-wide">Run E2E Demo</span>
          </button>
        ) : (
          <button
            onClick={onOpenDemo}
            title="Run End-to-End Demo"
            className="w-full flex items-center justify-center p-2 rounded-lg bg-[#08182D] border border-[#C47A5A] text-[#C47A5A] hover:bg-[#102A4D] hover:shadow-[0_0_10px_rgba(196,122,90,0.4)] transition-all cursor-pointer"
          >
            <Play size={14} className="fill-current" />
          </button>
        )}

        {isCollapsed && (
          <button
            onClick={onToggleCollapse}
            className="w-full flex items-center justify-center p-1.5 rounded-md text-[#C8BDAA] hover:text-[#FAF7F0] hover:bg-[#102A4D] cursor-pointer"
            aria-label="Expand sidebar"
          >
            <ChevronRight size={16} />
          </button>
        )}

        {!isCollapsed && (
          <div className="px-1 text-[10px] text-[#C8BDAA] font-mono flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E8DCC8] animate-pulse" />
              FIPS 186-4 · ED25519
            </span>
            <span className="text-[#C47A5A] font-semibold">SECURE</span>
          </div>
        )}
      </div>
    </aside>
  );
};
