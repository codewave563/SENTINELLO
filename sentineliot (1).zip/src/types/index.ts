export type CryptoAlgorithm = 'ECDSA_P256' | 'ED25519' | 'RSA_2048';

export type DeviceStatus = 'ONLINE' | 'OFFLINE' | 'TRUSTED' | 'SUSPICIOUS' | 'QUARANTINED' | 'BLOCKED';
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type PolicyDecision =
  | 'ALLOW'
  | 'DENY'
  | 'RATE_LIMIT'
  | 'REAUTHENTICATE'
  | 'STEP_UP_AUTH'
  | 'RESTRICT'
  | 'QUARANTINE'
  | 'BLOCK';
export type ThreatSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type ThreatStatus = 'DETECTED' | 'INVESTIGATING' | 'CONTAINED' | 'RESOLVED';
export type ThreatCategory = 
  | 'AUTHENTICATION_ATTACK'
  | 'REPLAY_ATTACK'
  | 'CREDENTIAL_ABUSE'
  | 'ANOMALOUS_BEHAVIOUR'
  | 'UNAUTHORIZED_ACCESS'
  | 'SUSPICIOUS_TRAFFIC'
  | 'DEVICE_COMPROMISE'
  | 'POLICY_VIOLATION';

export interface DeviceTelemetry {
  requestFrequency: number;     // req/min
  packetFrequency: number;      // packets/sec
  failedAuthCount: number;
  sessionDuration: number;      // sec
  bytesSent: number;
  bytesReceived: number;
  uniqueDestinations: number;
  commandFrequency: number;     // commands/min
  timeSinceLastSeen: number;    // seconds
  authFailureRate: number;      // 0-1
}

export interface Device {
  id: string;
  name: string;
  type: 'SENSOR' | 'GATEWAY' | 'CONTROLLER' | 'ACTUATOR' | 'CAMERA' | 'METER';
  ipAddress: string;
  manufacturer: string;
  firmwareVersion: string;
  cryptoAlgorithm: CryptoAlgorithm;
  status: DeviceStatus;
  trustScore: number;          // 0-100
  riskScore: number;           // 0-100
  riskLevel: RiskLevel;
  lastSeen: string;
  registeredAt: string;
  publicKeyPem: string;
  keyFingerprint: string;
  firmwareAgeMonths: number;
  telemetry: DeviceTelemetry;
}

export interface CryptoKeyDetails {
  algorithm: CryptoAlgorithm;
  curveOrBits: string;
  publicKeyPem: string;
  fingerprint: string;
  createdAt: string;
}

export interface CryptoBenchmarkResult {
  algorithm: CryptoAlgorithm;
  label: string;
  curveOrBits: string;
  keyGenMs: number;
  signMs: number;
  verifyMs: number;
  signatureSizeBytes: number;
  publicKeySizeBytes: number;
  securityBitsEquivalent: number;
  tradeoffRecommendation: string;
}

export interface ChallengeRequest {
  deviceId: string;
}

export interface ChallengeResponse {
  nonce: string;
  timestamp: number;
  deviceId: string;
  expiresAt: number;
  algorithm: CryptoAlgorithm;
  serverSignature?: string;
}

export interface VerificationRequest {
  deviceId: string;
  nonce: string;
  signatureBase64: string;
  timestamp: number;
}

export interface VerificationResult {
  success: boolean;
  deviceId: string;
  algorithm: CryptoAlgorithm;
  signatureValid: boolean;
  timestampValid: boolean;
  nonceValid: boolean;
  latencyMs: number;
  message: string;
  failureReason?: string;
  policyDecision: PolicyDecision;
  trustScore: number;
  riskScore: number;
}

export interface AuthAttempt {
  id: string;
  timestamp: string;
  deviceId: string;
  deviceName: string;
  nonce: string;
  algorithm: CryptoAlgorithm;
  signatureValid: boolean;
  timestampValid: boolean;
  nonceValid: boolean;
  result: 'SUCCESS' | 'FAILED' | 'REPLAY_BLOCKED' | 'EXPIRED';
  latencyMs: number;
  failureReason?: string;
}

export interface RiskFactor {
  factor: string;
  impact: number;
  category: 'AUTHENTICATION' | 'BEHAVIOUR' | 'NETWORK' | 'FIRMWARE' | 'HISTORIC';
}

export interface ZeroTrustEvaluation {
  deviceId: string;
  deviceName: string;
  identityTrust: number;       // 0-100
  authTrust: number;           // 0-100
  deviceHealth: number;        // 0-100
  behaviouralTrust: number;    // 0-100
  networkContext: number;      // 0-100
  threatPenalty: number;       // 0-100
  overallTrustScore: number;   // 0-100
  riskScore: number;           // 0-100
  riskLevel: RiskLevel;
  policyDecision: PolicyDecision;
  explainableFactors: RiskFactor[];
  timestamp: string;
}

export interface AnomalyExplanation {
  factor: string;
  percentage: number;
  impact: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface MetricBaseline {
  metric: string;
  observed: number;
  baseline: number;
  unit: string;
  deviation: number;
}

export interface AIDetectionResult {
  deviceId: string;
  deviceName: string;
  anomalyScore: number;        // 0-100
  isAnomaly: boolean;
  confidence: number;          // 0-100
  explainability: AnomalyExplanation[];
  baselineComparison: MetricBaseline[];
  evaluatedAt: string;
}

export interface ThreatInvestigationStage {
  stage: 'DETECTED' | 'ANALYZED' | 'RISK_CALCULATED' | 'POLICY_EVALUATED' | 'RESPONSE_INITIATED' | 'CONTAINED';
  label: string;
  timestamp: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
  description: string;
}

export interface ThreatEvent {
  id: string;
  timestamp: string;
  deviceId: string;
  deviceName: string;
  category: ThreatCategory;
  severity: ThreatSeverity;
  riskScore: number;
  status: ThreatStatus;
  description: string;
  responseAction: PolicyDecision;
  containedAt?: string;
  investigationNotes?: string;
  investigationTimeline?: ThreatInvestigationStage[];
}

export interface AttackScenario {
  id: string;
  name: string;
  category: ThreatCategory;
  description: string;
  technicalMechanism: string;
  expectedDefensiveResponse: PolicyDecision;
  severity: ThreatSeverity;
}

export interface AttackPhaseResult {
  phase: number;
  name: string;
  status: 'PENDING' | 'ANALYZING' | 'PASSED' | 'DETECTED' | 'MITIGATED';
  detail: string;
}

export interface AttackSimulationRun {
  scenarioId: string;
  scenarioName: string;
  timestamp: string;
  targetDeviceId: string;
  targetDeviceName: string;
  phases: AttackPhaseResult[];
  finalDecision: PolicyDecision;
  threatCreated?: ThreatEvent;
  deviceQuarantined: boolean;
  summary: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  event: string;
  deviceId?: string;
  deviceName?: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  source: 'CRYPTO_ENGINE' | 'AUTH_SERVICE' | 'ZERO_TRUST' | 'AI_ENGINE' | 'ATTACK_SIM' | 'SOC_ADMIN';
  result: 'SUCCESS' | 'DENIED' | 'DETECTED' | 'BLOCKED' | 'FLAGGED';
  details: string;
}

export interface SystemHealth {
  backend: 'OPERATIONAL' | 'WARNING' | 'DEGRADED' | 'OFFLINE';
  database: 'OPERATIONAL' | 'WARNING' | 'DEGRADED' | 'OFFLINE';
  mlEngine: 'OPERATIONAL' | 'WARNING' | 'DEGRADED' | 'OFFLINE';
  cryptoService: 'OPERATIONAL' | 'WARNING' | 'DEGRADED' | 'OFFLINE';
  apiGateway: 'OPERATIONAL' | 'WARNING' | 'DEGRADED' | 'OFFLINE';
  uptimeSeconds: number;
  totalEventsProcessed: number;
  activeSessions: number;
  memoryUsageMb: number;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL' | 'SUCCESS';
  read: boolean;
  deviceId?: string;
  threatId?: string;
  linkTab?: string;
}
