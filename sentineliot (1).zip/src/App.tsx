import React, { useState, useEffect, useCallback } from 'react';
import type {
  AuditLog,
  AuthAttempt,
  Device,
  NotificationItem,
  ThreatEvent,
} from './types/index.ts';
import {
  clearAllNotifications,
  fetchAuditLogs,
  fetchAuthAttempts,
  fetchDevices,
  fetchNotifications,
  fetchThreats,
  markAllNotificationsRead,
} from './services/api.ts';
import { Sidebar, type NavigationTab } from './components/layout/Sidebar.tsx';
import { Header } from './components/layout/Header.tsx';
import { SearchModal } from './components/ui/SearchModal.tsx';
import { EndToEndDemoModal } from './components/ui/EndToEndDemoModal.tsx';

// Views
import { OverviewView } from './components/views/OverviewView.tsx';
import { DevicesView } from './components/views/DevicesView.tsx';
import { CryptoLabView } from './components/views/CryptoLabView.tsx';
import { AuthenticationView } from './components/views/AuthenticationView.tsx';
import { AiSecurityView } from './components/views/AiSecurityView.tsx';
import { ThreatCenterView } from './components/views/ThreatCenterView.tsx';
import { RiskZeroTrustView } from './components/views/RiskZeroTrustView.tsx';
import { AttackSimulatorView } from './components/views/AttackSimulatorView.tsx';
import { AuditCenterView } from './components/views/AuditCenterView.tsx';
import { SystemHealthView } from './components/views/SystemHealthView.tsx';
import { SettingsView } from './components/views/SettingsView.tsx';

const TAB_TITLES: Record<NavigationTab, string> = {
  overview: 'Security Operations Overview',
  devices: 'IoT Device Fleet Management',
  'crypto-lab': 'Cryptographic Identity & Benchmarks',
  authentication: 'Challenge-Response Mutual Authentication',
  'ai-security': 'AI Anomaly Detection & Explainability',
  'threat-center': 'Active Threats & Incident Queue',
  'risk-zero-trust': 'Zero-Trust Engine & Risk Assessment',
  'attack-simulator': 'Defensive Cyber Attack Simulator',
  'audit-center': 'Tamper-Evident Security Audit Ledger',
  'system-health': 'Platform Health & SOC Diagnostics',
  settings: 'Security Policies & Fleet Configuration',
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('overview');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDemoOpen, setIsDemoOpen] = useState(false);

  // Application Telemetry State
  const [devices, setDevices] = useState<Device[]>([]);
  const [threats, setThreats] = useState<ThreatEvent[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [authAttempts, setAuthAttempts] = useState<AuthAttempt[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Routing context pass-through
  const [targetAuthDeviceId, setTargetAuthDeviceId] = useState<string | undefined>();
  const [devicesFilterStatus, setDevicesFilterStatus] = useState<string>('ALL');

  // Fetch all live data
  const loadData = useCallback(async () => {
    try {
      const [devs, thrs, logs, auths, notifs] = await Promise.all([
        fetchDevices(),
        fetchThreats(),
        fetchAuditLogs(),
        fetchAuthAttempts(),
        fetchNotifications(),
      ]);
      setDevices(devs);
      setThreats(thrs);
      setAuditLogs(logs);
      setAuthAttempts(auths);
      setNotifications(notifs);
      setLoadError(null);
    } catch (err: any) {
      console.error('Failed to load SOC telemetry:', err);
      setLoadError(err.message || 'Unable to connect to SentinelIoT SOC API daemon');
    }
  }, []);

  useEffect(() => {
    loadData();
    // Poll telemetry every 6 seconds
    const interval = setInterval(loadData, 6000);
    return () => clearInterval(interval);
  }, [loadData]);

  // Navigate to authentication with target device selected
  const handleNavigateToAuth = (deviceId: string) => {
    setTargetAuthDeviceId(deviceId);
    setCurrentTab('authentication');
  };

  const handleNavigateWithFilter = (tab: NavigationTab, filter?: string) => {
    if (tab === 'devices' && filter) {
      setDevicesFilterStatus(filter);
    }
    setCurrentTab(tab);
  };

  const handleMarkAllNotifications = async () => {
    try {
      await markAllNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    } catch (err) {
      console.error('Failed to mark notifications read:', err);
    }
  };

  const handleClearAllNotifications = async () => {
    try {
      await clearAllNotifications();
      setNotifications([]);
    } catch (err) {
      console.error('Failed to clear notifications:', err);
    }
  };

  const handleOpenRelatedEvent = (item: NotificationItem) => {
    if (item.threatId || item.linkTab === 'threat-center') {
      setCurrentTab('threat-center');
    } else if (item.deviceId) {
      setDevicesFilterStatus('ALL');
      setCurrentTab('devices');
    } else {
      setCurrentTab('overview');
    }
  };

  const activeThreatCount = threats.filter(
    (t) => t.status === 'DETECTED' || t.status === 'INVESTIGATING'
  ).length;

  return (
    <div className="min-h-screen bg-[#FAF7F0] text-[#08182D] flex flex-col font-sans antialiased selection:bg-[#C47A5A]/20 selection:text-[#0B1F3A]">
      {/* Permanent Sidebar (Desktop) */}
      <div className="hidden lg:block">
        <Sidebar
          currentTab={currentTab}
          onTabChange={(tab) => {
            if (tab === 'devices') setDevicesFilterStatus('ALL');
            setCurrentTab(tab);
          }}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
          onOpenDemo={() => setIsDemoOpen(true)}
        />
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-[#08182D]/70 backdrop-blur-xs"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-64 bg-[#0B1F3A] border-r border-[#294563] shadow-2xl z-10 flex flex-col">
            <Sidebar
              currentTab={currentTab}
              onTabChange={(tab) => {
                if (tab === 'devices') setDevicesFilterStatus('ALL');
                setCurrentTab(tab);
                setIsMobileMenuOpen(false);
              }}
              isCollapsed={false}
              onToggleCollapse={() => setIsMobileMenuOpen(false)}
              onOpenDemo={() => {
                setIsDemoOpen(true);
                setIsMobileMenuOpen(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div
        className={`flex-1 flex flex-col transition-all duration-200 ${
          isSidebarCollapsed ? 'lg:pl-16' : 'lg:pl-64'
        }`}
      >
        {/* Top Header */}
        <Header
          currentTabLabel={TAB_TITLES[currentTab]}
          onOpenSearch={() => setIsSearchOpen(true)}
          notifications={notifications}
          onMarkAllNotificationsRead={handleMarkAllNotifications}
          onClearAllNotifications={handleClearAllNotifications}
          onOpenRelatedEvent={handleOpenRelatedEvent}
          onToggleMobileMenu={() => setIsMobileMenuOpen((prev) => !prev)}
          activeThreatCount={activeThreatCount}
        />

        {/* Connection Error Banner (if any) */}
        {loadError && (
          <div className="bg-[#C47A5A]/15 border-b border-[#C47A5A] px-6 py-2.5 text-xs text-[#923818] font-medium flex items-center justify-between">
            <span>Warning: {loadError}. Telemetry daemon unreachable.</span>
            <button
              onClick={loadData}
              className="px-2 py-0.5 rounded bg-[#FAF7F0] border border-[#C47A5A] text-[#A64F2D] hover:bg-[#E8DCC8] cursor-pointer transition-colors"
            >
              Retry
            </button>
          </div>
        )}

        {/* View Viewport */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {currentTab === 'overview' && (
            <OverviewView
              devices={devices}
              threats={threats}
              auditLogs={auditLogs}
              authAttempts={authAttempts}
              onOpenDemo={() => setIsDemoOpen(true)}
              onNavigateTab={handleNavigateWithFilter}
              onRefresh={loadData}
              isLoading={isLoading}
            />
          )}

          {currentTab === 'devices' && (
            <DevicesView
              devices={devices}
              threats={threats}
              auditLogs={auditLogs}
              onRefresh={loadData}
              onNavigateToAuth={handleNavigateToAuth}
              initialStatusFilter={devicesFilterStatus}
            />
          )}

          {currentTab === 'crypto-lab' && <CryptoLabView />}

          {currentTab === 'authentication' && (
            <AuthenticationView
              devices={devices}
              authAttempts={authAttempts}
              onRefresh={loadData}
              initialDeviceId={targetAuthDeviceId}
            />
          )}

          {currentTab === 'ai-security' && (
            <AiSecurityView devices={devices} onRefresh={loadData} />
          )}

          {currentTab === 'threat-center' && (
            <ThreatCenterView
              threats={threats}
              auditLogs={auditLogs}
              onRefresh={loadData}
            />
          )}

          {currentTab === 'risk-zero-trust' && (
            <RiskZeroTrustView devices={devices} onRefresh={loadData} />
          )}

          {currentTab === 'attack-simulator' && (
            <AttackSimulatorView devices={devices} onRefresh={loadData} />
          )}

          {currentTab === 'audit-center' && (
            <AuditCenterView
              auditLogs={auditLogs}
              devices={devices}
              onRefresh={loadData}
            />
          )}

          {currentTab === 'system-health' && <SystemHealthView />}

          {currentTab === 'settings' && <SettingsView onReset={loadData} />}
        </main>
      </div>

      {/* Global Search Modal (Ctrl + K) */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectDevice={(device) => {
          setDevicesFilterStatus('ALL');
          setCurrentTab('devices');
        }}
        onSelectThreat={(threat) => {
          setCurrentTab('threat-center');
        }}
        onSelectAudit={(audit) => {
          setCurrentTab('audit-center');
        }}
      />

      {/* End-to-End 15-Stage Lifecycle Demo Modal */}
      <EndToEndDemoModal
        isOpen={isDemoOpen}
        onClose={() => setIsDemoOpen(false)}
        onCompleted={loadData}
      />
    </div>
  );
}
