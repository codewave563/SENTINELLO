import type {
  AIDetectionResult,
  AttackScenario,
  AttackSimulationRun,
  AuditLog,
  AuthAttempt,
  ChallengeResponse,
  CryptoAlgorithm,
  CryptoBenchmarkResult,
  CryptoKeyDetails,
  Device,
  DeviceStatus,
  NotificationItem,
  SystemHealth,
  ThreatEvent,
  VerificationResult,
  ZeroTrustEvaluation,
} from '../types/index.ts';

const API_BASE = '/api';

export async function fetchDevices(): Promise<Device[]> {
  const res = await fetch(`${API_BASE}/devices`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchDevice(id: string): Promise<Device & { zeroTrust: ZeroTrustEvaluation; anomalyDetection: AIDetectionResult }> {
  const res = await fetch(`${API_BASE}/devices/${id}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function registerDevice(data: {
  name: string;
  type: Device['type'];
  ipAddress: string;
  manufacturer?: string;
  firmwareVersion?: string;
  cryptoAlgorithm: CryptoAlgorithm;
}): Promise<Device> {
  const res = await fetch(`${API_BASE}/devices`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function updateDeviceStatus(id: string, status: DeviceStatus, reason?: string): Promise<Device> {
  const res = await fetch(`${API_BASE}/devices/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, reason }),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function generateCryptoKey(algorithm: CryptoAlgorithm): Promise<CryptoKeyDetails & { keyGenMs: number }> {
  const res = await fetch(`${API_BASE}/crypto/generate-key`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ algorithm }),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function runCryptoSignVerifyDemo(params: {
  algorithm: CryptoAlgorithm;
  message: string;
}): Promise<{
  algorithm: CryptoAlgorithm;
  message: string;
  signatureBase64: string;
  signatureSizeBytes: number;
  fingerprint: string;
  publicKeyPem: string;
  isValid: boolean;
  signMs: number;
  verifyMs: number;
}> {
  const res = await fetch(`${API_BASE}/crypto/sign-verify-demo`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchCryptoBenchmark(): Promise<CryptoBenchmarkResult[]> {
  const res = await fetch(`${API_BASE}/crypto/benchmark`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function issueAuthChallenge(deviceId: string): Promise<ChallengeResponse> {
  const res = await fetch(`${API_BASE}/auth/challenge`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ deviceId }),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function verifyAuthChallenge(params: {
  deviceId: string;
  nonce: string;
  signatureBase64: string;
  timestamp: number;
  forceReplay?: boolean;
  corruptSignature?: boolean;
  skewTimestamp?: boolean;
}): Promise<VerificationResult> {
  const res = await fetch(`${API_BASE}/auth/verify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function simulateAuthFlow(params: {
  deviceId: string;
  tamperWithSignature?: boolean;
  triggerReplay?: boolean;
  triggerSkew?: boolean;
}): Promise<any> {
  const res = await fetch(`${API_BASE}/auth/simulate-flow`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchAuthAttempts(): Promise<AuthAttempt[]> {
  const res = await fetch(`${API_BASE}/auth/attempts`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function evaluateDeviceZeroTrust(deviceId: string): Promise<ZeroTrustEvaluation> {
  const res = await fetch(`${API_BASE}/zero-trust/evaluate/${deviceId}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchDeviceTelemetry(deviceId: string): Promise<{
  telemetry: Device['telemetry'];
  detection: AIDetectionResult;
}> {
  const res = await fetch(`${API_BASE}/ai/telemetry/${deviceId}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function simulateTelemetrySpike(params: {
  deviceId: string;
  spikeType: 'TRAFFIC' | 'COMMAND_SURGE' | 'AUTH_BURST';
}): Promise<any> {
  const res = await fetch(`${API_BASE}/ai/simulate-telemetry-spike`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchThreats(): Promise<ThreatEvent[]> {
  const res = await fetch(`${API_BASE}/threats`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function containThreat(id: string, notes?: string): Promise<ThreatEvent> {
  const res = await fetch(`${API_BASE}/threats/${id}/contain`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ notes }),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchAttackScenarios(): Promise<AttackScenario[]> {
  const res = await fetch(`${API_BASE}/attacks/scenarios`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function runAttackScenario(scenarioId: string, targetDeviceId?: string): Promise<AttackSimulationRun> {
  const res = await fetch(`${API_BASE}/attacks/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ scenarioId, targetDeviceId }),
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function runAllAttackScenarios(): Promise<AttackSimulationRun[]> {
  const res = await fetch(`${API_BASE}/attacks/run-all`, {
    method: 'POST',
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchAuditLogs(filter?: {
  deviceId?: string;
  severity?: string;
  search?: string;
}): Promise<AuditLog[]> {
  const params = new URLSearchParams();
  if (filter?.deviceId) params.append('deviceId', filter.deviceId);
  if (filter?.severity) params.append('severity', filter.severity);
  if (filter?.search) params.append('search', filter.search);

  const res = await fetch(`${API_BASE}/audit?${params.toString()}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchSystemHealth(): Promise<SystemHealth> {
  const res = await fetch(`${API_BASE}/system/health`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function fetchNotifications(): Promise<NotificationItem[]> {
  const res = await fetch(`${API_BASE}/notifications`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function markAllNotificationsRead(): Promise<void> {
  await fetch(`${API_BASE}/notifications/read-all`, { method: 'POST' });
}

export async function clearAllNotifications(): Promise<void> {
  await fetch(`${API_BASE}/notifications`, { method: 'DELETE' });
}

export async function runEndToEndDemo(): Promise<{
  deviceId: string;
  steps: { step: number; title: string; detail: string; status: 'SUCCESS' | 'MITIGATED' }[];
  finalState: Device;
}> {
  const res = await fetch(`${API_BASE}/demo/run-e2e`, { method: 'POST' });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json;
}

export async function searchGlobal(q: string): Promise<{
  devices: Device[];
  threats: ThreatEvent[];
  auditLogs: AuditLog[];
}> {
  const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(q)}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
  return json.data;
}

export async function resetDatabase(): Promise<void> {
  const res = await fetch(`${API_BASE}/reset`, { method: 'POST' });
  const json = await res.json();
  if (!json.success) throw new Error(json.error);
}
