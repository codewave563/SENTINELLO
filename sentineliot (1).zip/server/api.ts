import { Router } from 'express';
import { evaluateDeviceAnomaly } from './ai-engine.ts';
import {
  ATTACK_SCENARIOS,
  executeAllAttackScenarios,
  executeAttackScenario,
} from './attack-simulator.ts';
import {
  generateKeyPair,
  runCryptographicBenchmark,
  signData,
  verifySignature,
} from './crypto.ts';
import { store } from './store.ts';
import { evaluateZeroTrust } from './zero-trust.ts';

export const apiRouter = Router();

// ==========================================
// 1. DEVICES API
// ==========================================

apiRouter.get('/devices', (_req, res) => {
  try {
    const devices = store.getDevices();
    res.json({ success: true, count: devices.length, data: devices });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/devices/:id', (req, res) => {
  try {
    const device = store.getDevice(req.params.id);
    if (!device) {
      res.status(404).json({ success: false, error: 'Device not found' });
      return;
    }
    const zt = evaluateZeroTrust(device, store.getActiveThreatCount(device.id));
    const anomaly = evaluateDeviceAnomaly(device);
    res.json({
      success: true,
      data: {
        ...device,
        zeroTrust: zt,
        anomalyDetection: anomaly,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/devices', (req, res) => {
  try {
    const { name, type, ipAddress, manufacturer, firmwareVersion, cryptoAlgorithm } = req.body;
    if (!name || !type || !ipAddress || !cryptoAlgorithm) {
      res.status(400).json({ success: false, error: 'Missing required device fields' });
      return;
    }
    const newDevice = store.registerDevice({
      name,
      type,
      ipAddress,
      manufacturer: manufacturer || 'Standard IoT Systems',
      firmwareVersion: firmwareVersion || 'v1.0.0',
      cryptoAlgorithm,
    });
    res.status(201).json({ success: true, data: newDevice });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.patch('/devices/:id/status', (req, res) => {
  try {
    const { status, reason } = req.body;
    if (!status) {
      res.status(400).json({ success: false, error: 'Status is required' });
      return;
    }
    const updated = store.updateDeviceStatus(req.params.id, status, reason);
    res.json({ success: true, data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 2. CRYPTOGRAPHY API & BENCHMARKS
// ==========================================

apiRouter.post('/crypto/generate-key', (req, res) => {
  try {
    const { algorithm } = req.body;
    if (!algorithm || !['ECDSA_P256', 'ED25519', 'RSA_2048'].includes(algorithm)) {
      res.status(400).json({ success: false, error: 'Valid algorithm required (ECDSA_P256, ED25519, RSA_2048)' });
      return;
    }

    const start = process.hrtime.bigint();
    const key = generateKeyPair(algorithm);
    const end = process.hrtime.bigint();
    const genTimeMs = Number(end - start) / 1e6;

    // Never return private key!
    res.json({
      success: true,
      data: {
        algorithm: key.algorithm,
        curveOrBits: key.curveOrBits,
        publicKeyPem: key.publicKeyPem,
        fingerprint: key.fingerprint,
        createdAt: key.createdAt,
        keyGenMs: Number(genTimeMs.toFixed(3)),
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/crypto/sign-verify-demo', (req, res) => {
  try {
    const { algorithm, message } = req.body;
    const alg = algorithm || 'ED25519';
    const text = message || 'SentinelIoT Zero-Trust Secure Payload';

    // Generate ephemeral key pair
    const key = generateKeyPair(alg);

    // Measure signing
    const signStart = process.hrtime.bigint();
    const signature = signData(alg, key.privateKeyPem, text);
    const signEnd = process.hrtime.bigint();
    const signMs = Number(signEnd - signStart) / 1e6;

    // Measure verification
    const verifyStart = process.hrtime.bigint();
    const isValid = verifySignature(alg, key.publicKeyPem, text, signature);
    const verifyEnd = process.hrtime.bigint();
    const verifyMs = Number(verifyEnd - verifyStart) / 1e6;

    res.json({
      success: true,
      data: {
        algorithm: alg,
        message: text,
        signatureBase64: signature,
        signatureSizeBytes: Buffer.from(signature, 'base64').length,
        fingerprint: key.fingerprint,
        publicKeyPem: key.publicKeyPem,
        isValid,
        signMs: Number(signMs.toFixed(3)),
        verifyMs: Number(verifyMs.toFixed(3)),
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/crypto/benchmark', (_req, res) => {
  try {
    const benchmarks = runCryptographicBenchmark();
    res.json({ success: true, count: benchmarks.length, data: benchmarks });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 3. AUTHENTICATION & CHALLENGE-RESPONSE
// ==========================================

apiRouter.post('/auth/challenge', (req, res) => {
  try {
    const { deviceId } = req.body;
    if (!deviceId) {
      res.status(400).json({ success: false, error: 'deviceId is required' });
      return;
    }
    const challenge = store.issueChallenge(deviceId);
    res.json({ success: true, data: challenge });
  } catch (err: any) {
    res.status(404).json({ success: false, error: err.message });
  }
});

apiRouter.post('/auth/verify', (req, res) => {
  try {
    const { deviceId, nonce, signatureBase64, timestamp, forceReplay, corruptSignature, skewTimestamp } = req.body;
    if (!deviceId || !nonce || !signatureBase64 || !timestamp) {
      res.status(400).json({ success: false, error: 'Missing verification parameters' });
      return;
    }

    const result = store.verifyChallenge(deviceId, nonce, signatureBase64, timestamp, {
      forceReplay,
      corruptSignature,
      skewTimestamp,
    });

    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * End-to-end interactive authentication pipeline simulator for a device
 */
apiRouter.post('/auth/simulate-flow', (req, res) => {
  try {
    const { deviceId, tamperWithSignature, triggerReplay, triggerSkew } = req.body;
    const targetId = deviceId || 'IOT-ESP32-07';
    const device = store.getDevice(targetId);
    if (!device) {
      res.status(404).json({ success: false, error: 'Device not found' });
      return;
    }

    // 1. Issue Challenge
    const challenge = store.issueChallenge(targetId);

    // 2. Device Signs Nonce
    const clientTimestamp = triggerSkew ? Date.now() - 360000 : Date.now();
    let signature = store.signChallengeLocally(targetId, challenge.nonce, clientTimestamp);

    if (tamperWithSignature) {
      // Corrupt last bytes of signature
      signature = signature.slice(0, -6) + 'AAAAAA';
    }

    // 3. Server Verifies
    const verifyResult = store.verifyChallenge(
      targetId,
      challenge.nonce,
      signature,
      clientTimestamp,
      {
        forceReplay: triggerReplay,
        corruptSignature: tamperWithSignature,
        skewTimestamp: triggerSkew,
      }
    );

    res.json({
      success: true,
      data: {
        step1_request: { deviceId: targetId, ip: device.ipAddress, requestedAt: challenge.timestamp },
        step2_challenge: challenge,
        step3_device_signature: {
          signatureBase64: signature,
          clientTimestamp,
          signedPayload: `${targetId}:${challenge.nonce}:${clientTimestamp}`,
        },
        step4_verification: verifyResult,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/auth/attempts', (_req, res) => {
  try {
    const attempts = store.getAuthAttempts();
    res.json({ success: true, count: attempts.length, data: attempts });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 4. ZERO TRUST & RISK ENGINE
// ==========================================

apiRouter.get('/zero-trust/evaluate/:deviceId', (req, res) => {
  try {
    const device = store.getDevice(req.params.deviceId);
    if (!device) {
      res.status(404).json({ success: false, error: 'Device not found' });
      return;
    }
    const evaluation = evaluateZeroTrust(device, store.getActiveThreatCount(device.id));
    res.json({ success: true, data: evaluation });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 5. AI SECURITY & ANOMALY DETECTION
// ==========================================

apiRouter.get('/ai/telemetry/:deviceId', (req, res) => {
  try {
    const device = store.getDevice(req.params.deviceId);
    if (!device) {
      res.status(404).json({ success: false, error: 'Device not found' });
      return;
    }
    const detection = evaluateDeviceAnomaly(device);
    res.json({
      success: true,
      data: {
        telemetry: device.telemetry,
        detection,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/ai/simulate-telemetry-spike', (req, res) => {
  try {
    const { deviceId, spikeType } = req.body;
    const targetId = deviceId || 'IOT-PLC-ACT-12';
    const device = store.getDevice(targetId);
    if (!device) {
      res.status(404).json({ success: false, error: 'Device not found' });
      return;
    }

    if (spikeType === 'TRAFFIC') {
      store.updateDeviceTelemetry(targetId, {
        bytesSent: 38000,
        uniqueDestinations: 6,
        packetFrequency: 35,
      });
    } else if (spikeType === 'COMMAND_SURGE') {
      store.updateDeviceTelemetry(targetId, {
        commandFrequency: 18.2,
        requestFrequency: 95,
        packetFrequency: 24,
      });
    } else {
      // General anomaly
      store.updateDeviceTelemetry(targetId, {
        failedAuthCount: 4,
        authFailureRate: 0.45,
        commandFrequency: 12.0,
      });
    }

    const updated = store.getDevice(targetId)!;
    const detection = evaluateDeviceAnomaly(updated);

    res.json({
      success: true,
      message: 'Telemetry anomaly injected into device',
      data: {
        device: updated,
        detection,
      },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 6. THREATS & INCIDENTS
// ==========================================

apiRouter.get('/threats', (_req, res) => {
  try {
    const threats = store.getThreats();
    res.json({ success: true, count: threats.length, data: threats });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/threats/:id', (req, res) => {
  try {
    const threat = store.getThreat(req.params.id);
    if (!threat) {
      res.status(404).json({ success: false, error: 'Threat not found' });
      return;
    }
    res.json({ success: true, data: threat });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.patch('/threats/:id/contain', (req, res) => {
  try {
    const { notes } = req.body;
    const threat = store.containThreat(req.params.id, notes);
    res.json({ success: true, data: threat });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 7. ATTACK SIMULATION
// ==========================================

apiRouter.get('/attacks/scenarios', (_req, res) => {
  try {
    res.json({ success: true, count: ATTACK_SCENARIOS.length, data: ATTACK_SCENARIOS });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/attacks/run', (req, res) => {
  try {
    const { scenarioId, targetDeviceId } = req.body;
    if (!scenarioId) {
      res.status(400).json({ success: false, error: 'scenarioId is required' });
      return;
    }
    const result = executeAttackScenario(scenarioId, targetDeviceId);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/attacks/run-all', (_req, res) => {
  try {
    const results = executeAllAttackScenarios();
    res.json({ success: true, count: results.length, data: results });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 8. AUDIT CENTER & EXPORTS
// ==========================================

apiRouter.get('/audit', (req, res) => {
  try {
    const { deviceId, severity, search } = req.query;
    const logs = store.getAuditLogs({
      deviceId: deviceId as string,
      severity: severity as string,
      search: search as string,
    });
    res.json({ success: true, count: logs.length, data: logs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.get('/audit/export', (req, res) => {
  try {
    const format = req.query.format === 'csv' ? 'csv' : 'json';
    const logs = store.getAuditLogs();

    if (format === 'csv') {
      const header = 'Timestamp,Event,Device ID,Device Name,Severity,Source,Result,Details\n';
      const rows = logs
        .map(
          (l) =>
            `"${l.timestamp}","${l.event}","${l.deviceId || ''}","${l.deviceName || ''}","${l.severity}","${l.source}","${l.result}","${l.details.replace(/"/g, '""')}"`
        )
        .join('\n');
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="sentineliot-audit-log.csv"');
      res.send(header + rows);
      return;
    }

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename="sentineliot-audit-log.json"');
    res.json(logs);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 9. SYSTEM HEALTH & METRICS
// ==========================================

apiRouter.get('/system/health', (_req, res) => {
  try {
    const health = store.getSystemHealth();
    res.json({ success: true, data: health });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 10. NOTIFICATIONS
// ==========================================

apiRouter.get('/notifications', (_req, res) => {
  try {
    const notifs = store.getNotifications();
    res.json({ success: true, count: notifs.length, data: notifs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/notifications/read-all', (_req, res) => {
  try {
    store.markAllNotificationsAsRead();
    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.delete('/notifications', (_req, res) => {
  try {
    store.clearAllNotifications();
    res.json({ success: true, message: 'All notifications cleared' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 11. END-TO-END DEMO SCENARIO (14 STEPS)
// ==========================================

apiRouter.post('/demo/run-e2e', (_req, res) => {
  try {
    const steps: { step: number; title: string; detail: string; status: 'SUCCESS' | 'MITIGATED' }[] = [];

    // 1. Register device
    const device = store.registerDevice({
      name: 'Demonstration Flow Sensor Beta',
      type: 'SENSOR',
      ipAddress: '192.168.10.220',
      manufacturer: 'Sentinel Secure Labs',
      firmwareVersion: 'v1.0.0',
      cryptoAlgorithm: 'ED25519',
    });
    steps.push({
      step: 1,
      title: 'Register Device',
      detail: `Created device ${device.id} with status ONLINE.`,
      status: 'SUCCESS',
    });

    // 2. Generate Cryptographic Identity
    steps.push({
      step: 2,
      title: 'Cryptographic Identity',
      detail: `Generated Ed25519 keypair. Public key fingerprint: ${device.keyFingerprint}.`,
      status: 'SUCCESS',
    });

    // 3. Challenge Generation
    const challenge = store.issueChallenge(device.id);
    steps.push({
      step: 3,
      title: 'Server Generates Challenge Nonce',
      detail: `32-byte cryptographic nonce generated: ${challenge.nonce.slice(0, 16)}... Expires in 60s.`,
      status: 'SUCCESS',
    });

    // 4. Device Signs Challenge
    const signature = store.signChallengeLocally(device.id, challenge.nonce, challenge.timestamp);
    steps.push({
      step: 4,
      title: 'Device Signs Challenge',
      detail: `Challenge signed using private key. Signature size: 64 bytes.`,
      status: 'SUCCESS',
    });

    // 5. Server Verifies Signature
    const authResult = store.verifyChallenge(device.id, challenge.nonce, signature, challenge.timestamp);
    steps.push({
      step: 5,
      title: 'Server Verifies Signature',
      detail: `Signature verified with Ed25519 public key in ${authResult.latencyMs}ms.`,
      status: 'SUCCESS',
    });

    // 6. Device Authenticated
    store.updateDeviceStatus(device.id, 'TRUSTED', 'E2E Demo: Challenge verified');
    steps.push({
      step: 6,
      title: 'Device Authenticated & Trusted',
      detail: `Device transitioned to TRUSTED state. Trust Score: 96/100.`,
      status: 'SUCCESS',
    });

    // 7. Normal Behaviour Telemetry
    steps.push({
      step: 7,
      title: 'Nominal Telemetry Ingestion',
      detail: `Telemetry stable at 12 req/min, 2.1 pkts/sec. Zero-Trust policy allows traffic.`,
      status: 'SUCCESS',
    });

    // 8. Inject Simulated Anomaly
    store.updateDeviceTelemetry(device.id, {
      requestFrequency: 145,
      packetFrequency: 42.0,
      commandFrequency: 24.5,
      bytesSent: 32000,
      uniqueDestinations: 5,
    });
    steps.push({
      step: 8,
      title: 'Simulated Anomaly Injection',
      detail: `Telemetry spiked: 145 req/min, 42 pkts/sec, multiple unfamiliar external destinations.`,
      status: 'SUCCESS',
    });

    // 9. AI Anomaly Detection
    const anomaly = evaluateDeviceAnomaly(store.getDevice(device.id)!);
    steps.push({
      step: 9,
      title: 'AI Anomaly Detector Flags Node',
      detail: `Isolation Forest model computed anomaly score: ${anomaly.anomalyScore}/100. Confidence: ${anomaly.confidence}%.`,
      status: 'MITIGATED',
    });

    // 10. Risk Score Increase
    const zt = evaluateZeroTrust(store.getDevice(device.id)!);
    steps.push({
      step: 10,
      title: 'Risk Engine Recalculation',
      detail: `Device risk score elevated from 4/100 to ${zt.riskScore}/100 (${zt.riskLevel} tier).`,
      status: 'MITIGATED',
    });

    // 11. Zero Trust Policy Decision
    steps.push({
      step: 11,
      title: 'Zero Trust Policy Decision',
      detail: `Zero-Trust engine enforced rule: Risk ${zt.riskScore} exceeds threshold -> Decision: QUARANTINE.`,
      status: 'MITIGATED',
    });

    // 12. Threat Generated
    const threatId = `THR-${Math.floor(1000 + Math.random() * 9000)}`;
    store.addThreat({
      id: threatId,
      timestamp: new Date().toISOString(),
      deviceId: device.id,
      deviceName: device.name,
      category: 'ANOMALOUS_BEHAVIOUR',
      severity: 'CRITICAL',
      riskScore: zt.riskScore,
      status: 'CONTAINED',
      description: 'End-to-End demonstration: AI detected behavioral deviation exceeding tolerance.',
      responseAction: 'QUARANTINE',
      containedAt: new Date().toISOString(),
      investigationNotes: 'Automated quarantine containment verified.',
    });
    steps.push({
      step: 12,
      title: 'Security Threat Generated',
      detail: `Threat record created (${threatId}) with CRITICAL severity.`,
      status: 'MITIGATED',
    });

    // 13. Device Quarantined
    store.updateDeviceStatus(device.id, 'QUARANTINED', 'E2E Demo: Automated anomaly response');
    steps.push({
      step: 13,
      title: 'Automated Quarantine Enforced',
      detail: `Device state moved to QUARANTINED. Network isolation policy enacted.`,
      status: 'MITIGATED',
    });

    // 14. Audit Event Recorded
    store.addAuditLog({
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      event: 'E2E_DEMO_COMPLETED',
      deviceId: device.id,
      deviceName: device.name,
      source: 'ZERO_TRUST',
      result: 'BLOCKED',
      details: `Full 14-step zero-trust lifecycle demonstration completed. Final state: QUARANTINED.`,
      severity: 'CRITICAL',
    });
    steps.push({
      step: 14,
      title: 'Immutable Audit Entry Recorded',
      detail: `All cryptographic and policy events logged to tamper-evident audit ledger.`,
      status: 'SUCCESS',
    });

    res.json({
      success: true,
      deviceId: device.id,
      steps,
      finalState: store.getDevice(device.id),
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 12. GLOBAL SEARCH & RESET
// ==========================================

apiRouter.get('/search', (req, res) => {
  try {
    const q = ((req.query.q as string) || '').trim().toLowerCase();
    if (!q) {
      res.json({ success: true, data: { devices: [], threats: [], auditLogs: [] } });
      return;
    }

    const devices = store
      .getDevices()
      .filter(
        (d) =>
          d.name.toLowerCase().includes(q) ||
          d.id.toLowerCase().includes(q) ||
          d.ipAddress.includes(q) ||
          d.cryptoAlgorithm.toLowerCase().includes(q)
      )
      .slice(0, 5);

    const threats = store
      .getThreats()
      .filter(
        (t) =>
          t.id.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          t.deviceName.toLowerCase().includes(q)
      )
      .slice(0, 5);

    const auditLogs = store
      .getAuditLogs({ search: q })
      .slice(0, 5);

    res.json({
      success: true,
      data: { devices, threats, auditLogs },
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

apiRouter.post('/reset', (_req, res) => {
  try {
    store.seedInitialData();
    res.json({ success: true, message: 'Database reset to initial fleet seed successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});
