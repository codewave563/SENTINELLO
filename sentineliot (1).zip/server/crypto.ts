import crypto from 'node:crypto';
import type { CryptoAlgorithm, CryptoBenchmarkResult, CryptoKeyDetails } from '../src/types/index.ts';

export interface KeyPairResult {
  algorithm: CryptoAlgorithm;
  curveOrBits: string;
  publicKeyPem: string;
  privateKeyPem: string;
  fingerprint: string;
  createdAt: string;
}

/**
 * Generate cryptographic key pair using real OpenSSL primitives
 */
export function generateKeyPair(algorithm: CryptoAlgorithm): KeyPairResult {
  const createdAt = new Date().toISOString();

  if (algorithm === 'ECDSA_P256') {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
      namedCurve: 'prime256v1',
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    });
    const fingerprint = calculateFingerprint(publicKey);
    return {
      algorithm,
      curveOrBits: 'NIST P-256 (secp256r1)',
      publicKeyPem: publicKey,
      privateKeyPem: privateKey,
      fingerprint,
      createdAt,
    };
  }

  if (algorithm === 'ED25519') {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519', {
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    });
    const fingerprint = calculateFingerprint(publicKey);
    return {
      algorithm,
      curveOrBits: 'Curve25519 (256-bit)',
      publicKeyPem: publicKey,
      privateKeyPem: privateKey,
      fingerprint,
      createdAt,
    };
  }

  if (algorithm === 'RSA_2048') {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
      modulusLength: 2048,
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    });
    const fingerprint = calculateFingerprint(publicKey);
    return {
      algorithm,
      curveOrBits: '2048-bit Modulus',
      publicKeyPem: publicKey,
      privateKeyPem: privateKey,
      fingerprint,
      createdAt,
    };
  }

  throw new Error(`Unsupported algorithm: ${algorithm}`);
}

/**
 * Compute SHA-256 fingerprint for a public key
 */
export function calculateFingerprint(publicKeyPem: string): string {
  // Strip PEM header/footer to hash standard base64/binary representation
  const cleanKey = publicKeyPem
    .replace(/-----BEGIN [A-Z ]+-----/g, '')
    .replace(/-----END [A-Z ]+-----/g, '')
    .replace(/\s+/g, '');
  const buffer = Buffer.from(cleanKey, 'base64');
  const hash = crypto.createHash('sha256').update(buffer).digest('hex');
  // Format with colon delimiters
  const formatted = hash.match(/.{1,2}/g)?.slice(0, 16).join(':') ?? hash.slice(0, 32);
  return `SHA256:${formatted}`;
}

/**
 * Generate a cryptographically secure 32-byte hexadecimal nonce
 */
export function generateSecureNonce(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Sign data using private key and algorithm
 */
export function signData(algorithm: CryptoAlgorithm, privateKeyPem: string, data: string): string {
  if (algorithm === 'ECDSA_P256' || algorithm === 'RSA_2048') {
    const signer = crypto.createSign('SHA256');
    signer.update(data);
    return signer.sign(privateKeyPem, 'base64');
  }

  if (algorithm === 'ED25519') {
    return crypto.sign(null, Buffer.from(data), privateKeyPem).toString('base64');
  }

  throw new Error(`Unsupported algorithm: ${algorithm}`);
}

/**
 * Verify data signature using public key and algorithm
 */
export function verifySignature(
  algorithm: CryptoAlgorithm,
  publicKeyPem: string,
  data: string,
  signatureBase64: string
): boolean {
  try {
    if (algorithm === 'ECDSA_P256' || algorithm === 'RSA_2048') {
      const verifier = crypto.createVerify('SHA256');
      verifier.update(data);
      return verifier.verify(publicKeyPem, signatureBase64, 'base64');
    }

    if (algorithm === 'ED25519') {
      return crypto.verify(
        null,
        Buffer.from(data),
        publicKeyPem,
        Buffer.from(signatureBase64, 'base64')
      );
    }

    return false;
  } catch (err) {
    return false;
  }
}

/**
 * Run high-precision cryptographic benchmarks using process.hrtime.bigint()
 */
export function runCryptographicBenchmark(): CryptoBenchmarkResult[] {
  const algorithms: CryptoAlgorithm[] = ['ECDSA_P256', 'ED25519', 'RSA_2048'];
  const testMessage = 'SENTINEL_IOT_CHALLENGE_NONCE_VERIFICATION_PAYLOAD_v1.0';
  const iterations = 10;

  return algorithms.map((alg) => {
    // 1. Measure Key Generation
    const keyGenStart = process.hrtime.bigint();
    let generatedKey: KeyPairResult | null = null;
    for (let i = 0; i < iterations; i++) {
      generatedKey = generateKeyPair(alg);
    }
    const keyGenEnd = process.hrtime.bigint();
    const keyGenMs = Number(keyGenEnd - keyGenStart) / (1e6 * iterations);

    if (!generatedKey) throw new Error('Key generation failed');

    // 2. Measure Signing
    const signStart = process.hrtime.bigint();
    let lastSig = '';
    for (let i = 0; i < iterations * 2; i++) {
      lastSig = signData(alg, generatedKey.privateKeyPem, testMessage);
    }
    const signEnd = process.hrtime.bigint();
    const signMs = Number(signEnd - signStart) / (1e6 * iterations * 2);

    // 3. Measure Verification
    const verifyStart = process.hrtime.bigint();
    for (let i = 0; i < iterations * 2; i++) {
      verifySignature(alg, generatedKey.publicKeyPem, testMessage, lastSig);
    }
    const verifyEnd = process.hrtime.bigint();
    const verifyMs = Number(verifyEnd - verifyStart) / (1e6 * iterations * 2);

    const signatureSizeBytes = Buffer.from(lastSig, 'base64').length;
    const publicKeySizeBytes = Buffer.byteLength(generatedKey.publicKeyPem, 'utf8');

    let label = 'ECDSA P-256';
    let curveOrBits = 'secp256r1 (SHA-256)';
    let securityBitsEquivalent = 128;
    let tradeoffRecommendation =
      'Optimal for standard enterprise compliance, FIPS 186-4, hardware crypto co-processors (e.g. ATECC608A).';

    if (alg === 'ED25519') {
      label = 'Ed25519';
      curveOrBits = 'Curve25519 (EdDSA)';
      securityBitsEquivalent = 128;
      tradeoffRecommendation =
        'Fastest signing and verification. Immune to timing attacks. Extremely low battery/compute overhead for constrained IoT.';
    } else if (alg === 'RSA_2048') {
      label = 'RSA-2048';
      curveOrBits = '2048-bit (PKCS#1 v1.5)';
      securityBitsEquivalent = 112;
      tradeoffRecommendation =
        'Legacy compatibility. Fast verification on gateways, but high keygen/sign latency and large payload overhead.';
    }

    return {
      algorithm: alg,
      label,
      curveOrBits,
      keyGenMs: Number(keyGenMs.toFixed(3)),
      signMs: Number(signMs.toFixed(3)),
      verifyMs: Number(verifyMs.toFixed(3)),
      signatureSizeBytes,
      publicKeySizeBytes,
      securityBitsEquivalent,
      tradeoffRecommendation,
    };
  });
}
