import { randomUUID } from 'node:crypto';
import type {
  AuditLog,
  AuthAttempt,
  ChallengeResponse,
  CryptoAlgorithm,
  Device,
  DeviceStatus,
  NotificationItem,
  PolicyDecision,
  SystemHealth,
  ThreatCategory,
  ThreatEvent,
  ThreatSeverity,
  VerificationResult,
} from '../src/types/index.ts';
import {
  generateKeyPair,
  generateSecureNonce,
  signData,
  verifySignature,
} from './crypto.ts';
import { evaluateZeroTrust } from './zero-trust.ts';

interface StoredDeviceKey {
  deviceId: string;
  algorithm: CryptoAlgorithm;
  publicKeyPem: string;
  privateKeyPem: string;
  fingerprint: string;
}

interface StoredNonce {
  nonce: string;
  deviceId: string;
  issuedAt: number;
  expiresAt: number;
  consumed: boolean;
}

class SentinelStore {
  private devices: Map<string, Device> = new Map();
  private deviceKeys: Map<string, StoredDeviceKey> = new Map();
  private nonces: Map<string, StoredNonce> = new Map();
  private authAttempts: AuthAttempt[] = [];
  private threats: ThreatEvent[] = [];
  private auditLogs: AuditLog[] = [];
  private notifications: NotificationItem[] = [];
  private startTime: number = Date.now();
  private totalEventsCounter = 0;

  constructor() {
    this.seedInitialData();
  }

  /**
   * Populate realistic initial synthetic IoT fleet
   */
  public seedInitialData(): void {
    this.devices.clear();
    this.deviceKeys.clear();
    this.nonces.clear();
    this.authAttempts = [];
    this.threats = [];
    this.auditLogs = [];
    this.notifications = [];
    this.startTime = Date.now();
    this.totalEventsCounter = 0;

    // Device 1: ESP32-07 (Trusted Temperature Sensor with Ed25519)
    this.createAndRegisterDevice({
      id: 'IOT-ESP32-07',
      name: 'Cleanroom Temp & Humidity Sensor',
      type: 'SENSOR',
      ipAddress: '192.168.10.45',
      manufacturer: 'Espressif Systems',
      firmwareVersion: 'v2.4.1-patch2',
      cryptoAlgorithm: 'ED25519',
      status: 'TRUSTED',
      firmwareAgeMonths: 3,
      telemetry: {
        requestFrequency: 12,
        packetFrequency: 2.1,
        failedAuthCount: 0,
        sessionDuration: 720,
        bytesSent: 480,
        bytesReceived: 190,
        uniqueDestinations: 1,
        commandFrequency: 0.1,
        timeSinceLastSeen: 14,
        authFailureRate: 0.0,
      },
    });

    // Device 2: EDGE-GW-01 (Industrial Edge Gateway with ECDSA P-256)
    this.createAndRegisterDevice({
      id: 'IOT-EDGE-GW-01',
      name: 'North Plant Telemetry Aggregator',
      type: 'GATEWAY',
      ipAddress: '192.168.10.1',
      manufacturer: 'Advantech Embedded',
      firmwareVersion: 'v4.18.0-lts',
      cryptoAlgorithm: 'ECDSA_P256',
      status: 'TRUSTED',
      firmwareAgeMonths: 5,
      telemetry: {
        requestFrequency: 45,
        packetFrequency: 15.2,
        failedAuthCount: 0,
        sessionDuration: 3600,
        bytesSent: 7800,
        bytesReceived: 4200,
        uniqueDestinations: 3,
        commandFrequency: 4.2,
        timeSinceLastSeen: 8,
        authFailureRate: 0.0,
      },
    });

    // Device 3: ENV-STATION-04 (Air Quality Monitor with Ed25519)
    this.createAndRegisterDevice({
      id: 'IOT-ENV-STN-04',
      name: 'Perimeter VOC & Particulate Monitor',
      type: 'SENSOR',
      ipAddress: '192.168.10.82',
      manufacturer: 'Bosch Sensortec',
      firmwareVersion: 'v1.9.0',
      cryptoAlgorithm: 'ED25519',
      status: 'ONLINE',
      firmwareAgeMonths: 8,
      telemetry: {
        requestFrequency: 14,
        packetFrequency: 2.4,
        failedAuthCount: 0,
        sessionDuration: 640,
        bytesSent: 520,
        bytesReceived: 210,
        uniqueDestinations: 1,
        commandFrequency: 0.2,
        timeSinceLastSeen: 32,
        authFailureRate: 0.02,
      },
    });

    // Device 4: PLC-ACTUATOR-12 (Hydraulic Valve Controller - Suspicious)
    this.createAndRegisterDevice({
      id: 'IOT-PLC-ACT-12',
      name: 'Cooling Loop Hydraulic Controller',
      type: 'CONTROLLER',
      ipAddress: '192.168.20.104',
      manufacturer: 'Siemens Industrial',
      firmwareVersion: 'v3.1.2-legacy',
      cryptoAlgorithm: 'ECDSA_P256',
      status: 'SUSPICIOUS',
      firmwareAgeMonths: 19,
      telemetry: {
        requestFrequency: 68,
        packetFrequency: 28.5,
        failedAuthCount: 2,
        sessionDuration: 2200,
        bytesSent: 16500,
        bytesReceived: 3800,
        uniqueDestinations: 5,
        commandFrequency: 14.8,
        timeSinceLastSeen: 21,
        authFailureRate: 0.22,
      },
    });

    // Device 5: CAM-SURV-09 (Security Surveillance - RSA-2048)
    this.createAndRegisterDevice({
      id: 'IOT-CAM-SURV-09',
      name: 'Facility Gate Optical Surveillance',
      type: 'CAMERA',
      ipAddress: '192.168.30.55',
      manufacturer: 'Axis Communications',
      firmwareVersion: 'v10.12.0',
      cryptoAlgorithm: 'RSA_2048',
      status: 'ONLINE',
      firmwareAgeMonths: 6,
      telemetry: {
        requestFrequency: 58,
        packetFrequency: 42.0,
        failedAuthCount: 0,
        sessionDuration: 7200,
        bytesSent: 39500,
        bytesReceived: 1400,
        uniqueDestinations: 2,
        commandFrequency: 0.6,
        timeSinceLastSeen: 5,
        authFailureRate: 0.0,
      },
    });

    // Device 6: SMART-METER-88 (Substation Power Meter with ECDSA P-256)
    this.createAndRegisterDevice({
      id: 'IOT-METER-88',
      name: 'High-Voltage Substation Wattmeter',
      type: 'METER',
      ipAddress: '192.168.10.190',
      manufacturer: 'Schneider Electric',
      firmwareVersion: 'v2.0.4',
      cryptoAlgorithm: 'ECDSA_P256',
      status: 'ONLINE',
      firmwareAgeMonths: 11,
      telemetry: {
        requestFrequency: 6,
        packetFrequency: 1.1,
        failedAuthCount: 0,
        sessionDuration: 14400,
        bytesSent: 310,
        bytesReceived: 150,
        uniqueDestinations: 1,
        commandFrequency: 0.05,
        timeSinceLastSeen: 45,
        authFailureRate: 0.0,
      },
    });

    // Device 7: SCADA-VALVE-03 (Quarantined Device due to replay attack attempt)
    this.createAndRegisterDevice({
      id: 'IOT-SCADA-VALVE-03',
      name: 'Effluent Neutralization Valve',
      type: 'ACTUATOR',
      ipAddress: '192.168.20.77',
      manufacturer: 'Honeywell Process',
      firmwareVersion: 'v1.4.0',
      cryptoAlgorithm: 'ED25519',
      status: 'QUARANTINED',
      firmwareAgeMonths: 26,
      telemetry: {
        requestFrequency: 112,
        packetFrequency: 34.0,
        failedAuthCount: 5,
        sessionDuration: 45,
        bytesSent: 8900,
        bytesReceived: 2100,
        uniqueDestinations: 4,
        commandFrequency: 22.0,
        timeSinceLastSeen: 180,
        authFailureRate: 0.65,
      },
    });

    // Seed existing threats
    this.addThreat({
      id: 'THR-8902',
      timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
      deviceId: 'IOT-SCADA-VALVE-03',
      deviceName: 'Effluent Neutralization Valve',
      category: 'REPLAY_ATTACK',
      severity: 'CRITICAL',
      riskScore: 88,
      status: 'CONTAINED',
      description: 'Stale cryptographic nonce resubmission detected. Challenge timestamp exceeded 300s delta window.',
      responseAction: 'QUARANTINE',
      containedAt: new Date(Date.now() - 13 * 60 * 1000).toISOString(),
      investigationNotes: 'Automated policy isolated device to VLAN 99. Zero-Trust decision verified.',
    });

    this.addThreat({
      id: 'THR-8901',
      timestamp: new Date(Date.now() - 48 * 60 * 1000).toISOString(),
      deviceId: 'IOT-PLC-ACT-12',
      deviceName: 'Cooling Loop Hydraulic Controller',
      category: 'ANOMALOUS_BEHAVIOUR',
      severity: 'HIGH',
      riskScore: 72,
      status: 'INVESTIGATING',
      description: 'AI model isolated sudden 4.8x surge in actuator command frequency from unapproved IP gateway.',
      responseAction: 'RESTRICT',
      investigationNotes: 'Rate-limiting policy activated. Restricted to read-only telemetry mode.',
    });

    // Seed recent audit events
    this.addAuditLog({
      id: 'AUD-1001',
      timestamp: new Date(Date.now() - 65 * 60 * 1000).toISOString(),
      event: 'SYSTEM_BOOT',
      source: 'SOC_ADMIN',
      result: 'SUCCESS',
      details: 'SentinelIoT SOC security daemon initialized with Zero-Trust enforcement engine.',
      severity: 'INFO',
    });

    this.addAuditLog({
      id: 'AUD-1002',
      timestamp: new Date(Date.now() - 50 * 60 * 1000).toISOString(),
      event: 'DEVICE_REGISTERED',
      deviceId: 'IOT-ESP32-07',
      deviceName: 'Cleanroom Temp & Humidity Sensor',
      source: 'CRYPTO_ENGINE',
      result: 'SUCCESS',
      details: 'Ed25519 identity keypair generated and public key bound to hardware MAC.',
      severity: 'INFO',
    });

    this.addAuditLog({
      id: 'AUD-1003',
      timestamp: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
      event: 'AUTHENTICATION_SUCCESS',
      deviceId: 'IOT-ESP32-07',
      deviceName: 'Cleanroom Temp & Humidity Sensor',
      source: 'AUTH_SERVICE',
      result: 'SUCCESS',
      details: 'Ed25519 signature verified on 32-byte nonce. Timestamp freshness delta: 82ms.',
      severity: 'INFO',
    });

    this.addAuditLog({
      id: 'AUD-1004',
      timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
      event: 'REPLAY_ATTACK_DETECTED',
      deviceId: 'IOT-SCADA-VALVE-03',
      deviceName: 'Effluent Neutralization Valve',
      source: 'AUTH_SERVICE',
      result: 'BLOCKED',
      details: 'Reused nonce payload rejected. Cryptographic signature invalid for session.',
      severity: 'CRITICAL',
    });

    this.addAuditLog({
      id: 'AUD-1005',
      timestamp: new Date(Date.now() - 13 * 60 * 1000).toISOString(),
      event: 'DEVICE_QUARANTINED',
      deviceId: 'IOT-SCADA-VALVE-03',
      deviceName: 'Effluent Neutralization Valve',
      source: 'ZERO_TRUST',
      result: 'BLOCKED',
      details: 'Zero-Trust Policy triggered QUARANTINE action. Risk score evaluated at 88/100.',
      severity: 'CRITICAL',
    });

    // Seed recent auth attempts
    this.authAttempts.push(
      {
        id: 'AUTH-901',
        timestamp: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
        deviceId: 'IOT-ESP32-07',
        deviceName: 'Cleanroom Temp & Humidity Sensor',
        nonce: '4f88e2c091ad78ef219ba382901a76c4e09f582b9012a839cf9e7284b0198c21',
        algorithm: 'ED25519',
        signatureValid: true,
        timestampValid: true,
        nonceValid: true,
        result: 'SUCCESS',
        latencyMs: 1.4,
      },
      {
        id: 'AUTH-902',
        timestamp: new Date(Date.now() - 28 * 60 * 1000).toISOString(),
        deviceId: 'IOT-EDGE-GW-01',
        deviceName: 'North Plant Telemetry Aggregator',
        nonce: 'a90e3810fca782190cd91280fae948201a89b023f901c9034980daef18902cae',
        algorithm: 'ECDSA_P256',
        signatureValid: true,
        timestampValid: true,
        nonceValid: true,
        result: 'SUCCESS',
        latencyMs: 3.8,
      },
      {
        id: 'AUTH-903',
        timestamp: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
        deviceId: 'IOT-SCADA-VALVE-03',
        deviceName: 'Effluent Neutralization Valve',
        nonce: '4f88e2c091ad78ef219ba382901a76c4e09f582b9012a839cf9e7284b0198c21', // replayed!
        algorithm: 'ED25519',
        signatureValid: false,
        timestampValid: false,
        nonceValid: false,
        result: 'REPLAY_BLOCKED',
        latencyMs: 0.9,
        failureReason: 'Nonce previously consumed; replay attempt aborted.',
      }
    );

    // Initial notifications
    this.notifications.push(
      {
        id: 'NOTIF-1',
        timestamp: new Date(Date.now() - 13 * 60 * 1000).toISOString(),
        title: 'Zero-Trust Quarantine Action',
        message: 'Device IOT-SCADA-VALVE-03 was quarantined due to replay attack attempt.',
        severity: 'CRITICAL',
        read: false,
        deviceId: 'IOT-SCADA-VALVE-03',
      },
      {
        id: 'NOTIF-2',
        timestamp: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        title: 'Elevated Risk Alert',
        message: 'Device IOT-PLC-ACT-12 flagged by AI engine with 4.8x command frequency surge.',
        severity: 'WARNING',
        read: false,
        deviceId: 'IOT-PLC-ACT-12',
      }
    );
  }

  /**
   * Helper to create device with real key generation
   */
  private createAndRegisterDevice(params: {
    id: string;
    name: string;
    type: Device['type'];
    ipAddress: string;
    manufacturer: string;
    firmwareVersion: string;
    cryptoAlgorithm: CryptoAlgorithm;
    status: DeviceStatus;
    firmwareAgeMonths: number;
    telemetry: Device['telemetry'];
  }): Device {
    const keyPair = generateKeyPair(params.cryptoAlgorithm);

    this.deviceKeys.set(params.id, {
      deviceId: params.id,
      algorithm: params.cryptoAlgorithm,
      publicKeyPem: keyPair.publicKeyPem,
      privateKeyPem: keyPair.privateKeyPem,
      fingerprint: keyPair.fingerprint,
    });

    const registeredAt = new Date(Date.now() - 14 * 86400 * 1000).toISOString();
    const lastSeen = new Date(Date.now() - params.telemetry.timeSinceLastSeen * 1000).toISOString();

    const partialDevice: Device = {
      id: params.id,
      name: params.name,
      type: params.type,
      ipAddress: params.ipAddress,
      manufacturer: params.manufacturer,
      firmwareVersion: params.firmwareVersion,
      cryptoAlgorithm: params.cryptoAlgorithm,
      status: params.status,
      trustScore: 90,
      riskScore: 10,
      riskLevel: 'LOW',
      lastSeen,
      registeredAt,
      publicKeyPem: keyPair.publicKeyPem,
      keyFingerprint: keyPair.fingerprint,
      firmwareAgeMonths: params.firmwareAgeMonths,
      telemetry: params.telemetry,
    };

    // Calculate initial Zero-Trust evaluation
    const zt = evaluateZeroTrust(partialDevice, 0);
    partialDevice.trustScore = zt.overallTrustScore;
    partialDevice.riskScore = zt.riskScore;
    partialDevice.riskLevel = zt.riskLevel;

    this.devices.set(params.id, partialDevice);
    return partialDevice;
  }

  // --- Public Device Operations ---

  public getDevices(): Device[] {
    return Array.from(this.devices.values());
  }

  public getDevice(id: string): Device | undefined {
    return this.devices.get(id);
  }

  public registerDevice(data: {
    name: string;
    type: Device['type'];
    ipAddress: string;
    manufacturer: string;
    firmwareVersion: string;
    cryptoAlgorithm: CryptoAlgorithm;
  }): Device {
    const id = `IOT-${data.type.slice(0, 3)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newDevice = this.createAndRegisterDevice({
      id,
      name: data.name,
      type: data.type,
      ipAddress: data.ipAddress,
      manufacturer: data.manufacturer,
      firmwareVersion: data.firmwareVersion,
      cryptoAlgorithm: data.cryptoAlgorithm,
      status: 'ONLINE',
      firmwareAgeMonths: 1,
      telemetry: {
        requestFrequency: 10,
        packetFrequency: 2,
        failedAuthCount: 0,
        sessionDuration: 300,
        bytesSent: 400,
        bytesReceived: 180,
        uniqueDestinations: 1,
        commandFrequency: 0.1,
        timeSinceLastSeen: 2,
        authFailureRate: 0.0,
      },
    });

    this.addAuditLog({
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      event: 'DEVICE_REGISTERED',
      deviceId: id,
      deviceName: newDevice.name,
      source: 'SOC_ADMIN',
      result: 'SUCCESS',
      details: `New device enrolled with algorithm ${newDevice.cryptoAlgorithm}. Fingerprint: ${newDevice.keyFingerprint}`,
      severity: 'INFO',
    });

    this.addNotification({
      title: 'Device Registered',
      message: `Enrolled device "${newDevice.name}" (${newDevice.id}) with cryptographic identity.`,
      severity: 'SUCCESS',
      deviceId: newDevice.id,
    });

    return newDevice;
  }

  public updateDeviceStatus(id: string, newStatus: DeviceStatus, reason?: string): Device {
    const device = this.devices.get(id);
    if (!device) throw new Error(`Device ${id} not found`);

    const prevStatus = device.status;
    device.status = newStatus;

    // Recalculate trust & risk
    const zt = evaluateZeroTrust(device, this.getActiveThreatCount(id));
    device.trustScore = zt.overallTrustScore;
    device.riskScore = zt.riskScore;
    device.riskLevel = zt.riskLevel;
    device.lastSeen = new Date().toISOString();

    this.addAuditLog({
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      event: `DEVICE_${newStatus}`,
      deviceId: id,
      deviceName: device.name,
      source: 'SOC_ADMIN',
      result: 'SUCCESS',
      details: `Status transitioned from ${prevStatus} to ${newStatus}. ${reason ?? ''}`,
      severity: newStatus === 'QUARANTINED' || newStatus === 'BLOCKED' ? 'CRITICAL' : 'INFO',
    });

    this.addNotification({
      title: `Device Status: ${newStatus}`,
      message: `Device ${device.name} (${id}) status changed to ${newStatus}.`,
      severity: newStatus === 'QUARANTINED' || newStatus === 'BLOCKED' ? 'CRITICAL' : 'INFO',
      deviceId: id,
    });

    return device;
  }

  public updateDeviceTelemetry(id: string, telemetryPatch: Partial<Device['telemetry']>): Device {
    const device = this.devices.get(id);
    if (!device) throw new Error(`Device ${id} not found`);

    device.telemetry = { ...device.telemetry, ...telemetryPatch };
    device.lastSeen = new Date().toISOString();

    const zt = evaluateZeroTrust(device, this.getActiveThreatCount(id));
    device.trustScore = zt.overallTrustScore;
    device.riskScore = zt.riskScore;
    device.riskLevel = zt.riskLevel;

    return device;
  }

  // --- Challenge-Response Authentication ---

  public issueChallenge(deviceId: string): ChallengeResponse {
    const device = this.devices.get(deviceId);
    if (!device) throw new Error(`Device ${deviceId} is not registered`);

    const nonce = generateSecureNonce();
    const now = Date.now();
    const expiresAt = now + 60 * 1000; // 60s expiration window

    this.nonces.set(nonce, {
      nonce,
      deviceId,
      issuedAt: now,
      expiresAt,
      consumed: false,
    });

    this.totalEventsCounter++;

    return {
      nonce,
      timestamp: now,
      deviceId,
      expiresAt,
      algorithm: device.cryptoAlgorithm,
    };
  }

  public verifyChallenge(
    deviceId: string,
    nonce: string,
    signatureBase64: string,
    clientTimestamp: number,
    options?: { forceReplay?: boolean; corruptSignature?: boolean; skewTimestamp?: boolean }
  ): VerificationResult {
    const startTime = process.hrtime.bigint();
    const device = this.devices.get(deviceId);
    const keyData = this.deviceKeys.get(deviceId);

    if (!device || !keyData) {
      return {
        success: false,
        deviceId,
        algorithm: 'ECDSA_P256',
        signatureValid: false,
        timestampValid: false,
        nonceValid: false,
        latencyMs: 0.5,
        message: 'Device identity not registered in Zero-Trust catalog',
        failureReason: 'UNKNOWN_DEVICE',
        policyDecision: 'BLOCK',
        trustScore: 0,
        riskScore: 100,
      };
    }

    const nonceEntry = this.nonces.get(nonce);
    const now = Date.now();

    // 1. Timestamp Freshness Check (tolerance: 60 seconds)
    const timestampDelta = Math.abs(now - clientTimestamp);
    const timestampValid = !options?.skewTimestamp && timestampDelta <= 60000;

    // 2. Nonce Validation & Single-Use Replay Protection
    let nonceValid = false;
    let isReplay = false;

    if (nonceEntry && nonceEntry.deviceId === deviceId) {
      if (nonceEntry.consumed || options?.forceReplay) {
        isReplay = true;
        nonceValid = false;
      } else if (now > nonceEntry.expiresAt) {
        nonceValid = false;
      } else {
        nonceValid = true;
        // Mark as consumed immediately to prevent replay
        nonceEntry.consumed = true;
      }
    }

    // 3. Cryptographic Signature Verification
    const payload = `${deviceId}:${nonce}:${clientTimestamp}`;
    let signatureValid = false;

    if (!options?.corruptSignature) {
      signatureValid = verifySignature(
        keyData.algorithm,
        keyData.publicKeyPem,
        payload,
        signatureBase64
      );
    }

    const endTime = process.hrtime.bigint();
    const latencyMs = Number(endTime - startTime) / 1e6;

    const success = signatureValid && timestampValid && nonceValid;

    let failureReason: string | undefined;
    if (isReplay) {
      failureReason = 'Cryptographic nonce reuse detected (Replay Attack blocked)';
    } else if (!nonceValid) {
      failureReason = 'Nonce expired or invalid for this device session';
    } else if (!timestampValid) {
      failureReason = `Challenge timestamp out of tolerance (${(timestampDelta / 1000).toFixed(1)}s skew)`;
    } else if (!signatureValid) {
      failureReason = 'Digital signature verification failed against registered public key';
    }

    // Record auth attempt
    const attempt: AuthAttempt = {
      id: `AUTH-${Date.now().toString().slice(-5)}`,
      timestamp: new Date().toISOString(),
      deviceId,
      deviceName: device.name,
      nonce,
      algorithm: keyData.algorithm,
      signatureValid,
      timestampValid,
      nonceValid,
      result: isReplay ? 'REPLAY_BLOCKED' : success ? 'SUCCESS' : 'FAILED',
      latencyMs: Number(latencyMs.toFixed(2)),
      failureReason,
    };
    this.authAttempts.unshift(attempt);
    if (this.authAttempts.length > 100) this.authAttempts.pop();

    this.totalEventsCounter++;

    // Evaluate Zero Trust
    if (!success) {
      device.telemetry.failedAuthCount += 1;
      device.telemetry.authFailureRate = Math.min(1.0, device.telemetry.authFailureRate + 0.15);
    } else {
      device.telemetry.failedAuthCount = 0;
      device.telemetry.authFailureRate = Math.max(0, device.telemetry.authFailureRate - 0.05);
      device.status = device.status === 'SUSPICIOUS' ? 'ONLINE' : device.status;
    }

    const zt = evaluateZeroTrust(device, this.getActiveThreatCount(deviceId));
    device.trustScore = zt.overallTrustScore;
    device.riskScore = zt.riskScore;
    device.riskLevel = zt.riskLevel;

    // Log to Audit Trail
    this.addAuditLog({
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      event: success ? 'AUTHENTICATION_SUCCESS' : isReplay ? 'REPLAY_ATTACK_DETECTED' : 'AUTHENTICATION_FAILED',
      deviceId,
      deviceName: device.name,
      source: 'AUTH_SERVICE',
      result: success ? 'SUCCESS' : 'DENIED',
      details: success
        ? `Challenge-response verified with ${keyData.algorithm}. Nonce consumed in ${latencyMs.toFixed(2)}ms.`
        : `Authentication rejected: ${failureReason}`,
      severity: isReplay ? 'CRITICAL' : success ? 'INFO' : 'WARNING',
    });

    return {
      success,
      deviceId,
      algorithm: keyData.algorithm,
      signatureValid,
      timestampValid,
      nonceValid,
      latencyMs: Number(latencyMs.toFixed(2)),
      message: success
        ? 'Mutual cryptographic challenge verified successfully'
        : `Authentication rejected: ${failureReason}`,
      failureReason,
      policyDecision: zt.policyDecision,
      trustScore: zt.overallTrustScore,
      riskScore: zt.riskScore,
    };
  }

  /**
   * Helper to sign challenge on device's behalf for testing/simulation
   */
  public signChallengeLocally(deviceId: string, nonce: string, timestamp: number): string {
    const keyData = this.deviceKeys.get(deviceId);
    if (!keyData) throw new Error(`Device key for ${deviceId} not found`);

    const payload = `${deviceId}:${nonce}:${timestamp}`;
    return signData(keyData.algorithm, keyData.privateKeyPem, payload);
  }

  // --- Threat Management ---

  public getThreats(): ThreatEvent[] {
    return this.threats.map((t) => {
      if (!t.investigationTimeline) {
        t.investigationTimeline = this.generateInvestigationTimeline(t);
      }
      return t;
    });
  }

  public getThreat(id: string): ThreatEvent | undefined {
    const threat = this.threats.find((t) => t.id === id);
    if (threat && !threat.investigationTimeline) {
      threat.investigationTimeline = this.generateInvestigationTimeline(threat);
    }
    return threat;
  }

  private generateInvestigationTimeline(threat: ThreatEvent) {
    const baseTime = new Date(threat.timestamp).getTime();
    const isContained = threat.status === 'CONTAINED' || threat.status === 'RESOLVED';
    return [
      {
        stage: 'DETECTED' as const,
        label: 'Security Anomaly Ingestion',
        timestamp: new Date(baseTime).toISOString(),
        status: 'COMPLETED' as const,
        description: `Telemetry stream or cryptographic boundary flagged potential violation [${threat.category}].`,
      },
      {
        stage: 'ANALYZED' as const,
        label: 'Root Cause & Context Extraction',
        timestamp: new Date(baseTime + 1800).toISOString(),
        status: 'COMPLETED' as const,
        description: `Target hardware [${threat.deviceName}] identified. SPKI fingerprint validated against catalog.`,
      },
      {
        stage: 'RISK_CALCULATED' as const,
        label: 'Zero-Trust Risk Scoring',
        timestamp: new Date(baseTime + 3200).toISOString(),
        status: 'COMPLETED' as const,
        description: `Dynamic risk calculated at ${threat.riskScore}/100 (${threat.severity} severity tier).`,
      },
      {
        stage: 'POLICY_EVALUATED' as const,
        label: 'Automated Policy Arbitration',
        timestamp: new Date(baseTime + 4100).toISOString(),
        status: 'COMPLETED' as const,
        description: `Rule triggered: Zero-Trust evaluated automated response [${threat.responseAction}].`,
      },
      {
        stage: 'RESPONSE_INITIATED' as const,
        label: 'Defensive Action Enforcement',
        timestamp: new Date(baseTime + 5400).toISOString(),
        status: 'COMPLETED' as const,
        description: `Device isolated from default telemetry subnet. Session tokens revoked.`,
      },
      {
        stage: 'CONTAINED' as const,
        label: 'SOC Containment & Verification',
        timestamp: threat.containedAt || new Date(baseTime + 8000).toISOString(),
        status: isContained ? ('COMPLETED' as const) : ('IN_PROGRESS' as const),
        description: isContained
          ? threat.investigationNotes || 'Incident contained by SOC Analyst. Forensics logged.'
          : 'Awaiting manual SOC Analyst review or active automated containment monitor.',
      },
    ];
  }

  public addThreat(threat: ThreatEvent): void {
    if (!threat.investigationTimeline) {
      threat.investigationTimeline = this.generateInvestigationTimeline(threat);
    }
    this.threats.unshift(threat);
    this.totalEventsCounter++;

    this.addNotification({
      title: `Threat Detected: ${threat.category}`,
      message: `${threat.description} (Device: ${threat.deviceName})`,
      severity: threat.severity === 'CRITICAL' ? 'CRITICAL' : 'WARNING',
      deviceId: threat.deviceId,
      threatId: threat.id,
      linkTab: 'threat-center',
    });
  }

  public containThreat(id: string, notes?: string): ThreatEvent {
    const threat = this.threats.find((t) => t.id === id);
    if (!threat) throw new Error(`Threat ${id} not found`);

    threat.status = 'CONTAINED';
    threat.containedAt = new Date().toISOString();
    threat.investigationNotes = notes ?? 'Containment verified by Security Analyst.';
    threat.investigationTimeline = this.generateInvestigationTimeline(threat);

    this.addAuditLog({
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      event: 'THREAT_CONTAINED',
      deviceId: threat.deviceId,
      deviceName: threat.deviceName,
      source: 'SOC_ADMIN',
      result: 'SUCCESS',
      details: `Threat ${id} (${threat.category}) transitioned to CONTAINED.`,
      severity: 'INFO',
    });

    return threat;
  }

  public getActiveThreatCount(deviceId?: string): number {
    return this.threats.filter((t) => {
      const matchDevice = deviceId ? t.deviceId === deviceId : true;
      return matchDevice && (t.status === 'DETECTED' || t.status === 'INVESTIGATING');
    }).length;
  }

  // --- Audit Logs ---

  public getAuditLogs(filter?: {
    deviceId?: string;
    severity?: string;
    search?: string;
  }): AuditLog[] {
    let logs = [...this.auditLogs];

    if (filter?.deviceId) {
      logs = logs.filter((l) => l.deviceId === filter.deviceId);
    }
    if (filter?.severity && filter.severity !== 'ALL') {
      logs = logs.filter((l) => l.severity === filter.severity);
    }
    if (filter?.search) {
      const q = filter.search.toLowerCase();
      logs = logs.filter(
        (l) =>
          l.event.toLowerCase().includes(q) ||
          l.details.toLowerCase().includes(q) ||
          (l.deviceName && l.deviceName.toLowerCase().includes(q)) ||
          (l.deviceId && l.deviceId.toLowerCase().includes(q))
      );
    }

    return logs;
  }

  public addAuditLog(entry: AuditLog): void {
    this.auditLogs.unshift(entry);
    if (this.auditLogs.length > 250) this.auditLogs.pop();
  }

  // --- Notifications ---

  public getNotifications(): NotificationItem[] {
    return [...this.notifications];
  }

  public addNotification(item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>): void {
    const notif: NotificationItem = {
      ...item,
      id: `NOTIF-${Date.now().toString().slice(-4)}-${Math.floor(Math.random() * 100)}`,
      timestamp: new Date().toISOString(),
      read: false,
    };
    this.notifications.unshift(notif);
    if (this.notifications.length > 50) this.notifications.pop();
  }

  public markNotificationAsRead(id: string): void {
    const notif = this.notifications.find((n) => n.id === id);
    if (notif) notif.read = true;
  }

  public markAllNotificationsAsRead(): void {
    this.notifications.forEach((n) => (n.read = true));
  }

  public clearAllNotifications(): void {
    this.notifications = [];
  }

  // --- System Health ---

  public getSystemHealth(): SystemHealth {
    const uptimeSeconds = Math.floor((Date.now() - this.startTime) / 1000);
    const mem = process.memoryUsage();
    return {
      backend: 'OPERATIONAL',
      database: 'OPERATIONAL',
      mlEngine: 'OPERATIONAL',
      cryptoService: 'OPERATIONAL',
      apiGateway: 'OPERATIONAL',
      uptimeSeconds,
      totalEventsProcessed: this.totalEventsCounter + this.auditLogs.length,
      activeSessions: this.devices.size,
      memoryUsageMb: Math.round(mem.heapUsed / 1024 / 1024),
      timestamp: new Date().toISOString(),
    };
  }

  public getAuthAttempts(): AuthAttempt[] {
    return [...this.authAttempts];
  }
}

export const store = new SentinelStore();
