import type {
  AttackPhaseResult,
  AttackScenario,
  AttackSimulationRun,
  PolicyDecision,
  ThreatCategory,
  ThreatEvent,
  ThreatSeverity,
} from '../src/types/index.ts';
import { evaluateDeviceAnomaly } from './ai-engine.ts';
import { store } from './store.ts';
import { evaluateZeroTrust } from './zero-trust.ts';

export const ATTACK_SCENARIOS: AttackScenario[] = [
  {
    id: 'SCENARIO-1',
    name: 'Replay Attack (Nonce Reuse)',
    category: 'REPLAY_ATTACK',
    description: 'Adversary intercepts a valid cryptographic challenge-response and retransmits it in an attempt to spoof an authorized IoT session.',
    technicalMechanism: 'Eavesdropping on MQTT/CoAP telemetry stream; captures signed challenge payload and resubmits after 4 minutes.',
    expectedDefensiveResponse: 'QUARANTINE',
    severity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-2',
    name: 'Forged Digital Signature',
    category: 'AUTHENTICATION_ATTACK',
    description: 'Compromised node or attacker injects an altered command payload accompanied by an invalid signature.',
    technicalMechanism: 'Payload tampering; bit-flip in transit or signature computed with an illegitimate private key.',
    expectedDefensiveResponse: 'BLOCK',
    severity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-3',
    name: 'Expired Timestamp (Time-Skew Attack)',
    category: 'AUTHENTICATION_ATTACK',
    description: 'Attacker delays delivery of signed challenge or submits a stale credential with timestamp outside the 60-second validity window.',
    technicalMechanism: 'NTP spoofing or intentional store-and-forward packet delay exceeding the delta window.',
    expectedDefensiveResponse: 'DENY',
    severity: 'MEDIUM',
  },
  {
    id: 'SCENARIO-4',
    name: 'Concurrent Nonce Reuse',
    category: 'REPLAY_ATTACK',
    description: 'Twin device clones simultaneously attempt mutual authentication using an identical pre-allocated nonce.',
    technicalMechanism: 'Hardware clone deployment attempting parallel session hijacking.',
    expectedDefensiveResponse: 'QUARANTINE',
    severity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-5',
    name: 'Rogue / Unregistered Device Injection',
    category: 'UNAUTHORIZED_ACCESS',
    description: 'An unauthorized rogue hardware device attempts to negotiate Zero-Trust TLS session without prior cryptographic enrollment.',
    technicalMechanism: 'Direct Ethernet injection or rogue Wi-Fi client presenting untrusted SPKI certificate.',
    expectedDefensiveResponse: 'BLOCK',
    severity: 'HIGH',
  },
  {
    id: 'SCENARIO-6',
    name: 'Brute-Force Authentication Burst',
    category: 'AUTHENTICATION_ATTACK',
    description: 'Adversary floods the authentication endpoint with rapid, randomly guessed challenge responses.',
    technicalMechanism: 'Automated fuzzing script issuing 150 failed signature verification requests per second.',
    expectedDefensiveResponse: 'RATE_LIMIT',
    severity: 'HIGH',
  },
  {
    id: 'SCENARIO-7',
    name: 'AI Behavioural Anomaly (Command Frequency Spike)',
    category: 'ANOMALOUS_BEHAVIOUR',
    description: 'Node is compromised via local buffer overflow; begins generating abnormal high-frequency actuator control commands.',
    technicalMechanism: 'Command rate surges from 0.2/min to 18.5/min (14.2σ above device baseline).',
    expectedDefensiveResponse: 'RESTRICT',
    severity: 'HIGH',
  },
  {
    id: 'SCENARIO-8',
    name: 'Data Exfiltration / Suspicious Outbound Traffic',
    category: 'SUSPICIOUS_TRAFFIC',
    description: 'Sensor attempts to connect to multiple external non-whitelisted IP addresses and transmit bulk binary dumps.',
    technicalMechanism: 'Telemetry exfiltration via covert DNS/UDP channels; payload byte volume exceeds 40x baseline.',
    expectedDefensiveResponse: 'QUARANTINE',
    severity: 'HIGH',
  },
  {
    id: 'SCENARIO-9',
    name: 'Unauthorized Administrative Command Injection',
    category: 'UNAUTHORIZED_ACCESS',
    description: 'Standard temperature sensor attempts to execute privileged firmware reflash command.',
    technicalMechanism: 'Privilege escalation attempt; invoking restricted RPC method `/system/reflash_bootloader`.',
    expectedDefensiveResponse: 'BLOCK',
    severity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-10',
    name: 'Device Identity / Key Mismatch',
    category: 'CREDENTIAL_ABUSE',
    description: 'Adversary signs challenge with Device A private key while asserting the hardware identity of Device B.',
    technicalMechanism: 'Public key fingerprint mismatch against hardware MAC/UUID in Zero-Trust catalog.',
    expectedDefensiveResponse: 'BLOCK',
    severity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-11',
    name: 'Quarantine Policy Evasion',
    category: 'POLICY_VIOLATION',
    description: 'An already quarantined or restricted device attempts to bypass network ACLs to communicate with SCADA control loop.',
    technicalMechanism: 'Zero-Trust enforcement barrier breached; attempts to establish raw socket to PLC port 502.',
    expectedDefensiveResponse: 'BLOCK',
    severity: 'CRITICAL',
  },
];

/**
 * Execute a single educational attack simulation through the 6 defensive phases
 */
export function executeAttackScenario(
  scenarioId: string,
  targetDeviceId?: string
): AttackSimulationRun {
  const scenario = ATTACK_SCENARIOS.find((s) => s.id === scenarioId);
  if (!scenario) throw new Error(`Scenario ${scenarioId} not found`);

  const devices = store.getDevices();
  let target = targetDeviceId ? store.getDevice(targetDeviceId) : undefined;
  if (!target) {
    target = devices.find((d) => d.status !== 'BLOCKED') || devices[0];
  }

  const timestamp = new Date().toISOString();
  const phases: AttackPhaseResult[] = [];
  let finalDecision: PolicyDecision = scenario.expectedDefensiveResponse;
  let threatCreated: ThreatEvent | undefined;
  let deviceQuarantined = false;

  // Phase 1: INGEST
  phases.push({
    phase: 1,
    name: 'Ingest & Boundary Inspection',
    status: 'PASSED',
    detail: `Telemetry stream & cryptographic packet ingested from source IP ${target.ipAddress} (asserted ID: ${target.id}). Boundary firewall routed packet to SentinelIoT verification pipeline.`,
  });

  // Phase 2: DETECT
  let detectDetail = '';
  switch (scenario.id) {
    case 'SCENARIO-1':
    case 'SCENARIO-4':
      detectDetail = 'Zero-Trust Nonce Store flagged duplicate challenge submission. Nonce was previously invalidated at timestamp delta +240s.';
      break;
    case 'SCENARIO-2':
      detectDetail = `OpenSSL cryptographic verification engine failed: Signature bytes rejected against public key ${target.keyFingerprint}.`;
      break;
    case 'SCENARIO-3':
      detectDetail = 'Timestamp validation check failed: Client packet timestamp skewed by 312 seconds beyond the 60s tolerance window.';
      break;
    case 'SCENARIO-5':
      detectDetail = 'Identity lookup in Zero-Trust catalog failed: Unknown hardware identity [IOT-ROGUE-9921]. No enrolled public key.';
      break;
    case 'SCENARIO-6':
      detectDetail = 'Rate-limiting monitor triggered: 48 failed challenge-response attempts received within 2.4 seconds.';
      break;
    case 'SCENARIO-7':
      detectDetail = 'AI Anomaly Detector triggered: Isolation Forest flagged 14.8 commands/min (nominal baseline is 0.2 cmd/min, 11.2σ deviation).';
      break;
    case 'SCENARIO-8':
      detectDetail = 'Network telemetry monitor flagged 6 unknown destination external IPs and 42,000 bytes/min outbound payload.';
      break;
    case 'SCENARIO-9':
      detectDetail = 'Zero-Trust ACL gate rejected command: Sensor role attempted unauthorized RPC execution: /system/reflash_bootloader.';
      break;
    case 'SCENARIO-10':
      detectDetail = 'Hardware-Crypto binding failure: Digital signature validated against key for IOT-ESP32-07, but asserted ID was IOT-EDGE-GW-01.';
      break;
    case 'SCENARIO-11':
      detectDetail = 'Policy violation: Device is currently marked QUARANTINED in SOC database; attempted restricted outbound connection.';
      break;
    default:
      detectDetail = 'Defensive anomaly detected in incoming packet stream.';
  }

  phases.push({
    phase: 2,
    name: 'Security Control Detection',
    status: 'DETECTED',
    detail: detectDetail,
  });

  // Phase 3: ANALYZE
  phases.push({
    phase: 3,
    name: 'Threat & Context Analysis',
    status: 'ANALYZING',
    detail: `Threat taxonomy classified as [${scenario.category}]. Target device classification: ${target.type}. Firmware age: ${target.firmwareAgeMonths} months.`,
  });

  // Phase 4: SCORE
  const riskDelta = scenario.severity === 'CRITICAL' ? 45 : scenario.severity === 'HIGH' ? 30 : 15;
  const simulatedRisk = Math.min(100, target.riskScore + riskDelta);
  phases.push({
    phase: 4,
    name: 'Risk & Trust Recalculation',
    status: 'ANALYZING',
    detail: `Zero-Trust trust score degraded from ${target.trustScore} to ${Math.max(0, 100 - simulatedRisk)}. Risk elevated by +${riskDelta} to ${simulatedRisk}/100 (${scenario.severity} tier).`,
  });

  // Phase 5: DECIDE
  finalDecision = scenario.expectedDefensiveResponse;
  phases.push({
    phase: 5,
    name: 'Zero-Trust Policy Decision',
    status: 'MITIGATED',
    detail: `Zero-Trust decision matrix evaluated risk posture: Enforcing automated action [${finalDecision}].`,
  });

  // Phase 6: RESPOND
  let responseDetail = '';
  if (finalDecision === 'QUARANTINE') {
    store.updateDeviceStatus(target.id, 'QUARANTINED', `Automated response to simulation: ${scenario.name}`);
    deviceQuarantined = true;
    responseDetail = `Device ${target.id} isolated to quarantine VLAN. Telemetry revoked, outbound routes severed.`;
  } else if (finalDecision === 'BLOCK') {
    store.updateDeviceStatus(target.id, 'BLOCKED', `Automated response to simulation: ${scenario.name}`);
    responseDetail = `Device ${target.id} permanently blocked. Cryptographic identity revoked in Zero-Trust catalog.`;
  } else if (finalDecision === 'RESTRICT') {
    store.updateDeviceStatus(target.id, 'SUSPICIOUS', `Automated response to simulation: ${scenario.name}`);
    responseDetail = `Device ${target.id} restricted to read-only diagnostic mode with rate-limiting.`;
  } else if (finalDecision === 'RATE_LIMIT') {
    responseDetail = `Traffic from ${target.ipAddress} throttled to 1 req/sec. Cooldown timer set for 300s.`;
  } else if (finalDecision === 'REAUTHENTICATE') {
    responseDetail = `Session invalidated. Immediate cryptographic challenge re-issued to device.`;
  } else {
    responseDetail = `Connection dropped silently. Host notified of policy failure.`;
  }

  // Create Threat Event
  const threatId = `THR-${Math.floor(1000 + Math.random() * 9000)}`;
  threatCreated = {
    id: threatId,
    timestamp,
    deviceId: target.id,
    deviceName: target.name,
    category: scenario.category,
    severity: scenario.severity,
    riskScore: simulatedRisk,
    status: 'CONTAINED',
    description: `[Attack Simulation] ${scenario.name} detected and mitigated.`,
    responseAction: finalDecision,
    containedAt: new Date().toISOString(),
    investigationNotes: `Defensive automated response executed policy ${finalDecision}. Threat contained by SOC rules engine.`,
  };
  store.addThreat(threatCreated);

  // Add audit log
  store.addAuditLog({
    id: `AUD-${Date.now().toString().slice(-4)}`,
    timestamp,
    event: `ATTACK_SIMULATION_${scenario.category}`,
    deviceId: target.id,
    deviceName: target.name,
    source: 'ATTACK_SIM',
    result: 'BLOCKED',
    details: `Scenario "${scenario.name}" executed. Action: ${finalDecision}. Threat ID: ${threatId}.`,
    severity: scenario.severity === 'CRITICAL' ? 'CRITICAL' : 'WARNING',
  });

  phases.push({
    phase: 6,
    name: 'Automated SOC Response & Containment',
    status: 'MITIGATED',
    detail: responseDetail,
  });

  return {
    scenarioId: scenario.id,
    scenarioName: scenario.name,
    timestamp,
    targetDeviceId: target.id,
    targetDeviceName: target.name,
    phases,
    finalDecision,
    threatCreated,
    deviceQuarantined,
    summary: `Defensive simulation completed successfully: Attack blocked at Phase 2 (Detect), Zero-Trust policy enforced ${finalDecision}, and threat logged.`,
  };
}

/**
 * Run all 11 scenarios sequentially
 */
export function executeAllAttackScenarios(): AttackSimulationRun[] {
  return ATTACK_SCENARIOS.map((scenario) => executeAttackScenario(scenario.id));
}
