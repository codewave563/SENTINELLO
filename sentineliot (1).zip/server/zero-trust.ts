import type {
  Device,
  PolicyDecision,
  RiskFactor,
  RiskLevel,
  ZeroTrustEvaluation,
} from '../src/types/index.ts';
import { evaluateDeviceAnomaly } from './ai-engine.ts';

/**
 * Perform continuous zero-trust evaluation on a device
 */
export function evaluateZeroTrust(
  device: Device,
  activeThreatCount = 0
): ZeroTrustEvaluation {
  const anomaly = evaluateDeviceAnomaly(device);

  // 1. Identity Trust (0-100)
  let identityTrust = 95;
  if (device.cryptoAlgorithm === 'ED25519') identityTrust = 100;
  else if (device.cryptoAlgorithm === 'ECDSA_P256') identityTrust = 96;
  else if (device.cryptoAlgorithm === 'RSA_2048') identityTrust = 88;

  // 2. Authentication Trust (0-100)
  const authFailRate = device.telemetry.authFailureRate;
  const authTrust = Math.max(0, Math.min(100, Math.round((1 - authFailRate) * 100 - device.telemetry.failedAuthCount * 12)));

  // 3. Device Health (0-100)
  let deviceHealth = 90;
  if (device.firmwareAgeMonths > 24) deviceHealth -= 35;
  else if (device.firmwareAgeMonths > 12) deviceHealth -= 15;
  if (device.telemetry.timeSinceLastSeen > 300) deviceHealth -= 20;

  // 4. Behavioural Trust (0-100) - inverse of ML anomaly score
  const behaviouralTrust = Math.max(0, 100 - anomaly.anomalyScore);

  // 5. Network Context (0-100)
  let networkContext = 92;
  if (device.telemetry.uniqueDestinations > 4) networkContext -= 30;
  else if (device.telemetry.uniqueDestinations > 2) networkContext -= 15;
  if (device.telemetry.bytesSent > 15000 && device.type !== 'CAMERA') networkContext -= 25;

  // 6. Threat Penalty (0-100)
  const threatPenalty = Math.min(100, activeThreatCount * 28 + (device.status === 'SUSPICIOUS' ? 25 : 0));

  // Compute Overall Trust Score (0-100)
  const rawTrust =
    identityTrust * 0.2 +
    authTrust * 0.25 +
    deviceHealth * 0.15 +
    behaviouralTrust * 0.25 +
    networkContext * 0.15 -
    threatPenalty * 0.35;

  let overallTrustScore = Math.min(100, Math.max(0, Math.round(rawTrust)));

  // Override by explicit quarantine/blocked status
  if (device.status === 'BLOCKED') overallTrustScore = Math.min(overallTrustScore, 8);
  if (device.status === 'QUARANTINED') overallTrustScore = Math.min(overallTrustScore, 20);

  // Risk Score is direct inverse of Trust Score
  const riskScore = 100 - overallTrustScore;

  // Risk Level
  let riskLevel: RiskLevel = 'LOW';
  if (riskScore >= 75) riskLevel = 'CRITICAL';
  else if (riskScore >= 55) riskLevel = 'HIGH';
  else if (riskScore >= 30) riskLevel = 'MEDIUM';

  // Zero-Trust Policy Decision
  let policyDecision: PolicyDecision = 'ALLOW';
  if (device.status === 'BLOCKED') {
    policyDecision = 'BLOCK';
  } else if (device.status === 'QUARANTINED' || riskScore >= 75) {
    policyDecision = 'QUARANTINE';
  } else if (riskScore >= 55) {
    policyDecision = 'RESTRICT';
  } else if (riskScore >= 30) {
    policyDecision = 'STEP_UP_AUTH';
  } else {
    policyDecision = 'ALLOW';
  }

  // Explainable risk factors contributing to elevated risk
  const explainableFactors: RiskFactor[] = [];

  if (device.telemetry.failedAuthCount > 0) {
    explainableFactors.push({
      factor: `Authentication failures (+${device.telemetry.failedAuthCount * 12})`,
      impact: device.telemetry.failedAuthCount * 12,
      category: 'AUTHENTICATION',
    });
  }

  if (anomaly.anomalyScore > 40) {
    const devImpact = Math.round(anomaly.anomalyScore * 0.4);
    explainableFactors.push({
      factor: `AI Behavioural deviation (+${devImpact})`,
      impact: devImpact,
      category: 'BEHAVIOUR',
    });
  }

  if (device.telemetry.bytesSent > 12000 && device.type !== 'CAMERA') {
    explainableFactors.push({
      factor: 'Unusual outbound data volume (+20)',
      impact: 20,
      category: 'NETWORK',
    });
  }

  if (device.telemetry.uniqueDestinations > 2) {
    explainableFactors.push({
      factor: `Multiple unfamiliar destination IPs (+${(device.telemetry.uniqueDestinations - 2) * 12})`,
      impact: (device.telemetry.uniqueDestinations - 2) * 12,
      category: 'NETWORK',
    });
  }

  if (device.firmwareAgeMonths > 12) {
    explainableFactors.push({
      factor: `Outdated firmware (${device.firmwareAgeMonths} mos without CVE patch, +${device.firmwareAgeMonths > 24 ? 25 : 12})`,
      impact: device.firmwareAgeMonths > 24 ? 25 : 12,
      category: 'FIRMWARE',
    });
  }

  if (activeThreatCount > 0) {
    explainableFactors.push({
      factor: `Active threat detections in quarantine scope (+${activeThreatCount * 25})`,
      impact: activeThreatCount * 25,
      category: 'HISTORIC',
    });
  }

  if (explainableFactors.length === 0) {
    explainableFactors.push({
      factor: 'Nominal telemetry within cryptographic Zero-Trust tolerance',
      impact: 0,
      category: 'AUTHENTICATION',
    });
  }

  return {
    deviceId: device.id,
    deviceName: device.name,
    identityTrust,
    authTrust,
    deviceHealth,
    behaviouralTrust,
    networkContext,
    threatPenalty,
    overallTrustScore,
    riskScore,
    riskLevel,
    policyDecision,
    explainableFactors,
    timestamp: new Date().toISOString(),
  };
}
